﻿
function Write-Log 
{ 
    [CmdletBinding()] 
    Param 
    ( 
        [Parameter(Mandatory=$true, 
                   ValueFromPipelineByPropertyName=$true)] 
        [ValidateNotNullOrEmpty()] 
        [Alias("LogContent")] 
        [string]$Message, 
 
        [Parameter(Mandatory=$false)] 
        [Alias('LogPath')] 
        [string]$Path="$env:SystemDrive\TEMP\IPChange_HID-USB_1.2.log", 
         
        [Parameter(Mandatory=$false)] 
        [ValidateSet("Error","Warn","Info")] 
        [string]$Level="Info", 
         
        [Parameter(Mandatory=$false)] 
        [switch]$NoClobber 
    ) 
 
    Begin 
    { 
        # Set VerbosePreference to Continue so that verbose messages are displayed. 
        $VerbosePreference = 'SilentlyContinue' 
    } 
    Process 
    { 
         
        # If the file already exists and NoClobber was specified, do not write to the log. 
        if ((Test-Path $Path) -AND $NoClobber) { 
            Write-Error "Log file $Path already exists, and you specified NoClobber. Either delete the file or specify a different name." 
            Return 
            } 
 
        # If attempting to write to a log file in a folder/path that doesn't exist create the file including the path. 
        elseif (!(Test-Path $Path)) { 
            Write-Verbose "Creating $Path." 
            $NewLogFile = New-Item $Path -Force -ItemType File 
            } 
 
        else { 
            # Nothing to see here yet. 
            } 
 
        # Format Date for our Log File 
        $FormattedDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss" 
 
        # Write message to error, warning, or verbose pipeline and specify $LevelText 
        switch ($Level) { 
            'Error' { 
                Write-Error $Message 
                $LevelText = 'ERROR:' 
                } 
            'Warn' { 
                Write-Warning $Message 
                $LevelText = 'WARNING:' 
                } 
            'Info' { 
                Write-Verbose $Message 
                $LevelText = 'INFO:' 
                } 
            } 
         
        # Write log entry to $Path 
        
        "$FormattedDate $LevelText $Message" | Out-File -FilePath $Path -Append
    } 
    End 
    { 
    } 
}

#------------------------------------------------

$installed32=$null
$installed64=$null
$IP='192.168.63.99'

Write-log "Checking If Installed , Application Name : 'PAR Express v4.01.0000' - {2C13243C-7945-4FAA-A988-7C63AB821F7E}"

$installed32=Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | where {$_.pschildname -like "{2C13243C-7945-4FAA-A988-7C63AB821F7E}"}|Select-Object{$_.displayname} -ErrorAction SilentlyContinue
$installed64=Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | where {$_.pschildname -like "{2C13243C-7945-4FAA-A988-7C63AB821F7E}"}|Select-Object{$_.displayname} -ErrorAction SilentlyContinue
$ApplicationInstalled=($installed32 -or $installed64)

Write-log "Application Installed : $ApplicationInstalled"

If ($ApplicationInstalled)
{

    $NetAdapters=@(Get-NetAdapter)
    Write-Log -Message "Finding the Network adapter "
    Write-log -Message "Found -- `n  $NetAdapters"

    foreach($adapter in $NetAdapters) 
    {
        $Alias=$adapter.InterfaceAlias
        $Discription=$adapter.InterfaceDescription

        if ($Discription -like "HID USB CDC EEM Ethernet Adapter*")
        #if ($Discription -like "Intel(R)*")
            {
            New-NetIPAddress -IPAddress $IP -PrefixLength 24 -InterfaceAlias $Alias -AddressFamily IPv4 -ErrorAction SilentlyContinue
            Write-log -Message "IP Address Modified : $IP for NIC, Name:$Alias, InterfaceDescription:$Discription "
            Write-Log "Verifying the Oparation for success"
            $IPstoVerify=(Get-NetIPConfiguration -InterfaceAlias $Alias).ipv4address.ipaddress 

                If ($IPstoVerify -contains $IP) 
                {
                  Write-Log "$IPstoVerify contains $IP "
                  Write-Log "Oparation Successful. ENDING SCRIPT with Success - $LASTEXITCODE"
                  $ExitC=0 
                
                }
                else{Write-Log "Unexpected Error occured, Exiting the Script with Error"
                     $ExitC=9} # 9 for error, 0 for success
            
            }
        else { Write-log -Message "NO NIC found with Matching InterfaceDescription like 'HID USB CDC EEM Ethernet Adapter*'"}

    }    
}
Else {Write-log "Application Not Installed, Script wont run"}

Write-log "==================================================================================================="
New-item -Path HKLM:\SOFTWARE\NYUMC\NYULMC_IPModify_1.1 -Force
New-ItemProperty -Path HKLM:\SOFTWARE\NYUMC\NYULMC_IPModify_1.1 -Name ExitCode -Value $ExitC -ErrorAction SilentlyContinue -Force
[System.Environment]::Exit($ExitC)



