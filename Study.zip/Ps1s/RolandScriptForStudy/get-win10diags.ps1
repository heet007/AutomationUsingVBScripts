﻿#==========================================================================================================================================
# Program			: GET-WIN10DIAGS.PS1
# Version			: 1.2.0
# Date				: June 24 2021
# Author			: Roland Thomas
# Team				: MCIT / End User Device Engineering
#
# This script collects diagnostics on a remote computer and then copies the logs back to the local machine in C:\TEMP\Win10Diags_<machinename>
#
# Reference Links:
# ---------------
# https://support.microsoft.com/en-us/help/12373/windows-update-faq
# https://docs.microsoft.com/en-us/windows/deployment/upgrade/resolve-windows-10-upgrade-errors
# https://docs.microsoft.com/en-us/windows/deployment/upgrade/setupdiag
# https://docs.microsoft.com/en-us/windows-hardware/manufacture/desktop/windows-setup-states
# https://docs.microsoft.com/en-us/windows-hardware/manufacture/desktop/windows-setup-command-line-options
# https://docs.microsoft.com/en-us/windows-hardware/manufacture/desktop/deployment-troubleshooting-and-log-files
# https://support.microsoft.com/en-us/help/928901/log-files-that-are-created-when-you-upgrade-to-a-new-version-of-window
# https://docs.microsoft.com/en-us/windows-hardware/manufacture/desktop/windows-setup-log-files-and-event-logs
#
# 01-26-20 (v1.0.0) : First release
# 05-11-20 (v1.1.0) : Added capture of Windows Update log, Windows Event logs, group policy trace folders and additional Windows diagnostic folders
# 06-24-21 (v1.2.0) : Rebranded to be a general purpose script to remotely collect diagnostic logs, purpose is not just for Win10 Setup diagnostics

[cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]
param(
    [string]$Computer = $env:COMPUTERNAME,
    [switch]$Recovery = $False,
    [switch]$AddUpgradeDiags = $False,
    [switch]$ShowProgress = $False
)


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-DNtoCN([string]$DistinguishedName) {

    # Parsing if an empty string is sent 
    if ([string]::IsNullOrEmpty($DistinguishedName)) { return $Null }


    # Strip off leading LDAP prefix if there is any
    if ($DistinguishedName -like "LDAP://*") { $DistinguishedName = $DistinguishedName -replace "LDAP://","" }


    # Split the distinguished name into separate bits 
    $Parts = $DistinguishedName.Split(",")
 
    foreach ($Part in $Parts) {
        if ($Part -like "OU=*") {
            $Subpart = $Part -replace "OU=",""
            $CanonicalName = "/$Subpart" + $CanonicalName
        }

    }

    $CanonicalName = "nyumc.org" + $CanonicalName

    return $CanonicalName

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-CurrentRemoteUser ($Machine) {

    try {

        $UserInfo = Invoke-Command -ComputerName $Machine -ErrorAction SilentlyContinue -ScriptBlock {
            $ErrorActionPreference = "SilentlyContinue"
            $Quser = quser.exe
            if ($Quser) {
                return ($QuserInfo = $Quser[1] -replace '\s+',' ' -split " ")
            } else {
                return $False
            }
        }


        if ($UserInfo) {
            try { if (Get-Process logonui -ComputerName $Machine -ErrorAction Stop) { $WorkstationState = "LOCKED" } } 
            catch { $WorkstationState = "UNLOCKED" } 
    
            if ($UserInfo.Count -eq 8) { # HACK: if number of elements = 8, that means the SessionName is blank, and need to decrement index
    
                $CurrentRemoteUser = [PSCustomObject]@{
                    UserName = $UserInfo[1].ToUpper()
                    SessionName = "NONE"
                    SessionID = $UserInfo[2]
                    UserState = $UserInfo[3].ToUpper()
                    IdleTime= $UserInfo[4]
                    LogonTime = $UserInfo[5] + " " + $UserInfo[6] + $UserInfo[7]
                    WorkstationState = $WorkstationState
                }

            } else {

                $CurrentRemoteUser = [PSCustomObject]@{
                    UserName = $UserInfo[1].ToUpper()
                    SessionName = $UserInfo[2].ToUpper()
                    SessionID = $UserInfo[3]
                    UserState = $UserInfo[4].ToUpper()
                    IdleTime= $UserInfo[5]
                    LogonTime = $UserInfo[6] + " " + $UserInfo[7] + $UserInfo[8]
                    WorkstationState = $WorkstationState
               }

            }

        } else {
            $CurrentRemoteUser = $False
        }

    }


    catch {
        $CurrentRemoteUser = $False
    }

    return $CurrentRemoteUser}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-OnlineStatus($Machine) {    $PingStatus = Test-Connection -ComputerName $Machine -Count 1 -Quiet -ErrorAction SilentlyContinue    if ($PingStatus) {        $Machine_IPAddress = (Test-Connection -ComputerName $Machine -Count 1).IPV4Address.IPAddressToString        $FQDN_Machine = ([System.Net.Dns]::GetHostEntry($Machine)).Hostname        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "Yes"
            DNSHostName = $FQDN_Machine
            IPAddress = $Machine_IPAddress
        }

    } else {        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "No"
            DNSHostName = "OFFLINE"
            IPAddress = "OFFLINE"
        }
    }    return $ReturnObject}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-OSVersion ($OSName, $OSBuild) {

    if ($OSName -like "*Windows 7*") {

        $OSEdition = $OSName -replace "Windows 7","Win7"
        $OSVersion = "$OSEdition $OSBuild"    } else {        $OSEdition = $OSName -replace "Windows 10","Win10"        switch -Wildcard ($OSBuild) {            "*10240*" { $Win10_Version = "ver 1507 RTM" }
            "*10586*" { $Win10_Version = "ver 1511" }
            "*14393*" { $Win10_Version = "ver 1607" }
            "*15063*" { $Win10_Version = "ver 1703" }
            "*16299*" { $Win10_Version = "ver 1709" }
            "*17134*" { $Win10_Version = "ver 1803" }
            "*17763*" { $Win10_Version = "ver 1809" }
            "*18362*" { $Win10_Version = "ver 1903" }            "*18363*" { $Win10_Version = "ver 1909" }            "*19041*" { $Win10_Version = "ver 2004" }            "*19043*" { $Win10_Version = "ver 21H1" }            "*19044*" { $Win10_Version = "ver 21H2" }            default { $Win10_Version = "ver UNKNOWN" }        }        $OSVersion = "$OSEdition ($Win10_Version - build $OSBuild)"
    }    return $OSVersion}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-Subnet($Machine) {

    try {
        $NetworkAdapters = Get-CimInstance -Namespace "root\cimv2" -Class Win32_NetworkAdapterConfiguration -ComputerName $Machine -OperationTimeoutSec 30 `
             -Property * -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | ? {($_.IPEnabled -eq "True") -and ($_.DefaultIPGateway -ne $Null)}

        $NetworkAdapters | % {
 
           # Compute the Subnet (Network ID) from the IP Address and Subnet Mask
           $IPAddress = @($_.IPAddress)[0]
           $IPAddress_Octets = $IPAddress -split "\."              # Split up IP Address into array of 4 octets
           $SubnetMask_Octets = @($_.IPSubnet)[0] -split "\."      # Do the same for the subnet mask
           $Subnet_Octets = @{}                                    # Initialize hashtable for the subnet

           for ($i=0; $i -le 3; $i++) {                            # Do binary-and on all octets
               [int32]$Subnet_Octets[$i] = [int32]$IPAddress_Octets[$i] -band [int32]$SubnetMask_Octets[$i]
               $Subnet_NetworkID += ($Subnet_Octets[$i]).ToString() + "."  # Concatenate the result back into dotted-notation
           }

           $Subnet_NetworkID = $Subnet_NetworkID -replace ".$"             # Strip off last dot (artifact of last command)

        }

    }

   catch { $Subnet_NetworkID = "OFFLINE" }

   return $Subnet_NetworkID

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SystemInfo ($Machine) {

    try {
        $OSInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem -ComputerName $Machine -ErrorAction SilentlyContinue    }    catch {        $OSInfo = $False        Error-Handler "Unable to query WMI Win32_OperatingSystem class on [$Machine]" $ExitonError
    }    if ($OSInfo) {        # Get last boot tiime        $BootTime = $OSInfo.ConvertToDateTime($OSInfo.LastBootUpTime)  # Use this if enumerating with GET-WMIOBJECT        ### $BootTime = $OSInfo.LastBootUpTime    # Use this if enumerating with GET-CIMINSTANCE        if ($BootTime -eq $Null) { $BootTime = "UNKNOWN" }
        # Get OS Version
        $OSName = $OSInfo.Caption -replace "Microsoft ",""        if ($OSName -like "*Windows 7*") {

            $OSVersion = Get-OSVersion $OSName $OSInfo.CSDVersion        } else {            $OSVersion = Get-OSVersion $OSName $OSInfo.Version        }

    } else {

        $OSVersion = "UNKNOWN"
        $BootTime = "UNKNOWN"
    }


    $ReturnObject = [PSCustomObject]@{
        OSVersion = $OSVersion
        BootTime = $BootTime
    }    return $ReturnObject
}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------


Clear-Host

#region Start running the clock
$Script_StartTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"
Write-Output "`nProcessing Start`t: $Script_StartTime`n"
#endregion


#region Remotely connect to computer
$Computer = $Computer.ToUpper()

$ComputerStatus = Get-OnlineStatus -Machine $Computer

if ($ComputerStatus.OnlineStatus -ne "Yes") {
    Write-Warning "$Computer : Cannot ping machine - it may be offline"

} else {

    $Subnet = Get-Subnet -Machine $Computer
    $SystemInfo = Get-SystemInfo -Machine $Computer

    $CurrentOU = Convert-DNtoCN -DistinguishedName (Get-ADComputer -Identity $Computer).DistinguishedName
    $CurrentUser = (Get-CurrentRemoteUser -Machine $Computer).UserName


    $RemotePC = [PSCustomObject]@{
        DNSHostName = $ComputerStatus.DNSHostName
        IPAddress = $ComputerStatus.IPAddress
        Subnet = if ([bool]$Subnet) {$Subnet} else {"UNKNOWN"}
        OSVersion= $SystemInfo.OSVersion
        CurrentOU = $CurrentOU
        CurrentUser = if ([bool]$CurrentUser) {$CurrentUser} else {"UNKNOWN"}
        BootTime = $SystemInfo.BootTime
    }


    Write-Host "`nComputer [$Computer] is online and reporting this information:"
    $RemotePC

    ### exit

    $Session = New-PSSession -ComputerName $Computer
    $TargetFolder = "C:\TEMP"

    if ($AddUpgradeDiags) {

        # Define where to get the diagnostic tool and where to copy it to on the remote computer
        $SourceFolder = "\\mscsnyu01.nyumc.org\adbuild\DET_Builds\Packages\Microsoft Products\Diagnostics"
        $Exec = "setupdiag.exe"
        $Installer = "$SourceFolder\$Exec"

        if (!(Test-Path $Installer -ErrorAction SilentlyContinue)) { Write-Warning "$Computer : Cannot find diagnostic executable - $Installer" ; exit }

        $FileVersion = (Get-ChildItem -Path $Installer).VersionInfo.ProductVersion
        Write-Host "`n$Computer : Deploying Microsoft SetupDiag v$FileVersion to remote computer [$Computer]`n"

        Copy-Item -Path $Installer -Destination $TargetFolder -ErrorAction SilentlyContinue -Force -ToSession $Session | Out-Null

        if ($Recovery) {
            $Arglist = "/output:SetupDiag.log /verbose /ziplogs:false /scenario:recovery"  ## log location should be in $DiagFolder 
        } else {
            $Arglist = "/verbose /ziplogs:false"
        }

    }


    #region Command block to run on remote machine - run the diagnostic in a non-interactive session
    $DiagTime = Get-Date -Format "yyyyMMdd-HHmmss"

    ### $Results = Invoke-Command -ComputerName $Computer -ArgumentList $Computer, $TargetFolder, $Exec, $Arglist -ErrorAction SilentlyContinue -ScriptBlock { 
    $Results = Invoke-Command -Session $Session -ArgumentList $Computer, $TargetFolder, $DiagTime, $Exec, $Installer, $AddUpgradeDiags, $ShowProgress, $Arglist -ErrorAction SilentlyContinue -ScriptBlock { 

        param ($Computer, $TargetFolder, $DiagTime, $Exec, $Installer, $AddUpgradeDiags, $ShowProgress, $Arglist)

        $UpgradeStatus = $Null
        $DiagFolder = "$TargetFolder\Win10Diags_$Computer-$DiagTime"

        if (Test-Path -Path $DiagFolder -ErrorAction SilentlyContinue) { Remove-Item -Path $DiagFolder -Force -Recurse | Out-Null }
        New-Item -Path $DiagFolder -ItemType Directory | Out-Null

        Set-Location -Path $DiagFolder


        if ($AddUpgradeDiags) {
 
            if (!(Test-Path -Path "$TargetFolder\$Exec" -ErrorAction SilentlyContinue)) {

                Write-Host "$Computer : Failed to copy Setup Diagnostics package to remote computer" -ForegroundColor Red
                Write-Host "$Computer : $Installer -> $TargetFolder" -ForegroundColor Red

                return $False

            } else {

                Write-Host "$Computer : Running Windows 10 Setup Diagnostics ... please wait"
                Write-Host "$Computer : Arguments = $Arglist`n"

                Start-Process -FilePath $TargetFolder\$Exec -ArgumentList $Arglist -Wait

                # Backup the logfiles for the SETUPDIAG tool itself
                if (Test-Path -Path "$TargetFolder\SetupDiag*.*" -ErrorAction SilentlyContinue) { Move-Item -Path "$TargetFolder\SetupDiag*.*" -Destination $DiagFolder | Out-Null }
                if (Test-Path -Path "C:\Logs*.zip" -ErrorAction SilentlyContinue) { Move-Item -Path "C:\Logs*.zip" -Destination $DiagFolder | Out-Null }

            }

        }


        # Backup the NYULH Windows 10 Upgrade Script log if it exists
        if (Test-Path -Path "C:\Temp\$Computer-Win10Upgrade.log" -ErrorAction SilentlyContinue) {
            Write-Host "$Computer : Copying Windows 10 Upgrade Log"        
            Copy-Item -Path "C:\Temp\$Computer-Win10Upgrade.log" -Destination $DiagFolder -ErrorAction SilentlyContinue | Out-Null
        }



        # The MDM Diagnostic tool collects information about policies executed by GPO and Workspace One , and which ones have conflict with the other
        Write-Host "$Computer : Running MDM Diagnostics Tool"
        Start-Process -FilePath "c:\windows\system32\mdmdiagnosticstool.exe" -ArgumentList "-out $DiagFolder\mdmdiagnostics" -Wait


        # Backup the Windows event logs
        Write-Host "$Computer : Backing up all Windows event logs"
        $EventLogList = wevtutil enum-logs
        New-Item -Path "$DiagFolder\Eventlogs" -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
        foreach ($LogName in $EventLogList) {
            $LogFile = $LogName -replace " ","" -replace "/","_"
            $EventLogPath = "$DiagFolder\Eventlogs\$LogFile.evtx"
            if ($ShowProgress) { Write-Host "$Computer : Backing up eventlog [$LogName]" }
            $Index = [array]::IndexOf($EventLogList, $LogName) + 1
            $PercentComplete = [int32](($Index / $($EventLogList.Count)) * 100)
            Write-Progress -Activity "$Computer : Backing up eventlog [$LogName] ($Index out of $($EventLogList.Count))" -Status "$PercentComplete% complete" -PercentComplete $PercentComplete
            wevtutil export-log $LogName $EventLogPath /overwrite:true
        }
        Write-Progress -Activity "$Computer : Backing up eventlog [$LogName] ($Index out of $($EventLogList.Count))" -Status "Completed" -Completed


        # Backup various system and diagnostic folders
        New-Item -Path "$DiagFolder\C-Root" -ItemType Directory -ErrorAction SilentlyContinue | Out-Null

        $LogList = @("$env:WINDIR\ntbtlog.txt", "$env:WINDIR\inf\setupapi.log", "$env:WINDIR\memory.dmp", "$env:WINDIR\minidump.dmp", "$env:WINDIR\debug", "$env:WINDIR\logs", 
            "$env:PROGRAMDATA\GroupPolicy", "$env:PROGRAMDATA\Microsoft\GroupPolicy", "$env:PROGRAMDATA\USOPrivate", "$env:PROGRAMDATA\USOShared", 
            "$env:PROGRAMDATA\Sophos\Sophos Anti-Virus", "$env:PROGRAMDATA\Symantec", "C:\$Computer.TXT", "C:\AppsenseLogs")

        if ($AddUpgradeDiags) {
            $LogList += @("$env:WINDIR\system32\sysprep\panther", "$env:WINDIR\Panther", "C:\`$WINDOWS.~BT\Sources\Panther", "C:\`$WINDOWS.~BT\Sources\Rollback") 
        }

        foreach ($Item in $LogList) {
            if (Test-Path -Path $Item -PathType Any -ErrorAction SilentlyContinue) { 

                if ($ShowProgress) { Write-Host "$Computer : Backing up file/folder : $Item" }
                $Parent = ($Item -split "\\")[1]
                New-Item -Path "$DiagFolder\C-Root\$Parent" -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
                Copy-Item -Path $Item -Destination "$DiagFolder\C-Root\$Parent" -Force -Recurse -Container -ErrorAction SilentlyContinue | Out-Null

            } else {

                if ($ShowProgress) { Write-Host "$Computer : Could not find : $Item" -ForegroundColor Red }

            }
        }


        # Generate the Windows Update patching log
        Write-Host "$Computer : Generating Windows Update Scan Log"
        Get-WindowsUpdateLog -LogPath "$DiagFolder\WindowsUpdate.log"
        ### Start-Job -ArgumentList $DiagFolder -ScriptBlock { Get-WindowsUpdateLog -LogPath $DiagFolder\WindowsUpdate.log } | Wait-Job  ### | Remove-Job


        # Zip folder up for faster time to copy
        Write-Host "$Computer : Zipping all files to: $DiagFolder.zip"
        Compress-Archive -Path $DiagFolder -DestinationPath "$DiagFolder.zip" -ErrorAction SilentlyContinue


        # Return status back to the caller
        if ($AddUpgradeDiags) {    # return actual setup status or just True to indicate rest of diagnostics was captured

            # Finally capture the status of the upgrade that was saved in the registry by the upgrade process
            $RegKey = "HKLM:\SYSTEM\Setup\MoSetup\Volatile\SetupDiag"
            $RegName = "FailureData"
            $UpgradeStatus = (Get-ItemProperty -Path $RegKey -Name $RegName -ErrorAction SilentlyContinue).$RegName
     
            return $UpgradeStatus 

        } else {

            return $True 

        }
            
    }
    #endregion


    # The Results variable can have one of three values: $False, $True (non-specific status message), and a string that represents status as recorded by the Windows 10 SETUP.EXE
    if ([bool]$Results) {

        $DiagFolder = "$TargetFolder\Win10Diags_$Computer-$DiagTime"

        if ($Computer -ne $env:COMPUTERNAME) {

            # Copy the diagnostic logfile from the remote computer back to the local machine
            Write-Host "`n$Computer : Searching for [$DiagFolder] on remote computer [$Computer]"

            if ([bool](Invoke-Command -Session $Session -ScriptBlock { Test-Path -Path "$DiagFolder.zip" -ErrorAction SilentlyContinue })) {

                $SourceCopy = "$DiagFolder.zip"

            } else {

            if ([bool](Invoke-Command -Session $Session -ScriptBlock { Test-Path -Path $DiagFolder -ErrorAction SilentlyContinue })) {

                    $SourceCopy = $DiagFolder

                } else {

                    $SourceCopy = $False

                }

            }


            if ([bool]$SourceCopy) {
         
                ### robocopy $SourceCopy "C:\TEMP" /mir /r:10 /w:15 /np /ns /nc /nfl /ndl
                Copy-Item -Path $SourceCopy -Destination "C:\TEMP" -Force -Recurse -FromSession $Session -ErrorAction SilentlyContinue | Out-Null

                Write-Progress -Activity "$Computer : Copying [$SourceCopy] from remote computer [$Computer]" -Status "Completed" -Completed

            } else {

                Write-Host "$Computer : Diagnostic folder was not found on the remote computer - nothing to copy" -ForegroundColor Red

            }


            if (Test-Path -Path $SourceCopy -ErrorAction SilentlyContinue) {

                Write-Host "`n$Computer : Copy complete - saved to [$SourceCopy] on your computer"

            } else {

                Write-Host "`n$Computer : Copy failed - please examine the [$DiagFolder] folder on the remote computer"
            }


        } else {

            Write-Host "`n$Computer : Diagnostics complete - saved to [$DiagFolder] on your computer"  # fall to here if the diagnostics were run locally

        }


        # The Results variable can have one of three values: $False, $True (non-specific status message), and a string that represents status as recorded by the Windows 10 SETUP.EXE
        if ($Results -eq $True) {

            Write-Host "`n$Computer : No specific status message returned by Setup Diagnostic tool" -ForegroundColor Yellow

        } else {

            Write-Host "`n$Computer : According to the Setup Diagnostic tool this is the last message reported by the Win10 Upgrade:" -ForegroundColor Green
            Write-Host $Results -ForegroundColor Yellow

        }

    } else {

        Write-Host "$Computer : Win10 Diagnostics failed to run on computer [$Computer]" -ForegroundColor Red

    }


    Exit-PSSession

}
#endregion


#region Stop the clock and exit
$Script_EndTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"
$TimeDiff = New-TimeSpan -Start $Script_StartTime -End $Script_EndTime

Write-Host "`n`nProcessing Stop`t`t: $Script_EndTime"
Write-Output "`nScript completed in $($TimeDiff.Minutes) minutes $($TimeDiff.Seconds) seconds`n`n"
#endregion
