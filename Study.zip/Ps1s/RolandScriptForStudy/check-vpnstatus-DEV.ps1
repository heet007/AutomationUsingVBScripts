﻿#======================================================================================================================================================================# Program	: CHECK-VPNSTATUS.PS1# Version	: 1.6.5# Date		: Sep 28 2020# Author	: Roland Thomas# Team		: MCIT / End User Device Engineering## This script will do the following on a verified NYULH computer:#   if the device is connected over a VPN then,#      - map the H: drive to the user's home folder -- as defined by the HOMEDIRECTORY attribute in the user's AD object#      - map any required shared network drives#      - redirect known Windows folders, screensaver and wallpaper paths to production network shares#   otherwise, if the device is logged in locally then,#      - redirect known Windows folders, screensaver and wallpaper paths to local paths## This is accomplished by running the script as such:#     - when the user boots up and logs in locally, the script runs automatically out of the "Run" key under HKCU\Software\Microsoft\Windows\CurrentVersion #     - when user makes successful VPN connection, the f5 runs its own copy of the script located behind the firewall#     # The script needs to run against these two triggers so that folder redirection can be enabled or disabled based on connection state## The script will copy itself down from the network so that the local script will always be in sync with the latest code## Currently not implemented because they require elevation (which is not enabled by f5 client over VPN connection):#   - cached domain credentials locally if necessary (NEED TO DECIDE IF THIS IS REQUIRED)#   - execute group policies (using GPUPDATE /FORCE)#   - activate Windows 10 and Office 2016 if necessary using kms.nyumc.org server#   - execute scheduled task that scans machine for hardware and software inventory (EUDE_INVENTORY task)#   - force Windows Update to automatic scan / download / install  -- no autoreboot, user will be prompted to reboot if required## The script performs the following validation checks and will abort if any fail:#   - computer is not member of the GPO-WDX-VPN domain group#   - user is not member of the GPO-WDX-VPN domain group#   - credentials of the NYULH service account cannot be authenticated
#   - computer does not exists in AD
#   - computer has expired Microsoft LAPS password
#   - device is not a NYULH built computer
#
## 03-18-20 (v1.0.0): First release# 03-25-20 (v1.1.0): Added validation and activation of Windows 10 and Office 2016# 03-28-20 (v1.2.0): Added execution of shared-drive login script and scan for Windows Updates# 05-12-20 (v1.3.0): Added additional validations# 07-27-20 (v1.4.0): Comment out any code that requires elevation; need to figure out how to elevate after VPN connection which is limited to non-elevated privileges# 08-07-20 (v1.5.0): Add code to revert folder redirection if computer is disconnected# 08-18-20 (v1.6.0): Change how shared drive mappings are handled:#                       - Stop shelling out to run production logon script \\NYUMC.ORG\NETLOGON\LOGON2012.VBS because network firewall rejects anonymous LDAP queries#                       - Instead do database lookup by iterating through all enumerated user groups and mapping returned drive letters to the assigned drive paths# 08-25-20 (v1.6.1): Add detection and enumeration of attached and embedded devices like printers, video display adapters and monitors (the last requires elevation privileges)# 09-03-20 (v1.6.2): Add detection if Offline Folders are enabled; output session data to a CSV file saved to same network log folder as the transcript# 09-16-20 (v1.6.3): Rewrite SQL query parsing and database lookup functions# 09-20-20 (v1.6.4): Rewrite account credentials parsing and validation function# 09-28-20 (v1.6.5): Modify SQL Query and Shared Folder Mapping functions to login to database with user's domain account (which is member of GPO-WDX-VPN that has database read-only permissions)#Requires -Version 3.0[cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]param(    [switch]$DebugEnable=$True)if ($DebugEnable) {
    $DebugPreference = "SilentlyContinue"
    $ErrorActionPreference = "SilentlyContinue"    $VerbosePreference = "SilentlyContinue"} else {
    $DebugPreference = "SilentlyContinue"
    $ErrorActionPreference = "SilentlyContinue"    $VerbosePreference = "SilentlyContinue"}
#Initialize script-specific variables$ScriptFileName = $PSCommandPath.ToUpper()$ScriptVersion = "v1.6.5 (092820)"
$ScriptBuild = (Get-ChildItem -Path $ScriptFileName).LastWriteTime.ToString("MM-dd-yyyy hh:mm:ss tt")

$ScriptName = Split-Path $ScriptFileName -Leaf
$ScriptUNCPath = (Resolve-Path -Path $ScriptFileName).Drive.DisplayRoot + ((Split-Path -Path $ScriptFileName -NoQualifier) -replace $ScriptName,"")

$RunScriptLocally = [bool] ((Resolve-Path -Path $Script:ScriptFileName).Drive.Root -eq "C:\")

if ($RunScriptLocally) {
    $ScriptFullPath = $ScriptFileName
} else {
    $ScriptFullPath = $ScriptUNCPath + $ScriptName
}


$ExitonError = $True
$DontExitonError = $False


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Activate-Product {

    param(        [string]$ProductName,
        [string]$ProductAppId,
        [string]$ProductKeytoCheck,
        [string]$ProductKey,
        [string]$ActivationScript,
        [string]$ScriptBlocktoRun,
        [object]$Credential
    )


    Write-Log "Activating license for [$ProductName] with Application ID [$ProductAppID] ..."

    $ProductProperties = @("Name", "ApplicationID", "LicenseStatus", "PartialProductKey")

    $LicenseInfo = Get-ActivationStatus -AppID $ProductAppID -Properties $ProductProperties

    if ($LicenseInfo.LicenseStatus -eq "1") {   ### TURN THIS BACK TO -EQ FOR PROD
        Write-Log "License for [$ProductName] is already activated:"
        $LicenseInfo | ft
        return
    }


    if (!(Test-Path -Path $ActivationScript)) {
        Write-Log "`t- Activation script [$ActivationScript] was not found"
        return
    }

    $ScriptBlocktoRun
    exit

    ### Invoke-Expression -Command $ScriptBlocktoRun
    ### Invoke-Command -Credential $Credential -ScriptBlock { $ScriptBlocktoRun }

    $LicenseInfo = Get-ActivationStatus -AppID $ProductAppID -Properties $ProductProperties
    $LicenseInfo | ft

}



# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-CNtoDN ([string]$CanonicalName) {

    # Parsing if an empty string is sent 
    if ([string]::IsNullOrEmpty($CanonicalName)) { return $Null }


    # Split the canonical name into separate bits 
    $Parts = $CanonicalName.Replace("\","/").Split("//")

    foreach ($Part in $Parts) {

        $Index = $Parts.IndexOf($Part)

        if ($Index -eq 0) {
            $DomainNameParts = $env:USERDNSDOMAIN.Split(".")
            $DistinguishedName = "DC=$($DomainNameParts[0]),DC=$($DomainNameParts[1])"
        } else {
            $DistinguishedName = "OU=$Part," + $DistinguishedName
        }

    }

    return $DistinguishedName

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-DNtoCN ([string]$DistinguishedName) {

    # Parsing if an empty string is sent 
    if ([string]::IsNullOrEmpty($DistinguishedName)) { return $Null }


    # Strip off leading LDAP prefix if there is any
    if ($DistinguishedName -like "LDAP://*") { $DistinguishedName = $DistinguishedName -replace "LDAP://","" }


    # Split the distinguished name into separate bits 
    $Parts = $DistinguishedName.Split(",")
 
    foreach ($Part in $Parts) {
        if ($Part -like "OU=*") {
            $Subpart = $Part -replace "OU=",""
            $CanonicalName = "/$Subpart" + $CanonicalName
        }

    }

    $CanonicalName = $env:USERDNSDOMAIN + $CanonicalName

    return $CanonicalName

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Create-CustomScheduledTask ($TaskName, $TaskXMLFilePath) {

    $ExportedTaskFile = "$TaskXMLFilePath\$TaskName.xml"

    if (Test-Path $ExportedTaskFile) {

        # Read in the exported task definition file
        $ImportedTask = (Get-Content -Path $ExportedTaskFile) | Out-String
    
        # Create the task
        Register-ScheduledTask -TaskName $Taskname -XML $ImportedTask -Force -User "System"

        # Retrieve and display task parameters
        $TaskObject = Get-ScheduledTask -TaskName $Taskname

        $Result = [PSCustomObject]@{
            Principal = $TaskObject.Principal
            Triggers = $TaskObject.Triggers
            Actions = $TaskObject.Actions
            Settings = $TaskObject.Settings
        }

        return $Result

    } else {

        return $False

    }
       
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Error-Handler([string]$ErrorMessage, $_ExitonError) {

    $CallingFunction = ((Get-Variable MyInvocation -Scope 1).Value.MyCommand.Name).ToUpper() #-replace ".ps1",""
    $CallingLineNumber = $MyInvocation.ScriptLineNumber

    Write-Log $ErrorMessage -Color "Red" -CallingFunction $CallingFunction -LineNumber $CallingLineNumber

    <#
    try {

        $ExceptionMessage = $Error[0].Exception.Message
        if ($ExceptionMessage -ne $Null) { Write-Log "System error message was: '$ExceptionMessage'" -Color "Yellow" }
        
        $HResultCode = $Error[0].Exception.HResult
        if (([bool]$HResultCode) -and ($HResultCode -ne 0)) {
            $ExitCode = "0x" + $("{0:x}" -f $HResultCode)
        } else {
            $ExitCode = $LASTEXITCODE
        }

    }
    catch { 
        $ExitCode = -999
    }

    Write-Log "Returning to caller with Error Code: $ExitCode" -Color "Yellow"
    #>

    if ([bool]$_ExitonError) {
        Write-StopScriptTime $Script:StartTime  $Script:TranscriptLog $Script:NetworkLogFolder
        exit
    }

}
 
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Exec-SQLQuery {

    param (
        [string]$SQLServer,
        [string]$SQLDBName,
        [object]$SQLAccount,
        [string]$SQLQuery

    )

    [System.Data.SqlClient.SqlConnection]::ClearAllPools()

    $Error.Clear()

    $SQLDataSet = $Null

    $Timer = [diagnostics.stopwatch]::StartNew()

    $QueryTimeout = 15

    <#
    # Use this if logging in with local SQL authentication
    $SQLUID = "$($SQLAccount.UserName)"
    $SQLPWD = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SQLAccount.Password)))
    $ConnectionString = "Server=$SQLServer; Database=$SQLDBName; UID=$SQLUID; PWD=$SQLPWD; Timeout=$QueryTimeout; Integrated Security=True;"
    #>

    # Use this if logging in with Windows domain user account
    $ConnectionString = "Server=$SQLServer; Database=$SQLDBName; Timeout=$QueryTimeout; Integrated Security=True;"

    ### Write-Log "ConnectionString: $ConnectionString" -Color Green

    $SQLDataSet = New-Object System.Data.DataSet
    $SQLDataTable = New-Object System.Data.DataTable

    $SQLConnection = New-Object System.Data.SQLClient.SQLConnection
    $SQLConnection.ConnectionString = $ConnectionString
    $SQLConnection.Open()

    $SQLCommand = New-Object System.Data.SQLClient.SQLCommand
    $SQLCommand.Connection = $SQLConnection
    $SQLCommand.CommandText = $SQLQuery

    try {
        $SQLDataAdapter = New-Object System.Data.SqlClient.SqlDataAdapter $SQLCommand
        $SQLDataAdapter.Fill($SQLDataSet) | Out-Null
        $SQLDataTable = $SQLDataSet.Tables[0]
    }

    catch {
        ### Error-Handler "Connection attempt to database [$SQLServer`:$SQLDBName] failed" $DontExitonError        Error-Handler $Error[0].Exception.Message $DontExitonError
    }

    finally {
        $SQLConnection.Close()
        $Timer.Stop()
    }

    if ($SQLDataTable.Rows.Count -eq 0) {
        ### Write-Log "SQL query returned zero results.  Nothing to process!" -Color Red
        return $False
    } else {
        Write-Log "SQL Query completed in $($Timer.Elapsed) seconds and returned [$($SQLDataTable.Rows.Count)] records"
        return $SQLDataTable
    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Export-SessionInfotoCSV {

    [cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]    param(        [object]$Object,        [string]$Folder,        [string]$Filename    )

    $FileSizeLimit = [int]100  # max logfile size in kilobytes
    $ExportCSVFile = "$Folder\$Filename"

    $FileInfo = Get-ChildItem -Path $ExportCSVFile -Force
    $FileSize = [int]($FileInfo.Length / 1KB)  ### '1KB' is language constant that means 1 kilobyte
    $FileTimeStamp = $FileInfo.LastWriteTime.ToString("MMddyyyy-HHmmss")
    $NewFileName = $FileInfo.BaseName + "-ARCHIVE-" + $FileTimeStamp + $Fileinfo.Extension

    if ($FileSize -ge $FileSizeLimit) {
        Rename-Item -Path $ExportCSVFile -NewName $NewFileName
        Start-Sleep -Seconds 3
    }
 
    if (!(Test-Path -Path $ExportCSVFile)) {
        $Object | Export-Csv -Path $ExportCSVFile -NoTypeInformation # if file does not exist, create with header
    } else {
        $Object | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1 | Add-Content -Path $ExportCSVFile # if file already exist, append without header
    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-AccountCredentials {

    param(        [string]$Filename    )


    $EncryptScriptPath = "$Script:ScriptUNCPath`encrypt.ps1"

    if (!(Test-Path -Path $EncryptScriptPath)) {

        Error-Handler "Cannot load encryption routines from folder [$EncryptScriptPath]" $ExitonError

    } else {

        . $EncryptScriptPath # dot-source script to include the encrypt/decrypt functions (needs to be in same folder as this script)

        if (!(Test-Path -Path $Filename)) {

           Error-Handler "Cannot find XML account file: $Filename" $ExitonError
        } else {

            $AccountInfo = [xml](Get-Content -Path (Get-ChildItem -Path $Filename -ErrorAction SilentlyContinue -Attributes Hidden))

            # Encrypt-String -String "eude_reader" -Passphrase  $AccountInfo.Account.Passphrase
            # exit

            $SecurePassword = Decrypt-String -Encrypted $AccountInfo.Account.Hash -Passphrase $AccountInfo.Account.Passphrase | ConvertTo-SecureString -AsPlainText -Force

            $SecureCredential = New-Object System.Management.Automation.PsCredential($($AccountInfo.Account.Name), $SecurePassword)


            switch ($AccountInfo.Account.Type) {

                "SQL" { $ValidatedAccount = $True }

                "Domain" { $ValidatedAccount = (New-Object System.DirectoryServices.DirectoryEntry ("", $SecureCredential.GetNetworkCredential().UserName, $SecureCredential.GetNetworkCredential().Password)).PSBase.Name }

            }


            ### Write-Log "Retrieved Username = $($SecureCredential.UserName); Retrieved Password = $($SecureCredential.GetNetworkCredential().Password)" -Color Green


            if ([bool]$ValidatedAccount) {

                return $SecureCredential

            } else {

                return $False

            }

        }

    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-ActivationServer ($KMSServer, $KMSServerPort) {

    # Set default KMS server name and product keys
    Write-Log "Checking if NYULH Key Activation Server is enabled..."
    $KMSServerResolved = (nslookup $KMSServer | ConvertFrom-String | ? { $_.P1 -like "*Name*" }).P2


    # Read what Windows thinks is the current KMS server name (if any)
    $KMSService = Get-WmiObject -Class SoftwareLicensingService
    $KMSServerDiscovered = $KMSService.KeyManagementServiceMachine
    $KMSServerPortDiscovered = $KMSService.KeyManagementServicePort

    Write-Log "KMS Server (Defined) = $KMSServerResolved; KMS Server (Discovered) = $KMSServerDiscovered ($($KMSService.DiscoveredKeyManagementServiceMachineIpAddress))"
    Write-Log "KMS ServerPort (Defined) = $KMSServerPort; KMS ServerPort (Discovered) = $KMSServerPortDiscovered"


    #Verify that session can connect to KMS server
    $Error.Clear()
    if (($KMSServerResolved -ne $KMSServerDiscovered) -or ($KMSServerPort -ne $KMSServerPortDiscovered)) {

        Write-Log "Registering NYULH KMS Server [$KMSServer`:$KMSServerPort]"

        if ((Test-NetConnection -ComputerName $KMSServer -Port $KMSServerPort -ErrorAction SilentlyContinue).tcptestsucceeded) {

            $KMSService.SetKeyManagementServiceMachine($KMSServer)
            $KMSService.SetKeyManagementServicePort($KMSServerPort)
   
        } else {

            Error-Handler "Unable to ping [$KMSServer`:$KMSServerPort]" $DontExitonError
            return $False
    
        }

    } else {

        Write-Log "KMS Server [$KMSServer`:$KMSServerPort] is already registered and enabled"

    }
    
    return $KMSService

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-ActivationStatus ($AppID, $Properties) {
  
    return (Get-CimInstance -ClassName SoftwareLicensingProduct -Property $Properties -Filter "ApplicationID = '$AppID' AND LicenseStatus = '1'" -ErrorAction SilentlyContinue | select $Properties)
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-CurrentUser {

    $ProcessName = "explorer.exe"

    $Process = Get-WmiObject Win32_Process -Filter "Name='$ProcessName'" -ErrorAction SilentlyContinue

    if ([bool]$Process) {

        $UserName = ($Process | ForEach-Object { $_.GetOwner() } |  Select-Object -Unique -Expand User).ToUpper()

        $Principal = New-Object System.Security.Principal.NTAccount($env:USERDOMAIN, $UserName)

        $UserSID = ($Principal.Translate([System.Security.Principal.SecurityIdentifier])).Value

        ### Write-Log "Username = [$Username]; UserSID = [$UserSID]"

    } else {

        $UserName = $Null ; $UserSID = $Null

        Write-Log "Process [$ProcessName] was not found attached to any logged-on user"

    }

        
    $Result = [PSCustomObject]@{
        UserName = $UserName
        UserSID = $UserSID
    }

    return $Result
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-LocalCredential {

    param(        [string]$Machine=$env:COMPUTERNAME,        [string]$LocalUsername,        [string]$LocalPassword    )

    $LocalUsername = $LocalUsername.ToLower()

    # Verify the password username and password are valid
    Add-Type -AssemblyName System.DirectoryServices.AccountManagement
    $AccountPrincipal = New-Object System.DirectoryServices.AccountManagement.PrincipalContext('machine', $Machine)
    $ValidatedAccount = $AccountPrincipal.ValidateCredentials($LocalUsername, $LocalPassword)

    if ($ValidatedAccount) {

        $LocalAccount = "$Machine\$LocalUsername"
        $SecurePassword = $LocalPassword | ConvertTo-SecureString -AsPlainText -Force
        $LocalCredential = New-Object System.Management.Automation.PsCredential($LocalAccount, $SecurePassword)

        <#
        $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($LocalCredential.Password)
        $UnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
        Write-Log "LocaAdminUsername = $($LocalCredential.Username); LocalPassword = $UnsecurePassword" -Color Green
        exit
        #>

        return $LocalCredential

    } else {

        return $False

    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
Function Get-MapDriveList {

    ### Get-PSDrive -PSProvider FileSystem | sort Root | ft -AutoSize
    ### Get-SmbMapping | sort LocalPath
    Get-WmiObject Win32_NetworkConnection  | sort LocalName |  ft @{Name="Drive Letter";Expression="LocalName"}, @{Name="Drive Path";Expression="RemoteName"}

    <#
    $objCurrentDrives = @()
    $objNetwork = New-Object -COM WScript.Network 
   
    $CurrentDrives = $objNetwork.EnumNetworkDrives()

    for ($Index = 0; $Index -lt $CurrentDrives.Length; $Index += 2) {
        $PropTable = [ordered]@{'DriveLetter'=$CurrentDrives.Item($Index); 'DrivePath'=$CurrentDrives.Item($Index + 1)}
        $objCurrentDrives += New-Object -TypeName PSObject -Property $PropTable
    }

    return ($objCurrentDrives | sort DriveLetter)
    #>

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-PresentDevices {

    $ExcludedDevices = "HIDClass", "Net", "Processor", "Software*", "System", "USB", "Volume"
    $PresentDevices =  Get-PnpDevice -PresentOnly | ? { $_.Class -notin $ExcludedDevices } | Sort Class 

    Write-Log "List of attached or embedded devices:"
    $PresentDevices | ft Name, Manufacturer, Class, Caption, Status, InstanceID -AutoSize


    # Enumerate attached printers
    $PrinterList = @()
    $Printers = $PresentDevices | ? { $_.Class -eq "PrintQueue" }

    $Printers | % {

        $PrinterInfo = Get-Printer -Full -Name $_.Name

        $PrinterProperties = [ordered]@{
            Name = $_.Name
            Manufacturer = $_.Manufacturer
            Description = $_.Description
            DeviceID = ($_.DeviceID).split('{}')[1]
            DriverName = $PrinterInfo.DriverName
            PortName = $PrinterInfo.PortName
            ShareName = $PrinterInfo.ShareName
        }

        $PrinterList += New-Object -TypeName PSObject -Property $PrinterProperties
    }

    Write-Log "List of attached printers:"
    $PrinterList | sort Name | ft *


    # Enumerate display adapters
    Write-Log "List of physical or virtual display adapters:"
    Get-WmiObject -Class Win32_VideoController | ft Name, Description, Status, Current*Resolution


    # Enumerate attached monitors
    if (!Is-Admin) { return }

    $MonitorInfo = @()

    $Monitors = Get-CimInstance -Namespace root\wmi -ClassName wmimonitorid

    foreach ($Monitor in $Monitors) {

        $MonitorProperties = [ordered]@{
            ModelName = ($Monitor.UserFriendlyName -notmatch '^0$' | foreach {[char]$_}) -join ""
            SerialNumber = ($Monitor.SerialNumberID -notmatch '^0$' | foreach {[char]$_}) -join ""
            ProductID = ($Monitor.ProductCodeID -notmatch '^0$' | foreach {[char]$_}) -join ""
            Manufacturer = ($Monitor.ManufacturerName -notmatch '^0$' | foreach {[char]$_}) -join ""
        }

        $MonthofManufacture = $($Monitor.WeekOfManufacture | % { $Month = [math]::Ceiling(($_/52)*12) ; [cultureinfo]::InvariantCulture.DateTimeFormat.GetMonthName($Month) })
        $ManufactureDate = $MonthofManufacture + " " + $Monitor.YearofManufacture        $MonitorProperties.Add("ManufactureDate", $ManufactureDate)

        $PrefixID = $MonitorProperties.Manufacturer + $MonitorProperties.ProductID + $MonitorProperties.SerialNumber
        $MonitorProperties.Add("PrefixID", $PrefixID)
        $MonitorInfo += [PSCustomObject]$MonitorProperties

    }
    
    Write-Log "List of attached monitor displays:"
    $MonitorInfo | sort ModelName | ft *

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-RegValue ($RegKey, $RegName) {

    ### METHOD 1
    ### $RegValue = Get-ItemProperty -Path $RegKey -Name $RegName -ErrorAction SilentlyContinue
    ### return $RegValue

    ### METHOD 2
    $RegKey = $RegKey -replace ":","" 
    $RegValue = reg.exe query $RegKey /v $RegName
    return ($RegValue.Split(" ",[StringSplitOptions]'RemoveEmptyEntries')[3])

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SessionInfo ($Machine) {

    $IPAddress = (Test-Connection -ComputerName $Machine -Count 1).IPV4Address.IPAddressToString
    $DNSName = (Resolve-DnsName -Name $Machine | ? { $_.IPAddress -eq $IPAddress }).Name   ### ([System.Net.DNS]::GetHostEntry($Machine)).Hostname

    $Subnet = Get-Subnet $Machine

    $SystemInfo = Get-SystemInfo $Machine
    $OSFullName = $SystemInfo.OSVersion.OSFullName

    $CurrentUser = Get-CurrentUser
    if ([bool]$CurrentUser) { $CurrentUserName = $CurrentUser.Username }    $OfflineFiles = if ([bool](Get-ChildItem -Path C:\Windows\CSC\*\namespace\*).Count) { "Enabled" } else { "Disabled" }
    $SessionInfo = [PSCustomObject][ordered]@{
        HostName = $Machine
        DNSName = $DNSName
        IPAddress = $IPAddress
        Subnet = if ([bool]$Subnet) { $Subnet } else { "UNKNOWN" }
        Manufacturer = $SystemInfo.Manufacturer
        Model = $SystemInfo.Model
        BIOS = $SystemInfo.BIOS
        SerialNumber = $SystemInfo.SerialNumber
        OSFullName = $SystemInfo.OSFullName
        OSUpgradeDate = $SystemInfo.OSUpgradeDate
        LastBootTime = $SystemInfo.BootTime
        DomainUserName = "$Domain\$CurrentUserName"
        CurrentUserName = $CurrentUserName
        OfflineFiles = $OfflineFiles
        CurrentOU = ""
        ComputerGroups = ""
        UserGroups = ""
    }
    return $SessionInfo}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SystemInfo ($Machine) {  

    $SysInfo = if ($Machine.ToUpper() -eq $env:COMPUTERNAME.ToUpper()) { Get-ComputerInfo } else { Invoke-Command -ComputerName $Machine -ScriptBlock { Get-ComputerInfo } }

    $ReturnObject = [PSCustomObject][ordered]@{
        Manufacturer = $SysInfo.CsManufacturer
        Model = $SysInfo.CsModel
        BIOS = "$($SysInfo.BiosSMBIOSBIOSVersion) ($($SysInfo.BiosReleaseDate))"
        SerialNumber = $SysInfo.BiosSeralNumber
        WindowsEdition = $SysInfo.WindowsProductName
        OSVersion = $SysInfo.WindowsVersion
        OSBuild = $SysInfo.OSVersion
        OSFullName = "$($SysInfo.WindowsProductName) version $($SysInfo.WindowsVersion) (build $($SysInfo.OSVersion))"
        OSUpgradeDate = $SysInfo.OSInstallDate
        BootTime = $SysInfo.OSLastBootUpTime
    }    return $ReturnObject
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-Subnet($Machine) {

    try {
        $NetworkAdapters = Get-CimInstance -Namespace "root\cimv2" -Class Win32_NetworkAdapterConfiguration -ComputerName $Machine -OperationTimeoutSec 30 `
             -Property * -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | ? {($_.IPEnabled -eq "True") -and ($_.DefaultIPGateway -ne $Null)}

        $NetworkAdapters | % {
 
           # Compute the Subnet (Network ID) from the IP Address and Subnet Mask
           $IPAddress = @($_.IPAddress)[0]
           $IPAddress_Octets = $IPAddress -split "\."              # Split up IP Address into array of 4 octets
           $SubnetMask_Octets = @($_.IPSubnet)[0] -split "\."      # Do the same for the subnet mask
           $Subnet_Octets = @{}                                    # Initialize hashtable for the subnet

           for ($i=0; $i -le 3; $i++) {                            # Do binary-and on all octets
               [int32]$Subnet_Octets[$i] = [int32]$IPAddress_Octets[$i] -band [int32]$SubnetMask_Octets[$i]
               $Subnet_NetworkID += ($Subnet_Octets[$i]).ToString() + "."  # Concatenate the result back into dotted-notation
           }

           $Subnet_NetworkID = $Subnet_NetworkID -replace ".$"             # Strip off last dot (artifact of last command)

        }

    }

   catch { $Subnet_NetworkID = "OFFLINE" }

   return $Subnet_NetworkID

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Is-Admin {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Is-Laptop {

    $Enclosure = Get-WmiObject Win32_SystemEnclosure
    $ChassisType = $Enclosure.ChassisTypes[0]
    $ChassisTypes_Laptop = 8, 9, 10, 11, 14  # 8=Portable, 9=Laptop, 10=Notebook, 11=Handheld, 14=Sub-Notebook

    $System = Get-WmiObject Win32_ComputerSystem

    if (($ChassisTypes_Laptop -contains $ChassisType) -or ($System.Model -like "Surface*")) {

        Write-Log "Known Laptop Chassis Types = $ChassisTypes_Laptop; Detected ChassisType = $ChassisType; Detected System Model = $($System.Model)"
	    return $True

    } else {

    	return $False
    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
Function Map-HomeFolder ($Username) {

    $HomeDriveLetter = "H"
    $HomeDrive = Get-PSDrive -Name $HomeDriveLetter -ErrorAction SilentlyContinue 
    $HomeFolder = ([adsisearcher]"(&(objectClass=user)(samaccountname=$Username))").FindOne().Properties['HomeDirectory']

    if ( (!([bool]$HomeDrive)) -or ($HomeDrive.DisplayRoot -ne $HomeFolder)) { 

        try {

            Remove-PSDrive -Name $HomeDriveLetter -Force -ErrorAction SilentlyContinue   # this handles scenario if H: is already mapped but not to the correct home folder
            New-PSDrive -Name $HomeDriveLetter -PSProvider FileSystem -Root $HomeFolder -Scope Global -Persist -ErrorAction SilentlyContinue | Out-Null
            $NewHomeFolder = (Get-PSDrive -Name $HomeDriveLetter -ErrorAction SilentlyContinue).DisplayRoot
            Write-Log "Drive Letter [$HomeDriveLetter`:\] is now mapped to : $NewHomeFolder"

            return $True
        }
        catch {

            Error-Handler "Unable to map [$HomeDriveLetter`:\] to : $HomeFolder" $DontExitonError
            return $False

        }

    } else {

        Write-Log "Drive Letter [$HomeDriveLetter`:\] is already mapped to : $HomeFolder"
        return $False

    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Map-NetworkDrive ($DriveLetter, $NetworkPath) {

    $Timer = [diagnostics.stopwatch]::StartNew()

    $MapResult = $False

	$DriveLetter = $DriveLetter.ToUpper()
    $NetworkPath = $NetworkPath.ToLower()

    # Append : if drive letter does not end in one
    if ($DriveLetter.Substring($DriveLetter.Length - 1) -ne ":") { $DriveLetter += ":" }

    Write-Log "Attempting to map [$DriveLetter] to network share [$NetworkPath]"

    $objNetwork = New-Object -Com WScript.Network

    try {
        $objNetwork.RemoveNetworkDrive($DriveLetter, $True, $True)  # Additional parameters is to force remove mapping from user profile
        Write-Log "--- Deleted existing drive [$DriveLetter]"
    }
    catch {
        Write-Log "--- [$DriveLetter] currently does not exist"
    }


    try {
        Test-Path -Path $NetworkPath -PathType Container

        Write-Log "--- Successfully found network share [$NetworkPath]"

        try {
            $objNetwork.MapNetworkDrive($DriveLetter, $NetworkPath, $False)  # False means do not store mapping in user profile; True means it is stored in profile

            $Timer.Stop()

     		Write-Log "*** Successfully mapped [$DriveLetter] to network share [$NetworkPath] (execution time: $($Timer.Elapsed) seconds)"
            $MapResult = $True

        }
        catch {
            $Timer.Stop()
            Error-Handler "*** FAIL: Unable to map [$DriveLetter] to network share [$NetworkPath] (execution time: $($Timer.Elapsed) seconds)" $NoExitonError
        }
    }

    catch {
        Error-Handler "*** FAIL: Unable to find network share [$NetworkPath]" $NoExitonError
    }

    return $MapResult

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Map-SharedFolders {

    param (
        [string]$SQLServer,
        [string]$SQLDBName
    )

    Write-Log "Executing SQL database lookup of shared network drive mappings based on AD domain group membership"
    Write-Log "Connecting to Database Instance [$SQLDBName] on Server [$SQLServer]"

    $GroupList = $Script:UserGroups.Split(",").Trim()

    $MapResult = $False

    $Timer = [diagnostics.stopwatch]::StartNew()

    foreach ($Group in $GroupList) {

        ### if ($DebugEnable) { $Group = "DET-ADM-01" }

        $SQLQuery =
@"
SELECT DISTINCT *
FROM dbo.NYULH_SharedDrives  NYULH_SharedDrives
WHERE GroupName = '$Group'
ORDER BY DriveLetter ASC
"@

        $DriveList = Exec-SQLQuery -SQLServer $SQLServer -SQLDBName $SQLDBName -SQLAccount $DBUserAccount -SQLQuery $SQLQuery

        if ([bool]($DriveList)) {
            Write-Log "Database lookup query for group [$Group] returned [$($DriveList.Count)] records"
            foreach ($Drive in $DriveList) {
                $MapResult = Map-NetworkDrive $Drive.DriveLetter $Drive.DrivePath
            }
        }

    }

    $Timer.Stop()

    Write-Log "SQL Query against all groups was completed in $($Timer.Elapsed) seconds"

    return $MapResult

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function QueryLDAP-ADGroups ($FilterString, $Category) {

    $ADObject = QueryLDAP-ADObject $FilterString $Category

    if ([bool]$ADObject) {
        $CanonicalGroups = $ADObject.memberof | % { ($_ -split ",")[0] -replace "CN=","" -replace "\\","" } | sort

        if ((Measure-Object -InputObject $CanonicalGroups).Count -gt 0) {
            $Result = [string]::Join(", ", $CanonicalGroups)
        } else {
            $Result = "[NONE_FOUND]"
        }

    } else {
        $Result = "[LDAP_QUERY_ERROR]"
    }

    return $Result

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function QueryLDAP-ADObject ($Filter, $Category, $Credential=$Script:ServiceCredential) {

    switch ($Category) {
        "User" { $SearchFilter = "(&(objectCategory=User)(samAccountName=$Filter))" }
        "Group" { $SearchFilter = "(&(objectCategory=Group)(samAccountName=$Filter))" }
        "Computer" { $SearchFilter = "(&(objectCategory=Computer)(samAccountName=$Filter$))" }  # SAM Name requires terminating '$' for a computer
        "OU" { $SearchFilter = "(&(objectCategory=OrganizationalUnit)(name=$Filter))" }
        default { return $False }
    }

   
    # Decrypt the password, it must be passed as cleartext for LDAP queries
    $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Credential.Password)
    $UnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
    ### Write-Log "Username = $($Credential.Username), Unsecure Password = $UnsecurePassword" -Color Green


    $Searcher = New-Object System.DirectoryServices.DirectorySearcher

    $Domain = (New-Object System.DirectoryServices.DirectoryEntry).DistinguishedName # should return DC=nyumc,DC=org
    $DomainPath = "LDAP://$Domain"
    $Searcher.SearchRoot = New-Object System.DirectoryServices.DirectoryEntry ($DomainPath, $Credential.Username, $UnsecurePassword)
    $Searcher.PageSize = 1000
    $Searcher.PropertiesToLoad.Add("Name")
    $Searcher.Filter = $SearchFilter
    $Searcher.SearchScope = "Subtree"
    ### $Searcher.Sort = New-Object System.DirectoryServices.SortOption

    ### Write-Log "LDAP Domain Root = $DomainPath"
    ### Write-Log "LDAP Search Filter = $SearchFilter"

    try { $Result = $Searcher.FindOne().GetDirectoryEntry() }
    catch { $Result = $False }
 
    $Searcher.Dispose()

    return $Result

}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Run-ScheduledTask {

    param (
        [string]$TaskName,
        [string]$TaskPath,
        [string]$TaskSettings
    )

    if (!([bool](Get-ScheduledTask -TaskName $TaskName))) {  # Create the task if it doesn't exist

        if (Test-Path -Path $TaskSettings) {
            
            Write-Log "Creating scheduled task [$TaskName]"
            Create-CustomScheduledTask -TaskName $TaskName -TaskXMLFilePath $TaskSettings

        } else {

            Write-Log "Cannot create scheduled task [$TaskName], check access to inventory task file : $TaskSettings"

        }
    }


    if ([bool](Get-ScheduledTask -TaskName $TaskName)) {
 
        Write-Log "Starting scheduled task [$TaskName]"
        Start-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
 
    } else {
 
        Error-Handler "Scheduled task [$TaskName] failed to start" $DontExitonError
 
    }

}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Run-WindowsUpdateScan {

    # http://wuauclt.info/usoclient.asp
    # https://omgdebugging.com/2017/10/09/command-line-equivalent-of-wuauclt-in-windows-10-windows-server-2016
    # https://www.urtech.ca/2018/11/usoclient-documentation-switches
    # https://www.urtech.ca/2018/11/solved-easily-script-windows-10-to-download-install-and-restart-for-windows-updates

    Write-Log "Running Windows Update scan"
    ### (New-Object -ComObject Microsoft.Update.AutoUpdate).DetectNow()
    & "$env:SYSTEMROOT\system32\usoclient.exe" StartScan

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Set-FolderRedirection ($NetworkState, $Table) {

    $Results = $False

    # Setup pointers to the Quick Access sidebar.  We will scan icons that point to redirected folders
    # and change the paths to the network or local folder path depending on online/offline state of user
    $objQuickAccess = New-Object -ComObject shell.application
    $QuickAccessIcons = $objQuickAccess.Namespace("shell:::{679f85cb-0220-4080-b29b-5540cc05aab6}").Items()

    Write-Log "List of QuickAccess Icons:"
    ### $QuickAccessIcons | sort Name | ft Name, Path, Is*

    Write-Log "List of Resolved Paths in Personalizaton Table:"
    ### $Table | fl
   
    $RegKeyPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"
    Write-Log "Folders are in [$RegKeyPath]"

    Write-Log ("-" * 80)  # insert line separator of 80 dashes
    
    foreach ($Folder in $Table) {

        $QuickAccessShortcutName = $Folder.ShortcutName
        $FolderName = $Folder.RegistryName

        switch ($NetworkState) {
            "Connected" { $FolderPath = $Folder.NetworkPath }
            "Disconnected" { $FolderPath = $Folder.LocalPath }
        }

        $FolderPathExpanded = [System.Environment]::ExpandEnvironmentVariables($FolderPath)

        Write-Log "Checking [$FolderName] folder ..."

        # DEBUGGING - Verify folderpaths have been resolved correctly
        if ($Script:DebugEnable) {
            $FolderInfo = [PSCustomObject][ordered]@{
                QuickAccessShortcutName = $QuickAccessShortcutName
                FolderName = $FolderName
                FolderPath = $FolderPath
            }
            ### $FolderInfo
        }


        # Create folder if it does not exist
        if (-not(Test-Path -Path $FolderPathExpanded -ErrorAction SilentlyContinue)) {
            try {
                New-Item -Path $FolderPathExpanded -ItemType Directory -ErrorAction SilentlyContinue | Out-Null
                Write-Log ("Folder [$FolderPathExpanded] not found, successfully created")
            }
            catch {
                Write-Log ("Folder [$FolderPathExpanded] not found, error in creating folder, skip to next folder")
                continue 
            }

        }


        # Set registry value property type to ExpandString (REG_EXPAND_SZ) if there is a % symbol in the string
        if ($FolderPath -like "*%*%*") { $PropertyType = "ExpandString" } else { $PropertyType = "String" }


        # Update registry and set the redirected folder locations
        $Results = Set-RegValue $RegKeyPath $FolderName $FolderPath $PropertyType
        switch ($Results) {
            $True { 
                Write-Log ("Registry setting [$FolderName] changed to [$FolderPath]")
            }
            $False {
                Write-Log ("Registry setting [$FolderName] is already set to [$FolderPath]")
            }
        }


        # Check QuickAccess shortcut list
        if ($QuickAccessShortcutName -eq "[None]") {

            Write-Log "There is no default QuickAccess shortcut associated with the [$Foldername] folder"

        } else {

            foreach ($Icon in $QuickAccessIcons) {
           
                if ($Icon.Name -eq $QuickAccessShortcutName) {

                    if ($Icon.Path -ne $FolderPathExpanded) {
                        
                        Write-Log "Unpinning QuickAccess shortcut [$($Icon.Name)] because path = [$($Icon.Path)]"
                        $Icon.InvokeVerb("unpinhome")
                        ### $objQuickAccess.Namespace("$CurrentValue").Self.InvokeVerb(“unpinhome”)

                        Write-Log "Repinning QuickAccess shortcut [$($Icon.Name)] to point to [$FolderPathExpanded]"
                        $Icon.InvokeVerb("pintohome")
                        ### $objQuickAccess.Namespace("$FolderPathExpanded").Self.InvokeVerb(“pintohome”)

                        $Results = $True

                    } else {

                        Write-Log "QuickAccess shortcut [$($Icon.Name)] already points to [$FolderPathExpanded] - no change necessary"

                    }
                }
            }

        }

        Write-Log ("-" * 80)  # insert line separator of 80 dashes

    }

    return $Results

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Set-Personalization ($Personalization) {

    $Results = $False

    # Set path to lock screen image
    $LockScreenImage = $Personalization.LockScreenImage
    if (Test-Path -Path $LockScreenImage) {
        Write-Log "Checking lock screen = [$LockScreenImage]"
        $Results = Set-RegValue "HKLM:\Software\Policies\Microsoft\Windows\Personalization" "LockScreenImage" $LockScreenImage "String"
        if (!$Results) { Write-Log "... already set to correct path, nothing was changed" }
    } else {
        Write-Log "Cannot find path, registry will not be changed!"
    }



    # Set path to background wallpaper
    $WallpaperImage = $Personalization.WallpaperImage
    if (Test-Path -Path $WallpaperImage) {
        Write-Log "Checking wallpaper = [$WallpaperImage]"
        $Results = Set-RegValue "HKCU:\Control Panel\Desktop" "Wallpaper" $WallpaperImage "String"
        if (!$Results) { Write-Log "... already set to correct path, nothing was changed" }
    } else {
        Write-Log "Cannot find path, registry will not be changed!"
    }

    
    # Set path to screensaverfolder
    $ScreensaverPath = $Personalization.ScreensaverPath -replace " |`t|`r|`n",""
    Write-Log "Checking screensaver path (not logged -- it is in encrypted Base64 format)"
    $Results = Set-RegValue "HKCU:\Software\Microsoft\Windows Photo Viewer\Slideshow\Screensaver" "EncryptedPIDL" $ScreensaverPath "String"
    if (!$Results) { Write-Log "... already set to correct path, nothing was changed" }


    return $Results

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Set-RegValue ($Key, $Name, $NewValue, $Type) {

    $CurrentValue = (Get-ItemProperty -Path $Key -Name $Name -ErrorAction SilentlyContinue).$Name

    if (!($CurrentValue)) {

        if (!(Get-Item -Path $Key -ErrorAction SilentlyContinue)) { 
        
            Write-Log "Create new registry key [$Key]"
            New-Item -Path $Key -Credential $Script:LocalCredential -ErrorAction SilentlyContinue | Out-Null
        }

        Write-Log "Create new registry setting [$Key!$Name] with value [$NewValue]"
        New-ItemProperty -Path $Key -Name $Name -Value $NewValue -PropertyType $Type -Force -ErrorAction SilentlyContinue | Out-Null

    } else {

        ### Write-Log "Read current registry value: [$CurrentValue]"

        if ($CurrentValue -ne $NewValue) {

            Write-Log "Change registry setting [$Key!$Name] from [$CurrentValue] to [$NewValue]"
            Set-ItemProperty -Path $Key -Name $Name -Value $NewValue -Force -ErrorAction SilentlyContinue | Out-Null

        } else {

            return $False

        }

    }

    return $True

}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Write-Log {

    [cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]    param(        [string]$Message,        [string]$LogFile = $Script:TranscriptLog,        [string]$Color,        [string]$CallingFunction,        [string]$LineNumber    )

    $ScriptName = $Script:Scriptname.ToUpper()
    if (!$CallingFunction) { $CallingFunction = ((Get-Variable MyInvocation -Scope 1).Value.MyCommand.Name).ToUpper() } #-replace ".ps1","" 
    if (!$LineNumber) { $LineNumber = $MyInvocation.ScriptLineNumber }

    $Now = Get-Date -format "yyyy-MM-dd_HH:mm:ss"

    if (($CallingFunction -eq $ScriptName) -or ($CallingFunction -like "ALTIRISSCRIPT*")) {
        $LogMsg = "${Now}: [Line:$LineNumber (Main Code Section)] ${Message}"
    } else {
        $LogMsg = "${Now}: [Line:$LineNumber (Function '$CallingFunction')] ${Message}"
    }

    if ($Color) { 
        Write-Host $LogMsg -ForegroundColor $Color
    } else {
        Write-Host $LogMsg 
    }

    if (Test-Path $LogFile -ErrorAction SilentlyContinue) { Add-Content -Path $LogFile -Value $LogMsg -ErrorAction SilentlyContinue }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Write-StopScriptTime ($StartTime, $TranscriptLog, $NetworkLogFolder) {

    $StopTime = Get-Date
    $Duration = $StopTime - $StartTime
    Write-Log "Script Stop Time : $($StopTime.ToString("MM-dd-yyyy hh:mm:ss tt"))"
    Write-Log "Script executed in $($Duration.Minutes) minutes $($Duration.Seconds) seconds"
    Write-Log "********** SCRIPT ENDS **********"

    $Error.Clear()

    Stop-Transcript -ErrorAction SilentlyContinue | Out-Null

    Start-Sleep -Seconds 5

    # Copy logfile to network share
    if (($Script:VPNConnectionActive) -and (Test-Path -Path $NetworkLogFolder -ErrorAction SilentlyContinue)) { Copy-Item -Path $TranscriptLog -Destination $NetworkLogFolder -Force -ErrorAction SilentlyContinue | Out-Null }
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------


cls

$Error.Clear()


#region Setup and initialization

#COMMENTED OUT 07/28/20 - DO NOT RUN CODE THAT REQUIRES ELEVATION: Validate user has local admin rights
### if (!(Is-Admin)) { Error-Handler "This script requires admin privileges!  Please elevate and re-run the script." $ExitonError }

$Machine = $env:COMPUTERNAME
$Domain = $env:USERDOMAIN
$NetworkLogFolder = "\\shares.nyumc.org\eude\logon\vpn"


# Identify system and user information
$SessionInfo = Get-SessionInfo $Machine

# Define the folder redirection table with values for online and offline locations
# There are 4 values:
#    - QuickAccess shortcut name (Favorite and Templates are not required so they are empty strings)
#    - User Shell Folder registry name
#    - Path to network redirected folder
#    - Path to local redirected folder
$FolderRedirectionTable = @(
    [PSCustomObject]@{ 
        ShortcutName = "Desktop"
        RegistryName = "Desktop"
        NetworkPath = "h:\apps\xp\desktop"
        LocalPath = "%USERPROFILE%\Desktop"
    }
    [PSCustomObject]@{
        ShortcutName = "[None]"
        RegistryName = "Favorites"
        NetworkPath = "h:\apps\ie\favorites"
        LocalPath = "%USERPROFILE%\Favorites"
    }
    [PSCustomObject]@{
        ShortcutName = "Documents"
        RegistryName = "Personal"
        NetworkPath = "h:\Personal"
        LocalPath = "%USERPROFILE%\Documents"
    }
    [PSCustomObject]@{
        ShortcutName = "[None]"
        RegistryName = "Templates"
        NetworkPath = "h:\apps\xp\templates"
        LocalPath = "%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Templates"
    }
)


# Define the personalization table with values for online and offline locations
# There are 3 values:
#    - Path to the Windows lock screen image (what is displayed when machine boots before user logs in)
#    - Path to the background wallpaper image
#    - Path to the screensaver images
$PersonalizationTable = @(

    # First object is for network locations
    [PSCustomObject]@{ 
        LockScreenImage = "\\vsnfs04.nyumc.org\ss-bkg-gpo\win10-defaults\nyumc-lockscreen.jpg"
        WallpaperImage  = "\\vsnfs04.nyumc.org\ss-bkg-gpo\nyulmc-bkgrd.jpg"
        ScreensaverPath = "FAAfWA0aLPAhvlBDiLBzZ/yW7zzDAAAAvQC7r5M7rwAEAAAAAABRAAAAMVNQUzDx
                           JbfvRxoQpfECYIye66w1AAAACgAAAAAfAAAAEgAAAHYAcwBuAGYAcwAwADQALgBu
                           AHkAdQBtAGMALgBvAHIAZwAAAAAAAAAtAAAAMVNQUzqkvd6zN4NDkedEmNoplasR
                           AAAAAwAAAAATAAAAAAAAAAAAAAAtAAAAMVNQU3ND5Qq+Q61PheRp3IYzmG4RAAAA
                           CwAAAAALAAAA//8AAAAAAAAAAAAAAAA5AMMBwVxcdnNuZnMwNC5ueXVtYy5vcmdc
                           c3MtYmtnLWdwbwBNaWNyb3NvZnQgTmV0d29yawAAAgBYADEAAAAAAINIbLYQAFNT
                           LU1DTH4xAABAAAgABADvvqFGun2DSGy2KgAAAAA3AAAAAAEAAAAAAAAAAAAAAAAA
                           AABTAFMALQBNAEMATABvAGcAbwAAABgAAAA="  # Base64-encrypted path points to \\vsnfs04.nyumc.org\ss-bkg-gpo\SS-MCLogo
    }

    # Second object is for local locations
    [PSCustomObject]@{ 
        LockScreenImage = "C:\Windows\AppSenseTools\Wallpaper\nyumc-lockscreen.jpg"  # alternate path = "C:\ProgramData\NYUMC\nyumc-lockscreen.jpg"
        WallpaperImage  = "C:\Windows\AppSenseTools\Wallpaper\NYULMC-bkgrd.jpg" # alternate path = "C:\ProgramData\NYUMC\Screensaver\nyulmc-bkgrd.jpg"
        ScreensaverPath = "FAAfUOBP0CDqOmkQotgIACswMJ0ZAC9DOlwAAAAAAAAAAAAAAAAAAAAAAAAAVgAx
                           AAAAAAD5UJGAEABXaW5kb3dzAEAACQAEAO++c06sJPlQkYAuAAAAXIAHAAAAAwAA
                           AAAAAAAAAAAAAAAAAIKb3gBXAGkAbgBkAG8AdwBzAAAAFgBkADEAAAAAAERQ5KYQ
                           AEFQUFNFTn4xAABMAAkABADvvkRQ1KZGUOKmLgAAADu7AQAAAAYAAAAAAAAAAAAA
                           AAAAAABb+uUAQQBwAHAAUwBlAG4AcwBlAFQAbwBvAGwAcwAAABgAYAAxAAAAAAC1
                           TlVqEABTQ1JFRU5+MQAASAAJAAQA775cTy2Jh09UMS4AAABWuwEAAAADAAAAAAAA
                           AAAAAAAAAAAAAAAAAFMAYwByAGUAZQBuAHMAYQB2AGUAcgAAABgAAAA=" # Based64-encrypted path points to C:\Windows\AppSenseTools\Screensaver
        <#
        ScreensaverPath = "FAAfUOBP0CDqOmkQotgIACswMJ0ZAC9DOlwAAAAAAAAAAAAAAAAAAAAAAAAAYAAx
                           AAAAAACSSuGdEgBQUk9HUkF+MwAASAAJAAQA777wSPldkkrhnS4AAAALBAAAAAAB
                           AAAAAAAAAAAAAAAAAAAApr6sAFAAcgBvAGcAcgBhAG0ARABhAHQAYQAAABgAUAAx
                           AAAAAACRSryiEABOWVVNQwA8AAkABADvvpFKvKKRSryiLgAAAGCjAQAAAAUAAAAA
                           AAAAAAAAAAAAAACrdqsATgBZAFUATQBDAAAAFABgADEAAAAAAJFKvaIQAFNDUkVF
                           Tn4xAABIAAkABADvvpFKvKKRSr2iLgAAAGKjAQAAAAUAAAAAAAAAAAAAAAAAAACN
                           EcgAUwBjAHIAZQBlAG4AcwBhAHYAZQByAAAAGAAAAA==" # Based64-encrypted path points to C:\ProgramData\NYUMC\Screensaver
        #>  
    }

)
#endregion


#region Create transcript log
$LocalTempFolder = "C:\TEMP"
$LogFilename = "$Machine-VPNSTATUS"
$TranscriptLog = "$LocalTempFolder\$LogFilename.log"

# Stop any previously running transcript that may not have closed due to abnormal script termination
try { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null }
catch {}

if (!(Test-Path -Path $LocalTempFolder)) { New-Item -Path $LocalTempFolder -ItemType Directory -ErrorAction SilentlyContinue | Out-Null }
if (Test-Path -Path $TranscriptLog) { Remove-Item -Path $TranscriptLog -Force -ErrorAction SilentlyContinue }

try { Start-Transcript -Path $TranscriptLog -IncludeInvocationHeader -Force }catch { Error-Handler "Unable to start the transcript log: [$TranscriptLog]" $DontExitonError }$StartTime = Get-Date
Write-Log "********** SCRIPT BEGINS **********"
Write-Log "Script Name       : $ScriptName"Write-Log "Script Version    : $ScriptVersion"Write-Log "Script Build      : $ScriptBuild"Write-Log "Script Full Path  : $ScriptFullPath"Write-Log "Script Start Time : $($StartTime.ToString("MM-dd-yyyy hh:mm:ss tt"))"
#endregion#region Evaluate current network state
try {
    $VPNCommand = "C:\Program Files (x86)\F5 VPN\f5fpc.exe"
    if (Test-Path -Path $VPNCommand -ErrorAction SilentlyContinue) {
        $VPNSession = [bool](& "$VPNCommand" -info | Select-String "session established")
    } else {
        $VPNSession =  $False
    }
}
catch{
    $VPNSession = $False
}

try {
    $DomainExists = [adsi]::Exists("LDAP://DC=nyumc,DC=org")
}
catch {
    $DomainExists = $False
}

$VPNConnectionActive = $VPNSession -and $DomainExists

### FOR TESTING ONLY
if ($DebugEnable) { $VPNConnectionActive = $True }

Write-Log "`$VPNSession = $VPNSession"
Write-Log "`$DomainExists = $DomainExists"
Write-Log "`VPNConnectionActive = $VPNConnectionActive"
#endregion

#region Run tasks depending on whether on/off VPN
if ($VPNConnectionActive -and !$RunScriptLocally) { # execute if connected to VPN connection and verify the script is running from the network share

    #region Validate credentials of the NYULH service account 
    $ServiceCredential = Get-AccountCredentials -Filename "\\mscsnyu01.nyumc.org\adbuild\det_builds\scripts\eude\check-vpnstatus-serviceaccount.xml"    if ([bool]$ServiceCredential) {        Write-Log "VALIDATION PASS: The NYULH service account credentials were retrieved"    } else {        Error-Handler "VALIDATION FAIL: The NYULH service account credentials could not be retrieved" $ExitonError    }
    #endregion


    #region Validate computer exists in AD
    $ADComputer = QueryLDAP-ADObject $Machine "Computer"    if ([bool]($ADComputer.Name)) {        Write-Log "VALIDATION PASS: This device [$Machine] was found in the NYUMC.ORG Domain"    } else {        Error-Handler "VALIDATION FAIL: This device [$Machine] was not found in the NYUMC.ORG Domain" $ExitonError    }    #endregion


    #region Validate this computer has an unexpired LAPS password
    if (!(Test-Path -Path "C:\Program Files\LAPS\CSE\AdmPwd.dll")) { Error-Handler "Microsoft LAPS is not installed on this computer" $ExitonError }
    $LocalUser = "mcitadmin"    ### $LocalUserExists = (Get-LocalUser -Name $LocalUser).Enabled
    $LocalUserExists = Get-CimInstance -Query "SELECT Domain,Name FROM Win32_UserAccount WHERE (Domain = '$Machine' AND Name = '$LocalUser')" -ErrorAction SilentlyContinue
    if ([bool]$LocalUserExists) {
        $LocalCredential = Get-LocalCredential -LocalUsername $LocalUser -LocalPassword $($ADComputer."ms-Mcs-AdmPwd")
        if ([bool]$LocalCredential) {            Write-Log "VALIDATION PASS: Credentials for local account [$Localuser] successfully retrieved from AD"        } else {            Error-Handler "VALIDATION FAIL: Credentials for local account [$Localuser] could not be retrieved from AD" $ExitonError        }    }
    #endregion


    #region Validate this is a NYUMC built computer
    $RegValue = Get-RegValue "HKLM:\SOFTWARE\NYUMC\CoreBuild" "Domain"  ### or try "HKCU:\SOFTWARE\NYUMC" ""
    if ($RegValue -eq "NYUMC") { 
        Write-Log "VALIDATION PASS: This device [$Machine] is a NYULH-managed computer"    } else {        Error-Handler "VALIDATION FAIL: This device [$Machine] is not a NYULH-managed computer" $ExitonError
    }    #endregion
    #region Enumerate domain-specific system and user information
    $CurrentOU = Convert-DNtoCN -DistinguishedName ($ADComputer.Path -replace "LDAP://CN=$Machine,","")
    $SessionInfo.CurrentOU = $CurrentOU

    $ComputerGroups = QueryLDAP-ADGroups $Machine "Computer"
    $SessionInfo.ComputerGroups = $ComputerGroups

    $UserGroups = QueryLDAP-ADGroups $SessionInfo.CurrentUserName "User"
    $SessionInfo.UserGroups = $UserGroups    #endregion

    #region Abort script if user and machine does not meet certain group membership restrictions
    $DomainGrouptoCheck = "GPO-WDX-VPN"
    $FoundinGroup = Compare-Object -ReferenceObject $DomainGrouptoCheck -DifferenceObject $($UserGroups -split ", ") -IncludeEqual -ExcludeDifferent -PassThru
    if (!($FoundinGroup)) { 
        Error-Handler "VALIDATION FAIL: User [$($SessionInfo.CurrentUserName)] was not found in a required domain group [$($DomainGrouptoCheck -join ", " )] to execute this script" $ExitonError 
    } else {
        Write-Log "VALIDATION PASS: User [$($SessionInfo.CurrentUserName)] was found in a required domain group [$($DomainGrouptoCheck -join ", " )] to execute this script"
    }


    $DomainGrouptoCheck = "GPO-WDX-VPN", "GPO_EUDE_RRT_WIN10"
    $FoundinGroup = Compare-Object -ReferenceObject $DomainGrouptoCheck -DifferenceObject $($ComputerGroups -split ", ") -IncludeEqual -ExcludeDifferent -PassThru
    if (!($FoundinGroup)) {
        Error-Handler "VALIDATION FAIL: Computer [$Machine] was not found in a required domain group [$($DomainGrouptoCheck -join ", " )] to execute this script" $ExitonError
    } else {
        Write-Log "VALIDATION PASS: Computer [$Machine] was found in a required domain group [$($DomainGrouptoCheck -join ", " )] to execute this script"
    }


    $DomainGrouptoCheck = "appsense.disableredirection"
    $FoundinGroup = Compare-Object -ReferenceObject $DomainGrouptoCheck -DifferenceObject $($ComputerGroups -split ", ") -IncludeEqual -ExcludeDifferent -PassThru
    if ($FoundinGroup -and !$DebugEnable) { Error-Handler "VALIDATION FAIL: Computer [$Machine] was found in a restricted domain group [$($DomainGrouptoCheck -join ", " )] that should not execute this script" $ExitonError }
    #endregion
    #region Write out system and user information (including domain specific attributes) to log    Write-Log "Session Information:"
    $SessionInfo
    Get-PresentDevices
    #endregion


    #region Map user's network home folder to H: drive
    # This registry setting will allow the script to 'see' UNC paths if running in SYSTEM context
    ### Set-RegValue "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" "EnableLinkedConnections" 1 "DWORD" | Out-Null
    $HomeFolderMapped = Map-HomeFolder -Username $SessionInfo.CurrentUserName
    #endregion


    #region Map shared network folders if any found 
    if ($DebugEnable) {
        $SQLServer = "SQLDDB1207.NYUMC.ORG\DB07"  ### ,1443 (port?)
        $SQLDBName = "dbEUDEDEV01"
    } else {
        $SQLServer = "SQLPDB5603.NYUMC.ORG\DB03"  ### ,63501 (port?)
        $SQLDBName = "dbEUDEPROD01"
    }

    $SharedFoldersMapped = Map-SharedFolders -SQLServer $SQLServer -SQLDBName $SQLDBName

    Write-Log "List of currently mapped drives:"
    Get-MapDriveList
    #endregion
    

    #region Set folder redirection, screensaver and wallpaper paths to network paths
    $RedirectionChanged = Set-FolderRedirection -NetworkState "Connected" -Table $FolderRedirectionTable
    $PersonalizeChanged = Set-Personalization $PersonalizationTable[0]

    Write-Log "RedirectionChanged = $RedirectionChanged"
    Write-Log "PersonalizeChanged = $PersonalizeChanged"

    # Force restart of Explorer so that desktop is refreshed and all special folders know new locations        
    if ($PersonalizeChanged -or $RedirectionChanged -or $HomeFolderMapped) {
        Write-Log "Either personalization or folder redirection settings were changed or the home drive was mapped so desktop will be refreshed ..."
        Start-Sleep -Seconds 5
        ### & "rundll32.exe" user32.dll, UpdatePerUserSystemParameters, 1, True
        Stop-Process -Name "explorer"
        Start-Sleep -Seconds 5
    } else {
        Write-Log "Nothing was changed so desktop will not be refreshed"
    }
 
    # Remove the registry setting that allowed SYSTEM account to access UNC paths
    ### Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLinkedConnections" -Force -ErrorAction SilentlyContinue 
    #>
    #endregion


    #region COMMENTED OUT 07/28/20 - DO NOT RUN CODE THAT REQUIRES ELEVATION: Validate activation for Windows 10 and Office 2016
    <#
    $KMSService = Get-ActivationServer -KMSServer "kms.nyumc.org" -KMSServerPort "1688"

    if ([bool]$KMSService) {

        # Activate Windows 10 if necessary
        $Parameters = @{
            ProductName = "Windows 10"
            ProductAppId = "55c92734-d682-4d71-983e-d6ec3f16059f"
            ProductKeytoCheck = $KMSService.OA3xOriginalProductKey
            ### $ProductKey = "NKJFK-GPHP7-G8C3J-P6JXR-HQRJR"  # technet.microsoft.com/en-us/library/jj612867.aspx?lc=1033
            ProductKey= "NPPR9-FWDCX-D2C8J-H872K-2YT43" # https://docs.microsoft.com/en-us/windows-server/get-started/kmsclientkeys
            ActivationScript = "c:\windows\system32\slmgr.vbs"
            ScriptBlocktoRun = @"
Write-Log "`t- Installing product key ..."
Start-Process cscript.exe -ArgumentList "//b //nologo $ActivationScript /ipk $ProductKey" -Credential $LocalCredential -WindowStyle Hidden -Verb RunAs -PassThru | ft 
Start-Sleep -Seconds 5
Write-Log "`t- Activating license ..."
Start-Process cscript.exe -ArgumentList "//b //nologo $ActivationScript /ato" -Credential $LocalCredential -WindowStyle Hidden -Verb RunAs -PassThru | ft
"@
        }

        Activate-Product @Parameters -Credential $LocalCredential

        ### exit

        # Activate Office 2016 if necessary
        $OfficePath = (Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Microsoft\Office\ClickToRun\Configuration" -Name "InstallationPath")
        $Parameters = @{
            ProductName = "Office 2016"
            ProductAppId = "0ff1ce15-a989-479d-af46-f275c6370663"
            ProductKeytoCheck = ""
            ProductKey= "XQNVK-8JYDB-WJ9W3-YJ8YR-WFG99"
            ActivationScript = "$OfficePath\Office16\ospp.vbs"
            Credential = $LocalCredential
            ScriptBlocktoRun = @"
if (!($($LicenseInfo.PartialProductKey))) {
    Write-Log "`t- Installing product key for Office 2016"
    Start-Process $env:SYSTEMROOT\system32\cscript.exe -ArgumentList "//b //nologo $ActivationScript /inpkey:$ProductKey_Office2016" -Credential $LocalCredential -WindowStyle Hidden -Verb RunAs -PassThru | ft
}
start-sleep -Seconds 5
if ($ProductKey_Office2016.Substring($ProductKey_Office2016.Length - 5) -eq $($LicenseInfo.PartialProductKey)) {
    Write-Log "`t- Executing activation script: $ActivationScript"
    Start-Process $env:SYSTEMROOT\system32\cscript.exe -ArgumentList "//b //nologo $ActivationScript /act" -Credential $LocalCredential -WindowStyle Hidden -Verb RunAs -PassThru | ft
} else {
    Write-Log "`t- Cannot activate this edition of Office 2016"
}
"@
        }

        Activate-Product @Parameters -Credential $LocalCredential

    } else {

        Error-Handler "Cannot connect to Windows Key Management Server [kms.nyumc.org]"

    }

    exit
    #>
    #endregion


    #region COMMENTED OUT 07/28/20 - DO NOT RUN CODE THAT REQUIRES ELEVATION: Run EUDE_INVENTORY scheduled task
    <#
    $TaskName = "EUDE_INVENTORY"
    $TaskPath = "$env:LOGONSERVER\netlogon\Win10\Computer"
    $TaskSettings = "$TaskPath\$TaskName.xml"

    # This registry setting will allow the script to 'see' UNC paths if running in SYSTEM context
    ### Set-RegValue "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" "EnableLinkedConnections" 1 "DWORD" | Out-Null

    Start-Sleep -Seconds 5

    Run-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath -TaskSettings $TaskSettings

    Start-Sleep -Seconds 5

    # Remove the registry setting that allowed SYSTEM account to access UNC paths
    ### Remove-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLinkedConnections" -Force -Credential $LocalCredential -ErrorAction SilentlyContinue 
    #>
    #endregion


    #region COMMENTED OUT 07/28/20 - DO NOT RUN CODE THAT REQUIRES ELEVATION: Run Windows Update scan
    ### Run-WindowsUpdateScan
    #endregion


} else { # execute if disconnected from VPN connection

    if ($DomainExists) {

        #region FAIL-SAFE ABORT: if the script inadvertently runs when the machine is on the domain and there is no VPN connection
        Write-Log "Script should not run if computer [$Machine] is logged into the domain and there is no VPN connection"
        Remove-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" -Name "CHECK-VPNSTATUS" -Force -ErrorAction SilentlyContinue | Out-Null  # clean up if a machine inadvertently is stamped to run the script
        #endregion

    } else {

        #region Write out system and user info (excluding domain-specific attributes) to log        Write-Log "Session Information:"
        $SessionInfo

        Get-PresentDevices
        #endregion


        #region Reset folder redirection, screensaver and wallpaper paths back to local paths
        $RedirectionChanged = Set-FolderRedirection -NetworkState "Disconnected" -Table $FolderRedirectionTable
        $PersonalizeChanged = Set-Personalization $PersonalizationTable[1]

        Write-Log "RedirectionChanged = $RedirectionChanged"
        Write-Log "PersonalizeChanged = $PersonalizeChanged"

        # Force restart of Explorer so that desktop is refreshed and all special folders know new locations        
        if ($PersonalizeChanged -or $RedirectionChanged) {
            Write-Log "Either personalization or folder redirection settings were changed so desktop will be refreshed ..."
            Start-Sleep -Seconds 5
            ### & "rundll32.exe" user32.dll, UpdatePerUserSystemParameters, 1, True
            Stop-Process -Name "explorer"
            Start-Sleep -Seconds 5
        } else {
            Write-Log "Nothing was changed so desktop will not be refreshed"
        }

        Write-Log "List of mapped drives:"
        Get-MapDriveList
        #endregion

    }

}
#endregion


#region Enable script to run at user logon (when disconnected)
if ($VPNConnectionActive) {

    $LocalScriptFolder = "C:\Scripts"
    if (!(Test-Path -Path $LocalScriptFolder)) { New-Item -Path $LocalScriptFolder }

    if (Test-Path -Path $LocalScriptFolder) {

        # Sync the local copy of the script over VPN connection    
        Write-Log "Copying network copy of script [$ScriptFullPath] to local folder cache [$LocalScriptFolder]"
        Copy-Item -Path $ScriptFullPath -Destination $LocalScriptFolder -Force -ErrorAction SilentlyContinue | Out-Null

        $CMDScriptFile = $ScriptUNCPath + "check-vpnstatus.cmd"
        Copy-Item -Path $CMDScriptFile -Destination $LocalScriptFolder -Force -ErrorAction SilentlyContinue | Out-Null

        if ($DebugEnable) {   
            $RegValue = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -executionpolicy bypass -nologo -noprofile -windowstyle maximized –file ""$LocalScriptFolder\$ScriptName"""
        } else {
            $RegValue = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -executionpolicy bypass -nologo -noprofile -windowstyle hidden –file ""$LocalScriptFolder\$ScriptName"""
        }

        $RegKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
        Write-Log "Setting up registry under [$RegKey] to run local copy of script [$LocalScriptFolder\$ScriptName] when disconnected"
        Set-RegValue -Key $RegKey -Name "CHECK-VPNSTATUS" -NewValue $RegValue -Type "String" | Out-Null

    } else {

        Error-Handler "Unable to create local script folder [$LocalScriptFolder]" $DontExitonError

    }

}
#endregion


#region Stop the transcript, save log to network folder
Write-StopScriptTime $StartTime $TranscriptLog $NetworkLogFolder

# Save session data to CSV in the network log folder
Export-SessionInfotoCSV -Object $SessionInfo -Folder $NetworkLogFolder -Filename "VPNSTATS.CSV"


#COMMENTED OUT 07/28/20 - DO NOT RUN CODE THAT REQUIRES ELEVATION: Write status to Windows Event Log
<#
$Transcript = Get-Content -Path $TranscriptLog
$EventLogName = "EUDE"
try {
    New-EventLog -LogName $EventLogName -Source $ScriptName  -ErrorAction SilentlyContinue 
    Write-EventLog -LogName $EventLogName -Source $ScriptName -EntryType Information -EventId 2216 -Message (Out-String -InputObject $Transcript)
}
catch {
    Write-Host "Unable to save transcript to the [$EventLogName] Windows Event log" -ForegroundColor Red
}
#>
#endregion
