﻿#==========================================================================================================================================
# Program			: UNINSTALL-ALTIRIS.PS1
# Version			: 1.0.0
# Date				: May 11 2020
# Author			: Roland Thomas
# Team				: MCIT / End User Device Engineering
#
# This script connects to a remote computer and uninstalls ...
#
# 06-04-20 (v1.0.0) : First release
[cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]param(    [string[]]$Computers = $Null,    [string]$File = $Null)

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------


cls


#region Parse arguments
if ($File -like '*.TXT') {    if (Test-Path -Path $File) {        $Computers = Get-Content -Path $File -ErrorAction SilentlyContinue | Sort | % { $_.toupper().trim() } | ? { $_.trim() -ne ""  } | Set-Content $File -PassThru # sort and trim whitespace and blank lines from textfile    } else {        Write-Warning "Unable to open file: $File" ; exit    }
} else {

    if (!([bool]$Computers)) { Write-Warning "Computer name was not provided, please run the script again." ; exit }

}
#endregion


foreach ($Computer in $Computers) {

    $StartTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"

    $Computer = $Computer.ToUpper()
    $Online = Test-Connection -ComputerName $Computer -Count 1 -Quiet    if (!($Online)) {        Write-Host "$StartTime - $Computer`t: Cannot ping machine - it may be offline" -ForegroundColor Yellow
    } else {

        Write-Host "$StartTime - $Computer`t: Running uninstaller ... " -NoNewline -ForegroundColor White

        #region Command block to run on remote machine 
        $Results = Invoke-Command -ComputerName $Computer -ErrorAction SilentlyContinue -ScriptBlock { 

            $Error.Clear()

            $Uninstaller = "C:\Program Files\Altiris\Altiris Agent\AeXAgentUtil.exe" 
            $Arguments = "/uninstall"
            $Service = "AeXNSClient"
            $TimeLimit = 600

            if (!(Test-Path -Path $Uninstaller -ErrorAction SilentlyContinue)) {

                $ReturnStatus = [PSCustomObject]@{
                    Status = $False
                    Message = "Altiris already uninstalled"
                }

            } else {

                $Process = Start-Process -FilePath $Uninstaller -ArgumentList $Arguments -NoNewWindow -WorkingDirectory c:\temp -PassThru -ErrorAction SilentlyContinue -Wait
                Wait-Process -Id $Process.Id -Timeout $TimeLimit -ErrorAction SilentlyContinue

                if ((Get-Service -Name $Service).Status -eq "Running") {

                    $ReturnStatus = [PSCustomObject]@{
                        Status = $False
                        Message = "failed (the [$TimeLimit] second timeout was reached)"
                    }

                } else {

                    $ReturnStatus = [PSCustomObject]@{
                        Status = $True
                        Message = ""
                    }

                }

            }

            return $ReturnStatus

        }
        #endregion
        $StopTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt" 
        $Duration = New-TimeSpan -Start $StartTime -End $StopTime


        If ($Results.Status) {

            Write-Host "succeeded - ($($Duration.Minutes) minutes $($Duration.Seconds) seconds)" -ForegroundColor Green

        } else {

            Write-Host $Results.Message -ForegroundColor Red

        }

    }

}

