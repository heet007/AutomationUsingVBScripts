﻿#==========================================================================================================================================
# Program			: QUERY-LDAP.PS1
# Version			: 1.1.0
# Date				: Apr 26 2022
# Author			: Roland Thomas
# Team				: MCIT / End User Device Engineering
#
# 04-24-2022 v1.0.0 : First release
# 04-26-2022 v1.1.0 : Rewrote function to convert Canonical Names to Distinguished Names:
#                     - instead of string manipulation, use ADSI NameTranslate object interface methods to handle common and edge cases

[cmdletbinding (SupportsShouldProcess, ConfirmImpact="High")]
param(
    [ValidateSet("User", "Computer", "Group", "OUPath")]
    [string]$Class,

    [string]$User = $env:USERNAME,

    [string]$Computer = $env:COMPUTERNAME,

    [string]$Group = "DET-ADM-01",

    [string]$OUPath = "nyumc.org/NYULMC Clients/Win/Phase1/Desktop/EUDE"
)


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

<#
function Convert-CNtoDN {

    param(
        [string]$CanonicalName
    )

    # Convert the CanonicalPath to a DistinguishedPath
    $Parts = $CanonicalName.Split("//")

    foreach ($Part in $Parts) {
        if ($Parts.IndexOf($Part) -eq 0) {
            $DistinguishedName = "DC=nyumc,DC=org"
        } else {
            $DistinguishedName = "OU=$Part," + $DistinguishedName
        }
    }

}
#>


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-CNtoDN {

    param(
        [string]$CanonicalName,
        [PSCredential]$Credential
    )

    # The code below uses the IADsNameTranslate interface which can be used to convert the names of Active Directory objects from one format to another:
    # https://docs.microsoft.com/en-us/windows/win32/api/iads/nn-iads-iadsnametranslate


    # First define these CONSTANTS - they will be used to initialize the instantiated object
    # Name Translator Initialization Types: https://docs.microsoft.com/en-us/windows/win32/api/iads/ne-iads-ads_name_inittype_enum
    $ADS_NAME_INITTYPE_DOMAIN            = 1
    $ADS_NAME_INITTYPE_GC                = 3


    # And then define these CONSTANTS - they will be used to direct the Name Translation methods for the input and output formats
    # Name Translator Name Types: https://docs.microsoft.com/en-us/windows/win32/api/iads/ne-iads-ads_name_type_enum
    $ADS_NAME_TYPE_DISTINGUISHEDNAME     = 1
    $ADS_NAME_TYPE_CANONICALNAME         = 2


    # We will need to use the credentials of the service account so that we can contact a domain controller
    # The GetNetworkCredential() method will grab the service account password
    # https://docs.microsoft.com/en-us/dotnet/api/system.management.automation.pscredential.getnetworkcredential?view=powershellsdk-7.0.0
    # https://docs.microsoft.com/en-us/dotnet/api/system.net.networkcredential?view=net-6.0
    $NetworkCredential = $Credential.GetNetworkCredential()


    # Step 1: Instantiate the object
    $NameTranslate = New-Object -ComObject NameTranslate


    # Step 2: Initialize the object with the 'InitEx' method (this allows use of the service account credentials)
    # https://docs.microsoft.com/en-us/windows/win32/api/iads/nf-iads-iadsnametranslate-initex
    try {
        $DomainName = ([System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()).Name
        $Parameters = ($ADS_NAME_INITTYPE_DOMAIN, $DomainName, $NetworkCredential.Username, $NetworkCredential.Domain, $NetworkCredential.Password)
        $NameTranslate.GetType().InvokeMember("InitEx", "InvokeMethod", $Null, $NameTranslate, $Parameters)
    }
    catch {
        Write-Verbose $Error[0].Exception.Message
    }


    # Step 3: Define the naming format of the input with the 'Set' method
    # https://docs.microsoft.com/en-us/windows/win32/api/iads/nf-iads-iadsnametranslate-set
    $Parameters = ($ADS_NAME_TYPE_CANONICALNAME, "$CanonicalName")  # The $CanonicalName variable must be in quotes! (took me so long to figure this bug out)
    try {
        $NameTranslate.GetType().InvokeMember("Set", "InvokeMethod", $Null, $NameTranslate, $Parameters)
    }
    catch {
        Write-Verbose $Error[0].Exception.Message
    }


    # Step 4: Define the naming format of the output with th 'Get' method
    # https://docs.microsoft.com/en-us/windows/win32/api/iads/nf-iads-iadsnametranslate-get
    try {
        $DistinguishedName = $NameTranslate.GetType().InvokeMember("Get", "InvokeMethod", $Null, $NameTranslate, $ADS_NAME_TYPE_DISTINGUISHEDNAME)
    }
    catch {
        Write-Verbose $Error[0].Exception.Message
    }


    # Garbage collection -- delete the COM object and also credential variable because it will hold the cleartext password in memory
    finally {
        Remove-Variable -Name NetworkCredential
        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($NameTranslate) | Out-Null
    }

    return $DistinguishedName

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-EUDEServiceAccountCredentials {

    param(
        [string]$ServiceAccount = "NYUMC\svc_CompObj",
        [string]$PassHash = "o8Rw8n5RyQoqhdHcIt3Z0A==",
        [string]$ProgramPath = "\\nyumc.org\sysvol\nyumc.org\scripts\users",
        [string]$PassPhraseFile = "phrasep.txt"
    )


    if (Test-Path -Path "$ProgramPath\$PassPhraseFile") {

        . "$ProgramPath\encrypt.ps1"  # dot-source this script to include the encrypt/decrypt functions

        $PassPhrase = Get-Content -Path "$ProgramPath\$PassPhraseFile"

        $Password = Decrypt-String -Encrypted $PassHash -Passphrase $PassPhrase

        $SecurePassword = $Password | ConvertTo-SecureString -AsPlainText -Force

        $SecureCredential = New-Object System.Management.Automation.PsCredential($ServiceAccount, $SecurePassword)

        <# Uncomment to decrypt password for debugging purposes
        $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureCredential.Password)
        $UnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
        Write-Output "Service Account = $($SecureCredential.Username), Unsecure Password = $UnsecurePassword" ### ; exit
        #>

        return $SecureCredential

    } else {

        return $False

    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-LDAPGroupList {

    param(
        [PSCustomObject]$ADObject,
        [switch]$Children,
        [switch]$Parent
    )

    $RegexPattern = '^CN=(.+?),(?:CN|OU)=.+'  # this regex will grab the Common Name (CN) of the object from the Distinguished Name string


    # AD group objects have both "Member" and "MemberOf" properties that enumerate the children and parent (if the group is nested)
    if ($Parent) {
        $GroupList = $ADObject.memberof | % { $_ -replace $RegexPattern,'$1' -replace "\\","" } | sort  # regex will add a \ if the CN has a comma, the -replace "\\","" removes the \
    } else {
        if ($Children) {
            $GroupList = $ADObject.member | % { $_ -replace $RegexPattern,'$1' -replace "\\","" } | sort
        } else {
            return $False
        }
    }


    if (!$GroupList) {
        $Results = $False
    } else {
        $Results = [string]::Join("; ", $GroupList)  # convert the object list of groups in to a string, separated by semi-colons
    }

    
    return $Results

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function QueryLDAP-ADObject {

# .NET Framework Classes used:
# DirectoryEntry: https://docs.microsoft.com/en-us/dotnet/api/system.directoryservices.directoryentry?view=dotnet-plat-ext-6.0
# DirectorySearcher: https://docs.microsoft.com/en-us/dotnet/api/system.directoryservices.directorysearcher?view=dotnet-plat-ext-6.0

    param(
        [string]$Filter,
        [string]$Category,
        [PSCredential]$Credential
    )

    # Decrypt the password, it must be passed as cleartext for LDAP queries
    ### $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Credential.Password)
    ### $UnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
    $NetworkCredential = $Credential.GetNetworkCredential()


    # Build the searcher object - LDAP filter syntax conforms to: https://docs.microsoft.com/en-us/windows/win32/adsi/search-filter-syntax
    # (Future use: LDAP_MATCHING_RULE_IN_CHAIN Object Identifier "1.2.840.113556.1.4.1941" to enumerate members in nested groups)
    $Domain = (New-Object System.DirectoryServices.DirectoryEntry).DistinguishedName # should return DC=nyumc,DC=org

    if ($Category -eq "OU") {
        $SearchRoot = "LDAP://$Filter"
    } else {
        $SearchRoot = "LDAP://$Domain"
    }


    # if OU does not exist then abort function
    if (!([adsi]::Exists($SearchRoot))) { return $False }


    ### $SearchPath = New-Object System.DirectoryServices.DirectoryEntry ($SearchRoot, $Credential.Username, $UnsecurePassword)
    $SearchPath = New-Object System.DirectoryServices.DirectoryEntry ($SearchRoot, $NetworkCredential.Username, $NetworkCredential.Password)
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher
    $Searcher.SearchRoot = $SearchPath
    $Searcher.PageSize = 1000
    [void]$Searcher.PropertiesToLoad.Add("distinguishedName")
    [void]$Searcher.PropertiesToLoad.Add("Name")
    $Searcher.SearchScope = "Subtree"

    try {
        switch ($Category) {
            "User" { 
                $Searcher.Filter = "(&(objectCategory=User)(samAccountName=$Filter))"
                $Results = $Searcher.FindOne().GetDirectoryEntry()
            }
            "Computer" {
                $Searcher.Filter = "(&(objectCategory=Computer)(samAccountName=$Filter$))"  # SAM Name requires terminating '$' for a computer
                $Results = $Searcher.FindOne().GetDirectoryEntry()
            }
            "Group" {
                $Searcher.Filter = "(&(objectCategory=Group)(samAccountName=$Filter))"
                $Results = $Searcher.FindAll().GetDirectoryEntry()
            }
            "OU" {
                $RegexPattern = '^LDAP://CN=(.+?),(?:CN|OU)=.+' # this regex will grab the Common Name (CN) of the object from the Distinguished Name string
                $Searcher.Filter = "(&(objectCategory=Computer))"
                $Results = ($Searcher.FindAll()).Path | % { $_ -replace $RegexPattern,'$1' } | sort
            }
            default { return $False }
        }  
    }
    catch { $Results = $False }

    <#
    Write-Output "LDAP Search Filter = $($Searcher.Filter)"
    if ($Results) {
        $Results | fl *
    } else {
        Write-Output "No results found."
    }
    exit
    #>

      
    $Searcher.Dispose()

    Remove-Variable -Name NetworkCredential

    return $Results

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

#region Validate credentials of the NYULH EUDE service account 
if (!$Class) { exit }  #  immediately abort if there is no mandatory argument

$Credentials = Get-EUDEServiceAccountCredentials

if (!([bool]$Credentials)) {
    Write-Warning "VALIDATION FAIL: The EUDE service account credentials could not be retrieved"; exit
}
#endregion


#region Enumerate the LDAP attributes for the supported classes
switch ($Class) {

    "User" {
        $ADUser = QueryLDAP-ADObject -Filter $User -Category "User" -Credential $Credentials
        if ($ADUser) {
            $UserGroups = Get-LDAPGroupList -ADObject $ADUser -Parent
            $Results = $ADUser | Add-Member -NotePropertyName Groups -NotePropertyValue $UserGroups -Force -PassThru | Select-Object -Property *
        } else {
            $Results = $False
        }
    }

    "Computer" {
        $ADComputer = QueryLDAP-ADObject -Filter $Computer -Category "Computer" -Credential $Credentials
        if ($ADComputer) {
            $ComputerGroups = Get-LDAPGroupList -ADObject $ADComputer -Parent
            $Results = $ADComputer | Add-Member -NotePropertyName Groups -NotePropertyValue $ComputerGroups -Force -PassThru | Select-Object -Property *
        } else {
            $Results = $False
        }
    }

    "Group" {
        $GroupList = QueryLDAP-ADObject -Filter $Group -Category "Group" -Credential $Credentials
        if ($GroupList) {
            $Results = [PSCustomObject][Ordered]@{
                MemberOf = Get-LDAPGroupList -ADObject $GroupList -Parent
                Members = Get-LDAPGroupList -ADObject $GroupList -Children
            } # put both group lists in object to make output easier with Format-List
        } else {
            $Results = $False
        }
    }

    "OUPath" {
        $OUDN = Convert-CNtoDN -CanonicalName $OUPath -Credential $Credentials
        $Results = QueryLDAP-ADObject -Filter $OUDN -Category "OU" -Credential $Credentials
    }

}

return $Results
#endregion
