﻿#==========================================================================================================================================
# Program			: GET-GPRESULT.PS1
# Version			: 1.0.1
# Date				: Feb 12 2021
# Author			: Roland Thomas
# Team				: MCIT / End User Device Engineering
#
# This script runs a Win10 GPRESULT on a remote or local computer and saves report to C:\TEMP\GPRESULT-{computer}-{user}.HTM
#
# 02-13-20 (v1.0.0) : First release
# 02-12-20 (v1.0.1) : Add -TimeStamp switch to add timestamp to report filename (to compare multiple GP reports of same machine over period of time)

[cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]param(    [string[]]$Computername = $env:COMPUTERNAME,    [string]$User = $Null,    [switch]$CurrentUser = $True,    [switch]$TimeStamp = $True)


$ScriptName = $MyInvocation.MyCommand.Name.ToUpper()
$ExitonError = $True
$NoExitonError = $False
$Target = "C:\TEMP"


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Error-Handler([string]$ErrorMessage, [boolean]$_ExitonError) {
    Write-Host -ForegroundColor Red "`r`n$($Script:ScriptName): $ErrorMessage"
    ### Write-Log $ErrorMessage

    if ($_.Exception.Message -ne $null) {
        Write-Host -ForegroundColor Red "`r`nSystem error message was:" $_.Exception.Message
        ### Write-Log $_.Exception.Message
     }

    if ($_ExitonError) { exit }
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-DNtoCN([string]$DistinguishedName) {

    # Parsing if an empty string is sent 
    if ([string]::IsNullOrEmpty($DistinguishedName)) { return $Null }


    # Strip off leading LDAP prefix if there is any
    if ($DistinguishedName -like "LDAP://*") { $DistinguishedName = $DistinguishedName -replace "LDAP://","" }


    # Split the distinguished name into separate bits 
    $Parts = $DistinguishedName.Split(",")
 
    foreach ($Part in $Parts) {
        if ($Part -like "OU=*") {
            $Subpart = $Part -replace "OU=",""
            $CanonicalName = "/$Subpart" + $CanonicalName
        }

    }

    $CanonicalName = "nyumc.org" + $CanonicalName

    return $CanonicalName

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-OnlineStatus($Machine) {    $PingStatus = Test-Connection -ComputerName $Machine -Count 1 -Quiet -ErrorAction SilentlyContinue    if ($PingStatus) {    ### $PingStatus = Ping-Computer -ComputerName $Machine    ### if ($PingStatus.Online) {        $Machine_IPAddress = (Test-Connection -ComputerName $Machine -Count 1).IPV4Address.IPAddressToString        $FQDN_Machine = ([System.Net.Dns]::GetHostEntry($Machine)).Hostname        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "Yes"
            DNSHostName = $FQDN_Machine
            IPAddress = $Machine_IPAddress
        }

    } else {        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "No"
            DNSHostName = "OFFLINE"
            IPAddress = "OFFLINE"
        }
    }    return $ReturnObject}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-CurrentRemoteUser ($Machine) {

    try {

        $UserInfo = Invoke-Command -ComputerName $Machine -ErrorAction SilentlyContinue -ScriptBlock {
            $ErrorActionPreference = "SilentlyContinue"
            $Quser = quser.exe
            if ($Quser) {
                return ($QuserInfo = $Quser[1] -replace '\s+',' ' -split " ")
            } else {
                return $False
            }
        }


        if ($UserInfo) {
            try { if (Get-Process logonui -ComputerName $Machine -ErrorAction Stop) { $WorkstationState = "LOCKED" } } 
            catch { $WorkstationState = "UNLOCKED" } 
    
            if ($UserInfo.Count -eq 8) { # HACK: if number of elements = 8, that means the SessionName is blank, and need to decrement index
    
                $CurrentRemoteUser = [PSCustomObject]@{
                    UserName = $UserInfo[1].ToUpper()
                    SessionName = "NONE"
                    SessionID = $UserInfo[2]
                    UserState = $UserInfo[3].ToUpper()
                    IdleTime= $UserInfo[4]
                    LogonTime = $UserInfo[5] + " " + $UserInfo[6] + $UserInfo[7]
                    WorkstationState = $WorkstationState
                }

            } else {

                $CurrentRemoteUser = [PSCustomObject]@{
                    UserName = $UserInfo[1].ToUpper()
                    SessionName = $UserInfo[2].ToUpper()
                    SessionID = $UserInfo[3]
                    UserState = $UserInfo[4].ToUpper()
                    IdleTime= $UserInfo[5]
                    LogonTime = $UserInfo[6] + " " + $UserInfo[7] + $UserInfo[8]
                    WorkstationState = $WorkstationState
               }

            }

        } else {
            $CurrentRemoteUser = $False
        }

    }


    catch {
        $CurrentRemoteUser = $False
    }

    return $CurrentRemoteUser}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-OSVersion ($OSName, $OSBuild) {

    if ($OSName -like "*Windows 7*") {

        $OSEdition = $OSName -replace "Windows 7","Win7"
        $OSVersion = "$OSEdition $OSBuild"    } else {        $OSEdition = $OSName -replace "Windows 10","Win10"        switch -Wildcard ($OSBuild) {            "*10240*" { $Win10_Version = "ver 1507 RTM" }
            "*10586*" { $Win10_Version = "ver 1511" }
            "*14393*" { $Win10_Version = "ver 1607" }
            "*15063*" { $Win10_Version = "ver 1703" }
            "*16299*" { $Win10_Version = "ver 1709" }
            "*17134*" { $Win10_Version = "ver 1803" }
            "*17763*" { $Win10_Version = "ver 1809" }
            "*18362*" { $Win10_Version = "ver 1903" }            "*18363*" { $Win10_Version = "ver 1909" }            "*19041*" { $Win10_Version = "ver 2004" }            default { $Win10_Version = "ver UNKNOWN" }        }        $OSVersion = "$OSEdition ($Win10_Version - build $OSBuild)"
    }    return $OSVersion}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-Subnet($Machine) {

    try {
        $NetworkAdapters = Get-CimInstance -Namespace "root\cimv2" -Class Win32_NetworkAdapterConfiguration -ComputerName $Machine -OperationTimeoutSec 30 `
             -Property * -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | ? {($_.IPEnabled -eq "True") -and ($_.DefaultIPGateway -ne $Null)}

        $NetworkAdapters | % {
 
           # Compute the Subnet (Network ID) from the IP Address and Subnet Mask
           $IPAddress = @($_.IPAddress)[0]
           $IPAddress_Octets = $IPAddress -split "\."              # Split up IP Address into array of 4 octets
           $SubnetMask_Octets = @($_.IPSubnet)[0] -split "\."      # Do the same for the subnet mask
           $Subnet_Octets = @{}                                    # Initialize hashtable for the subnet

           for ($i=0; $i -le 3; $i++) {                            # Do binary-and on all octets
               [int32]$Subnet_Octets[$i] = [int32]$IPAddress_Octets[$i] -band [int32]$SubnetMask_Octets[$i]
               $Subnet_NetworkID += ($Subnet_Octets[$i]).ToString() + "."  # Concatenate the result back into dotted-notation
           }

           $Subnet_NetworkID = $Subnet_NetworkID -replace ".$"             # Strip off last dot (artifact of last command)

        }

    }

   catch { $Subnet_NetworkID = "OFFLINE" }

   return $Subnet_NetworkID

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SystemInfo ($Machine) {

    try {
        $OSInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem -ComputerName $Machine -ErrorAction SilentlyContinue    }    catch {        $OSInfo = $False        Error-Handler "Unable to query WMI Win32_OperatingSystem class on [$Machine]" $ExitonError
    }    if ($OSInfo) {        # Get last boot tiime        $BootTime = $OSInfo.ConvertToDateTime($OSInfo.LastBootUpTime)  # Use this if enumerating with GET-WMIOBJECT        ### $BootTime = $OSInfo.LastBootUpTime    # Use this if enumerating with GET-CIMINSTANCE        if ($BootTime -eq $Null) { $BootTime = "UNKNOWN" }
        # Get OS Version
        $OSName = $OSInfo.Caption -replace "Microsoft ",""        if ($OSName -like "*Windows 7*") {

            $OSVersion = Get-OSVersion $OSName $OSInfo.CSDVersion        } else {            $OSVersion = Get-OSVersion $OSName $OSInfo.Version        }

    } else {

        $OSVersion = "UNKNOWN"
        $BootTime = "UNKNOWN"
    }


    $ReturnObject = [PSCustomObject]@{
        OSVersion = $OSVersion
        BootTime = $BootTime
    }    return $ReturnObject
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function IsAdmin() {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Abort if user does not have local admin rights for certain functions
if (!(IsAdmin)) { Write-Warning "This script requires admin privileges!  Please elevate and re-run the script."; exit }


### Write-Host "`nUsage: $ScriptName -Computer <computername> [-User <username] [-CurrentUser]"


foreach ($Computer in $Computername) {

    cls

    if ($Computer -eq ".") { 
        $Computer = $env:COMPUTERNAME
    } else {
        $Computer = $Computer.ToUpper()
    }

    if ($User) { $User = $User.ToUpper() }

    $ComputerStatus = Get-OnlineStatus $Computer

    if ($ComputerStatus.OnlineStatus -ne "Yes") {        Write-Host "`nCannot ping machine [$Computer] - it may be offline" -ForegroundColor Red
        continue
    }    

   
    Write-Host "`nChecking to see if Computer [$Computer] is online ..."

    $Subnet = Get-Subnet $Computer
    $SystemInfo = Get-SystemInfo $Computer
    $CurrentOU = Convert-DNtoCN (Get-ADComputer -Filter 'Name -like $Computer').DistinguishedName


    $RemotePC = [PSCustomObject]@{
        DNSHostName = $ComputerStatus.DNSHostName
        IPAddress = $ComputerStatus.IPAddress
        Subnet = if ($Subnet) {$Subnet} else {"UNKNOWN"}
        OSVersion= $SystemInfo.OSVersion
        CurrentOU = $CurrentOU
        BootTime = $SystemInfo.BootTime
    }


    Write-Host "`nComputer [$Computer] is online and reporting this information:"
    $RemotePC


    if ($CurrentUser) {
        $User = (Get-CurrentRemoteUser $Computer).UserName
        if ($User) { 
            Write-Host "User [$User] is currently logged on computer [$Computer]`n"
        } else {
            Write-Warning "Unable to retrieve status of current logged in user on computer [$Computer]`n"
            ### continue
        }
    }


    $Error.Clear()

    $DateTime = Get-Date -Format "MMddyy-hhmmss"

    if ([bool]$User) {

        if ($TimeStamp) { $ReportFile = "$Target\GPRESULT-$Computer-$User-$DateTime.htm" } else { $ReportFile = "$Target\GPRESULT-$Computer-$User.htm" }        Write-Host "`nSaving RSOP for Computer [$Computer] in user context [$User] to: $ReportFile ...`n"        $RSOP = Get-GPResultantSetOfPolicy -Computer $Computer -User $User -ReportType Html -Path $ReportFile -ErrorAction SilentlyContinue

    } else {
        if ($TimeStamp) { $ReportFile = "$Target\GPRESULT-$Computer-NOCURRENTUSER-$DateTime.htm" } else { $ReportFile = "$Target\GPRESULT-$Computer.htm" }        Write-Host "`nSaving RSOP for Computer [$Computer] only (no user logged in) to: $ReportFile ...`n"        ### $RSOP = Get-GPResultantSetOfPolicy -Computer $Computer -ReportType Html -Path $ReportFile -ErrorAction SilentlyContinue
        $RSOP = gpresult.exe /s $Computer /scope computer /f /h $ReportFile

    }


    if (Test-Path -Path $ReportFile) {

        Write-Host "Opening report file: $ReportFile"
        & "C:\Program Files (x86)\Internet Explorer\iexplore.exe" $ReportFile
    } else {        if ([bool]$User) {
            Write-Warning "Unable to generate RSOP for supplied username or currently logged in user"        } else {            Write-Warning "Unable to generate RSOP for computer [$Computer]"        }        $Error[0].Exception.Message    }
}

