﻿
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-EUDEServiceAccountCredentials {

    $ServiceAccount = "NYUMC\svc_CompObj"    $ServiceAccountPassHash = "o8Rw8n5RyQoqhdHcIt3Z0A=="
    $ProgramPath = "\\nyumc.org\sysvol\nyumc.org\scripts\users"
    $PassPhraseFile = "$ProgramPath\phrasep.txt"

    if (Test-Path -Path $PassPhraseFile) {

        . "$ProgramPath\encrypt.ps1"  # dot-source this script to include the encrypt/decrypt functions

        $PassPhrase = Get-Content -Path $PassPhraseFile

        $Password = Decrypt-String -Encrypted $ServiceAccountPassHash -Passphrase $PassPhrase

        $SecurePassword = $Password | ConvertTo-SecureString -AsPlainText -Force

        $SecureCredential = New-Object System.Management.Automation.PsCredential($ServiceAccount, $SecurePassword)

        return $SecureCredential

    } else {

        return $False

    }

}

 
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-LocalCredential {

    param(        [string]$Machine=$env:COMPUTERNAME,        [string]$LocalUsername,        [string]$LocalPassword    )

    $LocalUsername = $LocalUsername.ToLower()

    # Verify the password username and password are valid
    Add-Type -AssemblyName System.DirectoryServices.AccountManagement
    $AccountPrincipal = New-Object System.DirectoryServices.AccountManagement.PrincipalContext('machine', $Machine)
    $Validate = $AccountPrincipal.ValidateCredentials($LocalUsername, $LocalPassword)

    if ($Validate) {

        $LocalAccount = "$Machine\$LocalUsername"
        $SecurePassword = $LocalPassword | ConvertTo-SecureString -AsPlainText -Force
        $LocalCredential = New-Object System.Management.Automation.PsCredential($LocalAccount, $SecurePassword)

        <#
        $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($LocalCredential.Password)
        $UnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
        Write-host "LocaAdminUsername = $($LocalCredential.Username); LocalPassword = $UnsecurePassword"
        exit
        #>

        return $LocalCredential

    } else {

        return $False

    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-RegValue ($RegKey, $RegName, $LocalCredential) {

    ### $RegValue =  (Get-ItemProperty -Path $RegKey -Name $RegName -ErrorAction SilentlyContinue) #.$RegName
    ### $RegValue
    ### return $RegValue

    ### $RegKey = $RegKey -replace ":","" 
    ### return (-split (reg.exe query $RegKey /v $RegName))[4]

    $RandomFilename = [system.io.path]::GetRandomFilename()
    $RandomFilename -replace ",","-"
    exit

    Start-Process -FilePath reg.exe -ArgumentList "query $RegKey /v $RegName" -WorkingDirectory "c:\temp" -NoNewWindow -RedirectStandardOutput "c:\temp\output2.txt"
    $RegValue = Get-Content -Path "c:\temp\output2.txt"

    # $RegValue

    return $RegValue
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Is-Admin() {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function QueryLDAP-ADObject ($Filter, $Category, $Credential) {

    switch ($Category) {
        "User" { $SearchFilter = "(&(objectCategory=User)(samAccountName=$Filter))" }
        "Group" { $SearchFilter = "(&(objectCategory=Group)(samAccountName=$Filter))" }
        "Computer" { $SearchFilter = "(&(objectCategory=Computer)(samAccountName=$Filter$))" }  # SAM Name requires terminating '$' for a computer
        "OU" { $SearchFilter = "(&(objectCategory=OrganizationalUnit)(name=$Filter))" }
        default { return $False }
    }

   
    # Decrypt the password, it must be passed as cleartext for LDAP queries
    $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Credential.Password)
    $UnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
    ### Write-Host "Username = $($Credential.Username), Unsecure Password = $UnsecurePassword"


    $SearchRoot = "LDAP://DC=nyumc,DC=org"
    $SearchPath = New-Object System.DirectoryServices.DirectoryEntry ($SearchRoot, $Credential.Username, $UnsecurePassword)
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher

    $Searcher.SearchRoot = $SearchPath
    $Searcher.PageSize = 1000
    $Searcher.PropertiesToLoad.Add("Name")
    $Searcher.Filter = $SearchFilter
    $Searcher.SearchScope = "Subtree"

    try {
        if ($Category -eq "Group") {
            $Result = $Searcher.FindAll().GetDirectoryEntry()
        } else {
            $Result = $Searcher.FindOne().GetDirectoryEntry()
        }
    }
    catch { $Result = $False }

    <#
    if ($Result) {
        Write-Host "Resolved Search Filter = $($Searcher.Filter)"
        $Result | fl *
        exit
    } 
    #>
       
    $Searcher.Dispose()

    return $Result

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Waitfor-KeyPress {
    Write-Host -NoNewLine "Press any key to continue...";
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown");
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

cls

$Machine = $env:COMPUTERNAME

#if (!(Is-Admin)) {

    #region Validate credentials of the NYULH service account 
    $ServiceCredential = Get-EUDEServiceAccountCredentials    if ([bool]$ServiceCredential) {        Write-Host "VALIDATION PASS: The NYULH service account credentials were authenticated"    } else {        Write-Host "VALIDATION FAIL: The NYULH service account credentials could not be authenticated"        exit    }    #endregion


    #region Validate computer exists in AD
    $ADComputer = QueryLDAP-ADObject $Machine "Computer" $ServiceCredential    if ([bool]($ADComputer.Name)) {        Write-Host "VALIDATION PASS: This device [$Machine] was found in the NYULH AD"    } else {        Write-Host "VALIDATION FAIL: This device [$Machine] was not found in the NYULH AD"        exit    }    if (![bool]($ADComputer.Name)) { Write-Host "This device [$Machine] does not exist in the NYULH AD" ; exit }
    #endregion


    #region Validate this computer has an unexpired LAPS password
    if (!(Test-Path -Path "C:\Program Files\LAPS\CSE\AdmPwd.dll")) { Write-Host "Microsoft LAPS is not installed on this computer" ; exit }
    $LocalUser = "mcitadmin"    ### $LocalUserExists = (Get-LocalUser -Name $LocalUser).Enabled
    $LocalUserExists = [bool](Get-CimInstance -Query "SELECT Domain,Name FROM Win32_UserAccount WHERE (Domain = '$Machine' AND Name = '$LocalUser')")
    if ($LocalUserExists) {
        $LocalCredential = Get-LocalCredential -LocalUsername $LocalUser -LocalPassword $($ADComputer."ms-Mcs-AdmPwd")
        if ([bool]$LocalCredential) {            Write-Host "VALIDATION PASS: Credentials for local account [$Localuser] successfully retrieved from AD"        } else {            Write-Host "VALIDATION FAIL: Credentials for local account [$Localuser] could not be retrieved from AD"            exit        }    }
    #endregion


    #
    $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($LocalCredential.Password)
    $UnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
    Write-host "LocaAdminUsername = $($LocalCredential.Username); LocalPassword = $UnsecurePassword"


    #region Validate this is a NYUMC built computer
    $RegValue = Get-RegValue "HKLM\SOFTWARE\NYUMC\CoreBuild" "Domain" $LocalCredential
    $RegValue | fl

    if ($RegValue -eq "NYUMC") { 
        Write-Host "VALIDATION PASS: This device [$Machine] is a NYULH-managed computer"    } else {        Write-Host "VALIDATION FAIL: This device [$Machine] is not a NYULH-managed computer"
        #exit    }    #endregion
    exit

    <#
    $ProcessProperties = @{
        Verb = "runas"
        Arguments = "& '.\" + $MyInvocation.MyCommand.Name + "'"
        CreateNoWindow = $True
        RedirectStandardOutput = $True
        RedirectStandardError = $True
        UserName = $LocalUser
        Password = $LocalCredential.Password
        Domain = $Machine
        WorkingDirectory = "c:\temp"
        WindowStyle = "Normal"
        UseShellExecute = $False
        ErrorDialog = $True
    }

    $ProcessStartInfo = New-Object System.Diagnostics.ProcessStartInfo "Powershell" -Property $ProcessProperties
    ### $ProcessStartInfo = New-Object System.Diagnostics.ProcessStartInfo "c:\windows\notepad.exe" -Property $ProcessProperties

    $ProcessStartInfo | fl *

    [System.Diagnostics.Process]::Start($ProcessStartInfo)

    ### EXIT
    #>


<#
} else {

    #region Create transcript on local drive to be added later to event log
    $LocalTempFolder = "C:\TEMP"
    $TranscriptLog = "$LocalTempFolder\$Machine-VPNHOST2.log"

    # Stop any previously running transcript that may not have closed due to abnormal script termination
    try { Stop-Transcript| Out-Null }
    catch [System.InvalidOperationException]{}

    if (!(Test-Path -Path $LocalTempFolder)) { New-Item -Path $LocalTempFolder -ItemType Directory -ErrorAction SilentlyContinue | Out-Null }
    if (Test-Path -Path $TranscriptLog) { Remove-Item -Path $TranscriptLog -Force -ErrorAction SilentlyContinue }

    Start-Transcript -Path $TranscriptLog -IncludeInvocationHeader -Force
    #endregion

    # Get the security principal for the administrator role
    $myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
    $myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);
    $adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

    $myWindowsID | fl *
    $myWindowsPrincipal | fl *
    $adminRole | fl *


    #region Validate this is a NYUMC built computer
    $RegValue = Get-RegValue "HKLM\SOFTWARE\NYUMC\CoreBuild" "Domain" $LocalCredential
    $RegValue | fl

    if ($RegValue -eq "NYUMC") { 
        Set-Content -Value "VALIDATION PASS: This device [$Machine] is a NYULH-managed computer" -Path "c:\temp\output.txt" -Force    } else {        Set-Content -Value "VALIDATION FAIL: This device [$Machine] is not a NYULH-managed computer" -Path "c:\temp\output.txt" -Force
        #exit    }    #endregion
    Stop-Transcript}### Waitfor-KeyPress#EXIT#>