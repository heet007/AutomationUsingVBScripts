﻿(Get-WmiObject -Query "Select * FROM WMIMonitorID" -Namespace root\wmi | 
    Select -ExpandProperty SerialNumberID | 
    foreach {[char]$_}) -join ""

