﻿#==========================================================================================================================================
# Program			: INSTALL-ANYAPP.PS1
# Version			: 1.0.0
# Date				: Sep 05 2020
# Author			: Roland Thomas
# Team				: MCIT / End User Device Engineering
#
# This script installs ....
#
# 09-05-20 (v1.0.0)	: First release.
    
#Requires -Version 3.0#Requires -RunAsAdministrator[cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]param(    [string[]]$Computername = $env:COMPUTERNAME,    [string]$File = $Null,    [string]$Group = $Null,    [string]$OUPath = $Null,    [string]$AppName = $Null,    [string]$AppShortName = $Null,    [string]$AppVersion = $Null,    [string]$CmdtoExecute = $Null,    [string]$CmdArguments = $Null,
    [switch]$DebugEnable=$True
)


if ($DebugEnable) {

    $DebugPreference = "SilentlyContinue"
    $ErrorActionPreference = "SilentlyContinue"    $VerbosePreference = "SilentlyContinue"    $AppName = "FullName"    $AppShortName = "ShortName"    $AppVersion = "9.9.9"    $CmdtoExecute = "\\mscsnyu01.nyumc.org\adbuild\DET_Builds\Packages\XXXXXX\NNNNN.exe"
    $CmdArguments = ""

} else {

    $DebugPreference = "SilentlyContinue"
    $ErrorActionPreference = "SilentlyContinue"    $VerbosePreference = "SilentlyContinue"}
#Initialize script-specific variables$Script = Get-ChildItem -Path $PSCommandPath.ToUpper()$ScriptBaseName = $Script.BaseName$ScriptFileName = $Script.FullName$ScriptVersion = "v1.0.0 (090520)"
$ScriptName = Split-Path $ScriptFileName -Leaf
$ScriptPath = (Resolve-Path $ScriptFileName).Drive.DisplayRoot + (Split-Path $ScriptFileName -NoQualifier)
$ScriptBuild = $Script.LastWriteTime.ToString("MM-dd-yyyy hh:mm:ss tt")


#Initialize general-purpose variables
$ExitonError = $True
$DontExitonError = $False
$TodaysShortDate = Get-Date -format "yyyyMMdd-HHmmss"
$LocalTempFolder = "C:\TEMP"
$LogFilename = "$ScriptBaseName-$TodaysShortDate"
$NetworkLogFolder = "\\shares.nyumc.org\EUDE\Inventory\OnDemand\Deployment"


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Display-Message () {

    param(
        [string]$Message,
        [string]$WindowTitle,
        [ValidateSet("AbortRetryIgnore", "OK", "OKCancel", "RetryCancel", "YesNo", "YesNoCancel")]
        [String]$ButtonType,
        [ValidateSet("Asterisk", "Error", "Exclamation", "Hand", "Information", "None", "Question", "Stop", "Warning")]
        [String]$IconType
    )


    Add-Type -AssemblyName System.Windows.Forms

    switch ($ButtonType) {

        { $ButtonType -in "AbortRetryIgnore", "OK", "OKCancel", "RetryCancel", "YesNo", "YesNoCancel" } 

            { [System.Windows.Forms.MessageBoxButtons]$Buttons = [System.Windows.Forms.MessageBoxButtons]::$ButtonType }

        default { [System.Windows.Forms.MessageBoxButtons]$Buttons = [System.Windows.Forms.MessageBoxButtons]::OK }

    }


    switch ($IconType) {

        { $IconType -in "Asterisk", "Error", "Exclamation", "Hand", "Information", "None", "Question", "Stop", "Warning" }

            { [System.Windows.Forms.MessageBoxIcon]$Icon = [System.Windows.Forms.MessageBoxIcon]::$IconType }

        default { [System.Windows.Forms.MessageBoxIcon]$Icon = [System.Windows.Forms.MessageBoxIcon]::None }

    }

    return [System.Windows.Forms.MessageBox]::Show($Message, $WindowTitle, $Buttons, $Icon)

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Error-Handler([string]$ErrorMessage, $_ExitonError) {

    ### $Line = $Error[0].InvocationInfo.ScriptLineNumber
    ### Write-Log "Error at Line [$Line]: $ErrorMessage" -Color "Red"

    Write-Log $ErrorMessage -Color "Red"

    <#
    try {

        $ExceptionMessage = $Error[0].Exception.Message
        if ($ExceptionMessage -ne $Null) { Write-Log "System error message was: '$ExceptionMessage'" -Color "Yellow" }
        
        $HResultCode = $Error[0].Exception.HResult
        if (([bool]$HResultCode) -and ($HResultCode -ne 0)) {
            $ExitCode = "0x" + $("{0:x}" -f $HResultCode)
        } else {
            $ExitCode = $LASTEXITCODE
        }

    }
    catch { 
        $ExitCode = -999
    }

    Write-Log "Returning to caller with Error Code: $ExitCode" -Color "Yellow"
    #>

    if ([bool]$_ExitonError) {
        Write-StopScriptTime $Script:StartTime  $Script:TranscriptLog $Script:NetworkLogFolder
        exit
    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-DNtoCN([string]$DistinguishedName) {

    # Parsing if an empty string is sent 
    if ([string]::IsNullOrEmpty($DistinguishedName)) { return $Null }


    # Strip off leading LDAP prefix if there is any
    if ($DistinguishedName -like "LDAP://*") { $DistinguishedName = $DistinguishedName -replace "LDAP://","" }


    # Split the distinguished name into separate bits 
    $Parts = $DistinguishedName.Split(",")
 
    foreach ($Part in $Parts) {
        if ($Part -like "OU=*") {
            $Subpart = $Part -replace "OU=",""
            $CanonicalName = "/$Subpart" + $CanonicalName
        }

    }

    $CanonicalName = "nyumc.org" + $CanonicalName

    return $CanonicalName

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Convert-OSBuildNumber ($OSBuild) {

    switch -Wildcard ($OSBuild) {
        "*10240*" { $OSVersion = "1507 RTM" }
        "*10586*" { $OSVersion = "1511" }
        "*14393*" { $OSVersion = "1607" }
        "*15063*" { $OSVersion = "1703" }
        "*16299*" { $OSVersion = "1709" }
        "*17134*" { $OSVersion = "1803" }
        "*17763*" { $OSVersion = "1809" }
        "*18362*" { $OSVersion = "1903" }        "*18363*" { $OSVersion = "1909" }        "*19041*" { $OSVersion = "2004" }        default { $OSVersion = "UNDETERMINED" }    }    return $OSVersion
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Export-SessionInfotoCSV {

    [cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]    param(        [object]$Object,        [string]$Folder,        [string]$Filename    )
    g
    $FileSizeLimit = [int]10  # max logfile size in kilobytes
    $ExportCSVFile = "$Folder\$Filename"

    $FileInfo = Get-ChildItem -Path $ExportCSVFile -Force
    $FileSize = [int]($FileInfo.Length / 1KB)  ### '1KB' is language constant that means 1 kilobyte
    $FileTimeStamp = $FileInfo.LastWriteTime.ToString("MMddyyyy-HHmmss")
    $NewFileName = $FileInfo.BaseName + "-ARCHIVE-" + $FileTimeStamp + $Fileinfo.Extension

    if ($FileSize -ge $FileSizeLimit) {
        Rename-Item -Path $ExportCSVFile -NewName $NewFileName
        Start-Sleep -Seconds 3
    }
 
    if (!(Test-Path -Path $ExportCSVFile)) {
        $Object | Export-Csv -Path $ExportCSVFile -NoTypeInformation # if file does not exist, create with header
    } else {
        $Object | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1 | Add-Content -Path $ExportCSVFile # if file already exist, append without header
    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-CurrentUser {

    $ProcessName = "explorer.exe"
    #$ProcessName = "ALMon.exe"         # the Sophos agent process
    #$ProcessName = "AeXAgentUIHost.exe" # the Symantec Management Agent process

    $Process = Get-WmiObject Win32_Process -Filter "Name='$ProcessName'" -ErrorAction SilentlyContinue

    if ([bool]$Process) {

        $UserName = ($Process | ForEach-Object { $_.GetOwner() } |  Select-Object -Unique -Expand User).ToUpper()

        $Principal = New-Object System.Security.Principal.NTAccount($env:USERDOMAIN, $UserName)

        $UserSID = ($Principal.Translate([System.Security.Principal.SecurityIdentifier])).Value

        Write-Log "Username = [$Username]; UserSID = [$UserSID]"

    } else {

        $UserName = $Null ; $UserSID = $Null

        Write-Log "Process [$ProcessName] was not found attached to any logged-on user"

    }

        
    $Result = [PSCustomObject]@{
        UserName = $UserName
        UserSID = $UserSID
    }

    return $Result
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-EUDEServiceAccountCredentials {

    $ServiceAccount = "NYUMC\svc_CompObj"    $ServiceAccountPassHash = "o8Rw8n5RyQoqhdHcIt3Z0A=="
    $ProgramPath = "\\nyumc.org\sysvol\nyumc.org\scripts\users"
    $PassPhraseFile = "$ProgramPath\phrasep.txt"

    if (Test-Path -Path $PassPhraseFile) {

        . "$ProgramPath\encrypt.ps1"  # dot-source this script to include the encrypt/decrypt functions

        $PassPhrase = Get-Content -Path $PassPhraseFile

        $Password = Decrypt-String -Encrypted $ServiceAccountPassHash -Passphrase $PassPhrase

        $SecurePassword = $Password | ConvertTo-SecureString -AsPlainText -Force

        $SecureCredential = New-Object System.Management.Automation.PsCredential($ServiceAccount, $SecurePassword)

        return $SecureCredential

    } else {

        return $False

    }

}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-InputDialog ([string]$Message, [string]$WindowTitle, [string]$DefaultText) {

    Add-Type -AssemblyName Microsoft.VisualBasic
    return [Microsoft.VisualBasic.Interaction]::InputBox($Message, $WindowTitle, $DefaultText)
}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-LocalCredential {

    param(        [string]$Machine=$env:COMPUTERNAME,        [string]$LocalUsername,        [string]$LocalPassword    )

    $LocalUsername = $LocalUsername.ToLower()

    # Verify the password username and password are valid
    Add-Type -AssemblyName System.DirectoryServices.AccountManagement
    $AccountPrincipal = New-Object System.DirectoryServices.AccountManagement.PrincipalContext('machine', $Machine)
    $Validate = $AccountPrincipal.ValidateCredentials($LocalUsername, $LocalPassword)

    if ($Validate) {

        $LocalAccount = "$Machine\$LocalUsername"
        $SecurePassword = $LocalPassword | ConvertTo-SecureString -AsPlainText -Force
        $LocalCredential = New-Object System.Management.Automation.PsCredential($LocalAccount, $SecurePassword)

        <#
        $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($LocalCredential.Password)
        $UnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
        Write-host "LocaAdminUsername = $($LocalCredential.Username); LocalPassword = $UnsecurePassword"
        exit
        #>

        return $LocalCredential

    } else {

        return $False

    }

}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-MachineList {
    param(        [ValidateSet('Computername','File','Group','OUPath')][string]$ListType = $Null,
        [string[]]$List = $Null    )

    Write-Log "ListType = $ListType"
    Write-Log "List = $List"

    switch ($ListType) {        # Parse the -COMPUTERNAME parameter which could be any of the following:        #   - single machine        #   - comma-delimited list of machines        #   - machines with wildcards        "Computername" {             $Machine = $Script:Computername.ToUpper()            if ($Machine -match '\*') {                $MachineList = Query-LDAPObject $Machine "Computer"            } else {                $MachineList = $Machine            }        }        # Parse the -FILE parameter which is a text file of machines        "File" {            try { $MachineList = Get-Content -Path $Script:File | Sort | % { $_.toupper().trim() } | ? { $_.trim() -ne ""  } | Set-Content $Script:File -PassThru } # sort and trim whitespace and blank lines and re-save            catch { Error-Handler "Unable to open file list $Script:File" $ExitonError }        }        # Parse the -GROUP parameter which is domain group of computers        "Group" {
            #$MachineList = Query-LDAPGroupMembers $Script:Group "Computer"
            $MachineList = (Get-ADGroup -Identity $Script:Group -Properties member).member | % { $_ -replace "(CN=)(.*?),.*",'$2' } | sort -Unique
            if (!$MachineList) { Error-Handler "Group [$Script:Group] does not exist in AD or the group is empty" $ExitonError }        }        # Parse the -OUPATH parameter which is a canonical path to the Active Directory OU        "OUPath" {
            ### $MachineList = QueryLDAP-Computers_in_OU -OUPath $Script:OUPath
            $MachineList = (Get-ADComputer -Filter * -SearchBase (Convert-CNtoDN -CanonicalName $Script:OUPath) -SearchScope OneLevel -ErrorAction SilentlyContinue).Name
            if (![bool]$MachineList) { Error-Handler "Source OU Path [$Script:OUPath] does not exist in AD or there are no computers in the OU" $ExitonError }        }
    }

    return $MachineList
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-OSVersion {

    $OSInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem -ErrorAction SilentlyContinue

    if ([bool]$OSInfo) {

        $OSLongName = $OSInfo.Caption -replace "Microsoft ",""
        $OSBuild = $OSInfo.Version

        if ($OSLongName -like "*Windows 7*") {

            $OSShortName = $OSLongName -replace "Windows 7","Win7"
            $OSFullName = "$OSLongName $OSBuild"        } else {            $OSVersion = Convert-OSBuildNumber $OSBuild
            $OSShortName = $OSLongName -replace "Windows 10","Win10"            $OSFullName = "$OSLongName (ver $OSVersion - build $OSBuild)"
        }    } else {        $OSLongName = $OSShortName = $OSBuild = $OSVersion = $OSFullName = "UNKNOWN"
    }    $OSVersionObject = [PSCustomObject]@{
        OSLongName = $OSLongName
        OSShortName = $OSShortName
        OSBuild = $OSBuild
        OSVersion = $OSVersion
        OSFullName = $OSFullName
    }


    return $OSVersionObject

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-RegValue ($RegKey, $RegName) {

    ### whoami /priv

    ### METHOD 1
    <#
    $RegValue = Get-ItemProperty -Path $RegKey -Name $RegName -ErrorAction SilentlyContinue
    return $RegValue
    #>


    ### METHOD 2
    $RegKey = $RegKey -replace ":","" 
    $RegValue = reg.exe query $RegKey /v $RegName
    return ($RegValue.Split(" ",[StringSplitOptions]'RemoveEmptyEntries')[3])

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SessionInfo ($Machine) {

    $IPAddress = (Test-Connection -ComputerName $Machine -Count 1).IPV4Address.IPAddressToString
    $DNSName = (Resolve-DnsName -Name $Machine | ? { $_.IPAddress -eq $IPAddress }).Name   ### ([System.Net.DNS]::GetHostEntry($Machine)).Hostname

    $Subnet = Get-Subnet $Machine

    $SystemInfo = Get-SystemInfo2 $Machine
    ### $OSFullName = $SystemInfo.OSVersion.OSFullName

    $CurrentUser = Get-CurrentUser
    if ([bool]$CurrentUser) { $CurrentUserName = $CurrentUser.Username }    $CurrentOU = Convert-DNtoCN -DistinguishedName ($ADComputer.Path -replace "LDAP://CN=$Machine,","")
    $ComputerGroups = QueryLDAP-ADGroups $Machine "Computer"
    $UserGroups = QueryLDAP-ADGroups $CurrentUserName "User"
    $SessionInfo = [PSCustomObject][ordered]@{
        HostName = $Machine
        DNSName = $DNSName
        IPAddress = $IPAddress
        Subnet = if ([bool]$Subnet) { $Subnet } else { "UNKNOWN" }
        Manufacturer = $SystemInfo.Manufacturer
        Model = $SystemInfo.Model
        BIOS = $SystemInfo.BIOS
        SerialNumber = $SystemInfo.SerialNumber
        OSFullName = $SystemInfo.OSFullName
        OSUpgradeDate = $SystemInfo.OSUpgradeDate
        LastBootTime = $SystemInfo.BootTime
        UserName = "$Domain\$CurrentUserName"
        CurrentOU = $CurrentOU
        ComputerGroups = $ComputerGroups
        UserGroups = $UserGroups
    }
    return $SessionInfo}
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-Subnet($Machine) {

    try {
        $NetworkAdapters = Get-CimInstance -Namespace "root\cimv2" -Class Win32_NetworkAdapterConfiguration -ComputerName $Machine -OperationTimeoutSec 30 `
             -Property * -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | ? {($_.IPEnabled -eq "True") -and ($_.DefaultIPGateway -ne $Null)}

        $NetworkAdapters | % {
 
           # Compute the Subnet (Network ID) from the IP Address and Subnet Mask
           $IPAddress = @($_.IPAddress)[0]
           $IPAddress_Octets = $IPAddress -split "\."              # Split up IP Address into array of 4 octets
           $SubnetMask_Octets = @($_.IPSubnet)[0] -split "\."      # Do the same for the subnet mask
           $Subnet_Octets = @{}                                    # Initialize hashtable for the subnet

           for ($i=0; $i -le 3; $i++) {                            # Do binary-and on all octets
               [int32]$Subnet_Octets[$i] = [int32]$IPAddress_Octets[$i] -band [int32]$SubnetMask_Octets[$i]
               $Subnet_NetworkID += ($Subnet_Octets[$i]).ToString() + "."  # Concatenate the result back into dotted-notation
           }

           $Subnet_NetworkID = $Subnet_NetworkID -replace ".$"             # Strip off last dot (artifact of last command)

        }

    }

   catch { $Subnet_NetworkID = "OFFLINE" }

   return $Subnet_NetworkID

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SystemInfo ($Machine) {

    # Get system information from the Win32_ComputerSystem and Win32_BIOS classes
    try {
        $SysInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_ComputerSystem -ComputerName $Machine -ErrorAction SilentlyContinue
        $Manufacturer = $SysInfo.Manufacturer
        $Model = $SysInfo.Model
        $BIOS = (Get-WmiObject -Namespace "root\cimv2" -Class Win32_BIOS -ComputerName $Machine -ErrorAction SilentlyContinue).Description  # Also property SMBIOSBIOSVersion
    }    catch {        $Manufacturer = $Model = $BIOS = "UNKNOWN"    }

    # Get system information from the Win32_OperatingSystem classes
    try {
        $OSInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem -ComputerName $Machine -ErrorAction SilentlyContinue        # Get last boot tiime        $BootTime = $OSInfo.ConvertToDateTime($OSInfo.LastBootUpTime)  # Use this if enumerating with GET-WMIOBJECT        ### $BootTime = $OSInfo.LastBootUpTime    # Use this if enumerating with GET-CIMINSTANCE        if ($BootTime -eq $Null) { $BootTime = "UNKNOWN" }
        # Get OS Version
        $OSName = $OSInfo.Caption -replace "Microsoft ",""        if ($OSName -like "*Windows 7*") {
            $OSVersion = Get-OSVersion $OSName $OSInfo.CSDVersion        } else {            $OSVersion = Get-OSVersion $OSName $OSInfo.Version        }

        $OSUpgradeDate = $OSInfo.ConvertToDateTime($OSInfo.InstallDate)

    }    catch {        $BootTime = $OSVersion = $OSUpgradeDate = "UNKNOWN"    }


    $ReturnObject = [PSCustomObject]@{
        Manufacturer = $Manufacturer
        Model = $Model
        BIOS = $BIOS
        OSVersion = $OSVersion
        OSUpgradeDate = $OSUpgradeDate
        BootTime = $BootTime
    }    return $ReturnObject
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SystemInfo2 ($Machine) {

    $SysInfo = Invoke-Command -ComputerName $Machine -ScriptBlock { Get-ComputerInfo }

    $ReturnObject = [PSCustomObject][ordered]@{
        Manufacturer = $SysInfo.CsManufacturer
        Model = $SysInfo.CsModel
        BIOS = "$($SysInfo.BiosSMBIOSBIOSVersion) ($($SysInfo.BiosReleaseDate))"
        SerialNumber = $SysInfo.BiosSeralNumber
        WindowsEdition = $SysInfo.WindowsProductName
        OSVersion = $SysInfo.WindowsVersion
        OSBuild = $SysInfo.OSVersion
        OSFullName = "$($SysInfo.WindowsEdition) (ver $($SysInfo.OSVersion) - build $($SysInfo.OSBuild))"
        OSUpgradeDate = $SysInfo.OSInstallDate
        BootTime = $SysInfo.OSLastBootUpTime
    }    return $ReturnObject
}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Install-MyApp {

    param(        [string]$Computer,        [string]$Name,        [string]$Version,        [string]$Command,        [System.Management.Automation.PSCredential]$Credential    )


    $CredScript = { Register-PSSessionConfiguration -Name Session1 -RunAsCredential $Credential -Force }
    Invoke-Command -ComputerName $Computer -Credential $Credential -ScriptBlock $CredScript -ErrorAction SilentlyContinue 

    $InstallResult = Invoke-Command -ComputerName $Computer -ArgumentList $Computer, $Name, $Version, $Command, $Credential -ErrorAction Stop -ConfigurationName Session1 -ScriptBlock { 

            param ($RemoteComputer, $AppName, $AppVersion, $CmdtoExecute, $RemoteLocalCredential)

            $EventID = "6608"
            New-EventLog -ComputerName $RemoteComputer -LogName Application -Source $AppName -ErrorAction SilentlyContinue
            Write-Log "$RemoteComputer`t`t: Running [$CmdtoExecute] as local user [$($RemoteLocalCredential.Username.ToUpper())]" -ForegroundColor Green
            Write-EventLog -ComputerName $RemoteComputer -LogName Application -Source $AppName -EntryType Information -EventId $EventID -Message "[$AppName version $AppVersion] installation started."

            try {

                $InstallStatus = Start-Process -FilePath "$CmdtoExecute" -WorkingDirectory "C:\Temp\$AppName" -PassThru -Wait ### -Credential $RemoteLocalCredential 

                $ExitCode = $InstallStatus.ExitCode.ToString()

                if ($InstallStatus.ExitCode -eq '0') {
                    $Result = "SUCCESS"
                    Write-Log "$RemoteComputer`t`t: $AppName $AppVersion installed successfully" -ForegroundColor Green
                    Write-EventLog -ComputerName $RemoteComputer -LogName Application -Source $AppName -EntryType Information -EventId $EventID -Message "$AppName $AppVersion installed successfully (exit code: $ExitCode)"
                } else {
                    $Result = "FAIL"                   
                    Write-Log "$RemoteComputer`t`t: $AppName $AppVersion failed to install (check application event log)" -ForegroundColor Green
                    Write-EventLog -ComputerName $RemoteComputer -LogName Application -Source $AppName -EntryType Error -EventId $EventID -Message "$AppName $AppVersion failed to install (exit code: $ExitCode)"
                }
            }

            catch { 

                $ExceptionName = $_.Exception.GetType().FullName
                $ErrorMessage = $_.Exception.Message
                $FailedItem = $_.Exception.ItemName

                $Result = "FAIL"
                Write-Log "$RemoteComputer`t`t: Problem with installing [$AppName version $AppVersion] (Error: $ErrorMessage [$ExceptionName])" -ForegroundColor Green
                Write-EventLog -ComputerName $RemoteComputer -LogName Application -Source $AppName -EntryType Warning -EventId $EventID -Message "Problem with installing [$AppName version $AppVersion] (error: $ErrorMessage [$ExceptionName])"
            }

            return $Result

        }

    return $InstallResult
}

# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------function Is-Admin {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
workflow Parse-MachineList {

# https://docs.microsoft.com/en-us/system-center/sma/overview-powershell-workflows?view=sc-sma-2019
# https://docs.microsoft.com/en-us/previous-versions/windows/it-pro/windows-server-2012-r2-and-2012/jj574187(v=ws.11)
# http://powershellmuscle.com/category/powershell-workflow/
# https://powershell.org/forums/topic/return-values-from-a-workflow/


    param(
        [object]$MachineList,
        [object]$InstallInfo
    )


    $MachineList
    $InstallInfo


    $ReturnObject = [PSCustomObject][ordered]@{
        Pinged = 0
        NotPinged = 0
    }

    $Pinged = 0
    $NotPinged = 0


    foreach -parallel ($Machine in $MachineList) {

        # Display progress bar
        $Index = [array]::IndexOf($MachineList, $Machine) + 1
        $PercentComplete = [int32](($Index / $($MachineList.Count)) * 100)
        Write-Progress -Activity "$Machine : $Index out of $($MachineList.Count)" `
                -CurrentOperation "Number of computers successfully pinged so far: $WORKFLOW:Pinged" `
                -Status "$PercentComplete% complete" -PercentComplete $PercentComplete


        ### Write-Output "Pingable`tComputer" | Out-File -FilePath c:\temp\pinglist.csv -Force


        #region Validate computer exists in AD
        $ADComputer = QueryLDAP-ADObject $Machine "Computer" #$ServiceCredential        if ([bool]($ADComputer.Name)) {            Write-Host "VALIDATION PASS: This device [$Machine] was found in the NYUMC.ORG Domain"        } else {            Error-Handler "VALIDATION FAIL: This device [$Machine] was not found in the NYUMC.ORG Domain" $DontExitonError                   }        #endregion


        $Online = Test-Connection -ComputerName $Machine -Count 1 -Quiet

        if ([bool]$Online) {

            $WORKFLOW:Pinged++
            Write-Log "`n$Computer`t`t: Installing [$AppName version $AppVersion]" -ForegroundColor Green


            #region Identify system and user information
            $SessionInfo = Get-SessionInfo $Machine            $SessionInfo | Add-Member -Name "Online" -Type NoteProperty -Value "Yes"

            Write-Host "Session Information:"
            $SessionInfo
            ### exit
            <#            $Output = Invoke-Command -ComputerName $Machine -ScriptBlock {                #region Validate this computer has an unexpired LAPS password
                if (!(Test-Path -Path "C:\Program Files\LAPS\CSE\AdmPwd.dll")) { Error-Handler "Microsoft LAPS is not installed on this computer" $ExitonError }
                $LocalUser = "mcitadmin"                ### $LocalUserExists = (Get-LocalUser -Name $LocalUser).Enabled
                $LocalUserExists = Get-CimInstance -Query "SELECT Domain,Name FROM Win32_UserAccount WHERE (Domain = '$Machine' AND Name = '$LocalUser')" -ErrorAction SilentlyContinue
                if ([bool]$LocalUserExists) {
                    $LocalCredential = Get-LocalCredential -Machine $Machine -LocalUsername $LocalUser -LocalPassword $($ADComputer."ms-Mcs-AdmPwd")
                    if ([bool]$LocalCredential) {                        Write-Log "VALIDATION PASS: Credentials for local account [$Localuser] successfully retrieved from AD"                    } else {                        Error-Handler "VALIDATION FAIL: Credentials for local account [$Localuser] could not be retrieved from AD" $DontExitonError                    }                }
                #endregion
                ### $InstallResult = Install-MyApp -Computer $Machine -Name $InstallInfo.AppName -Version $InstallInfo.AppVersion -Command $InstallInfo.CmdtoExecute -Credential $LocalCredential
                ### $SessionInfo | Add-Member -Name "Installed" -Type NoteProperty -Value $InstallResult

            }
            #>

        } else {

            $WORKFLOW:NotPinged++
            Write-Log "`n$Machine`t`t: Cannot ping machine`n" -ForegroundColor Red
        }

    }

    Write-Progress -Activity "$Item : $Index out of $($Computers.Count)" -Status "Completed" -Completed

    
    $ReturnObject = [PSCustomObject][ordered]@{
        Pinged = $Pinged
        NotPinged = $NotPinged
    }

    ### Write-EUDEEvent $SessionLog

    return $ReturnObject

}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function QueryLDAP-ADGroups ($FilterString, $Category) {

    $ADObject = QueryLDAP-ADObject $FilterString $Category

    if ([bool]$ADObject) {
        $CanonicalGroups = $ADObject.memberof | % { ($_ -split ",")[0] -replace "CN=","" -replace "\\","" } | sort

        if ((Measure-Object -InputObject $CanonicalGroups).Count -gt 0) {
            $Result = [string]::Join(", ", $CanonicalGroups)
        } else {
            $Result = "[NONE_FOUND]"
        }

    } else {
        $Result = "[LDAP_QUERY_ERROR]"
    }

    return $Result

}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function QueryLDAP-ADObject ($Filter, $Category, $Credential=$Script:ServiceCredential) {

    switch ($Category) {
        "User" { $SearchFilter = "(&(objectCategory=User)(samAccountName=$Filter))" }
        "Group" { $SearchFilter = "(&(objectCategory=Group)(samAccountName=$Filter))" }
        "Computer" { $SearchFilter = "(&(objectCategory=Computer)(samAccountName=$Filter$))" }  # SAM Name requires terminating '$' for a computer
        "OU" { $SearchFilter = "(&(objectCategory=OrganizationalUnit)(name=$Filter))" }
        default { return $False }
    }

   
    # Decrypt the password, it must be passed as cleartext for LDAP queries
    $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Credential.Password)
    $UnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
    ### Write-Log "Username = $($Credential.Username), Unsecure Password = $UnsecurePassword"


    $Searcher = New-Object System.DirectoryServices.DirectorySearcher

    $Domain = (New-Object System.DirectoryServices.DirectoryEntry).DistinguishedName # should return DC=nyumc,DC=org
    $DomainPath = "LDAP://$Domain"
    $Searcher.SearchRoot = New-Object System.DirectoryServices.DirectoryEntry ($DomainPath, $Credential.Username, $UnsecurePassword)
    $Searcher.PageSize = 1000
    $Searcher.PropertiesToLoad.Add("Name")
    $Searcher.Filter = $SearchFilter
    $Searcher.SearchScope = "Subtree"
    ### $Searcher.Sort = New-Object System.DirectoryServices.SortOption

    ### Write-Log "LDAP Domain Root = $DomainPath"
    ### Write-Log "LDAP Search Filter = $SearchFilter"

    try { $Result = $Searcher.FindOne().GetDirectoryEntry() }
    catch { $Result = $False }
 
    $Searcher.Dispose()

    return $Result

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Set-RegValue ($Key, $Name, $NewValue, $Type) {

    $CurrentValue = (Get-ItemProperty -Path $Key -Name $Name -ErrorAction SilentlyContinue).$Name

    if (!($CurrentValue)) {

        if (!(Get-Item -Path $Key -ErrorAction SilentlyContinue)) { 
        
            Write-Log "Create new registry key [$Key]"
            New-Item -Path $Key -Credential $Script:LocalCredential -ErrorAction SilentlyContinue | Out-Null
        }

        Write-Log "Create new registry setting [$Key!$Name] with value [$NewValue]"
        New-ItemProperty -Path $Key -Name $Name -Value $NewValue -PropertyType $Type -Force -ErrorAction SilentlyContinue | Out-Null

    } else {

        ### Write-Log "Read current registry value: [$CurrentValue]"

        if ($CurrentValue -ne $NewValue) {

            Write-Log "Change registry setting [$Key!$Name] from [$CurrentValue] to [$NewValue]"
            Set-ItemProperty -Path $Key -Name $Name -Value $NewValue -Force -ErrorAction SilentlyContinue | Out-Null

        } else {

            return $False

        }

    }

    return $True

}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Write-EUDEEvent {

    param(        [object]$EventMessage    )
    $EventLogName = "EUDE"
    try {
        New-EventLog -LogName $EventLogName -Source $Script:ScriptName  -ErrorAction SilentlyContinue 
        Write-EventLog -LogName $EventLogName -Source $Script:ScriptName -EntryType Information -EventId 2216 -Message (Out-String -InputObject $EventMessage)
    }
    catch {
        Write-Log "Unable to save transcript to the [$EventLogName] Windows Event log" -ForegroundColor Red
    }

}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Write-Log {

    [cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]    param(        [string]$Message,        [string]$LogFile = $Script:TranscriptLog,        [string]$Color    )

    $ScriptName = $Script:Scriptname.ToUpper()
    $CallingFunction = ((Get-Variable MyInvocation -Scope 1).Value.MyCommand.Name).ToUpper() -replace ".ps1",""

    $LineNumber = $MyInvocation.ScriptLineNumber

    $Now = Get-Date -format "yyyy-MM-dd_HH:mm:ss"

    if (($CallingFunction -eq $ScriptName) -or ($CallingFunction -like "ALTIRISSCRIPT*")) {
        $LogMsg = "${Now}: [Line:$LineNumber (Main Section)] ${Message}"
    } else {
        $LogMsg = "${Now}: [Line:$LineNumber (Function '$CallingFunction')] ${Message}"
    }

    if ($Color) { 
        Write-Host $LogMsg -ForegroundColor $Color
    } else {
        Write-Host $LogMsg 
    }

    if (Test-Path $LogFile -ErrorAction SilentlyContinue) { Add-Content -Path $LogFile -Value $LogMsg -ErrorAction SilentlyContinue }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Write-StopScriptTime ($StartTime, $TranscriptLog, $NetworkLogFolder) {

    $StopTime = Get-Date
    $Duration = $StopTime - $StartTime
    Write-Log "Script Stop Time : $($StopTime.ToString("MM-dd-yyyy hh:mm:ss tt"))"
    Write-Log "Script executed in $($Duration.Minutes) minutes $($Duration.Seconds) seconds"
    Write-Log "********** SCRIPT ENDS **********"

    $Error.Clear()

    Stop-Transcript -ErrorAction SilentlyContinue | Out-Null

    Start-Sleep -Seconds 5

    # Copy logfile to network share
    if (Test-Path -Path $NetworkLogFolder -ErrorAction SilentlyContinue) { Copy-Item -Path $TranscriptLog -Destination $NetworkLogFolder -Force -ErrorAction SilentlyContinue | Out-Null }
}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------

clear

#region Validation
if ($PSBoundParameters.Count -eq 0) { Usage }
if (!(Is-Admin)) { Write-Warning "This script requires admin privileges!  Please elevate and re-run the script" ; exit }

$InstallInfo = @{
    AppName = $AppName
    AppShortName = $AppShortName
    AppVersion = $AppVersion
    CmdtoExecute = $CmdtoExecute
    CmdArguments = $CmdArguments
}
#endregion#region Create transcript on local drive to be added later to event log
$TranscriptLog = "$LocalTempFolder\$LogFilename.log"

# Stop any previously running transcript that may not have closed due to abnormal script termination
try { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null }
catch {}

if (!(Test-Path -Path $LocalTempFolder)) { New-Item -Path $LocalTempFolder -ItemType Directory -ErrorAction SilentlyContinue | Out-Null }
if (Test-Path -Path $TranscriptLog) { Remove-Item -Path $TranscriptLog -Force -ErrorAction SilentlyContinue }

try { Start-Transcript -Path $TranscriptLog -IncludeInvocationHeader -Force }catch { Error-Handler "Unable to start the transcript log: [$TranscriptLog]" $DontExitonError }
$ScriptStartTime = Get-Date
Write-Log "********** SCRIPT BEGINS **********"
Write-Log "Script Name       : $ScriptName"Write-Log "Script Version    : $ScriptVersion"Write-Log "Script Path       : $ScriptPath"Write-Log "Script Build      : $ScriptBuild"Write-Log "Script Start Time : $($ScriptStartTime.ToString("MM-dd-yyyy hh:mm:ss tt"))"
#endregion

#region Validate credentials of the NYULH service account 
$ServiceCredential = Get-EUDEServiceAccountCredentialsif ([bool]$ServiceCredential) {    Write-Log "VALIDATION PASS: The NYULH service account credentials were authenticated"} else {    Error-Handler "VALIDATION FAIL: The NYULH service account credentials could not be authenticated" $ExitonError}#endregion


#region Enumerate all arguments (both defaults and passed from command line) and save name and value to logfile
Write-Log "Parameters passed to script (both default and name bound):"$ParameterList = ($MyInvocation.MyCommand.Parameters).Keys
$ParameterList | % {
    $Param = Get-Variable -Name $_ -ErrorAction SilentlyContinue
    if ($Param.Value.Length -gt 0) { Write-Log "`t$($Param.Name) = $($Param.Value)" }
}
#endregion


#region Enumerate computers - can be single machine, array of machines, file list, domain group or entire OU path
$MachineList = $False
$ValidParams = @("Computername", "File", "Group", "OUPath")

foreach ($Item in $ParameterList) {
    $Param = Get-Variable -Name $Item -ErrorAction SilentlyContinue
    if ($Param.Name -in $ValidParams) {
        $MachineList = Get-MachineList -ListType $Param.Name -List $Param.Value
        break
    }
}
#endregion


#region Iterate through the list of computers
if ([bool]$MachineList) {

    $MachineList
    $InstallInfo

    ### $Results = 
    Parse-MachineList -MachineList $MachineList -InstallInfo $InstallInfo
    Write-Log "Number of machines found online = $($Results.Pinged)"    Write-Log "Number of machines not online   = $($Results.NotPinged)"    Export-SessionInfotoCSV -Object $SessionInfo -Folder $NetworkLogFolder -Filename "$AppShortName-$TodaysShortDate.CSV"

} else {

    Write-Warning "No computers were listed!"

}
#endregion

    
#region Save session data to CSV in the network log folder
Write-StopScriptTime $StartTime $TranscriptLog $NetworkLogFolder
#endregion

