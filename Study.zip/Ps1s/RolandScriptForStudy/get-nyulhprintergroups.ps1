﻿#==========================================================================================================================================# Program	: GET-NYULHPRINTERGROUPS.PS1# Version	: 1.1.0# Date		: Aug 23 2021# Author	: Roland Thomas# Team		: MCIT / End User Device Engineering## This script will retrieve the computers in a list of groups as specified by the OU that the groups are in# No error checking is done on whether the group contains non-computer objects## 02-29-20 (v1.0.0): First release# 08-23-21 (v1.1.0): Added better error handling#Requires -Version 3.0[cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]param(    [string]$GroupOU = "nyumc.org/NYULMC Groups/Security/EUDE_Groups/Printers",    [switch]$AddComputers = $True,    [switch]$ShowProgress = $False,    [switch]$CommaDelimiter,    [switch]$PrintServerCountsOnly = $False)
$ScriptName = $MyInvocation.MyCommand.Name.ToUpper()
$ErrorActionPreference = "SilentlyContinue"

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

function _Error-Handler {

    param(        [string]$ScriptErrorMessage,        [System.Object]$PSError    )

    Write-Warning $ScriptErrorMessage

    if ([bool]$PSError) {
        if ([bool]$PSError.Exception.Message) { Write-Debug "Error message: $($PSError.Exception.Message)" }
        if ([bool]$PSError.Exception.ErrorCode) { Write-Debug "Error code: $($PSError.Exception.ErrorCode)" }
        if ([bool]$PSError.InvocationInfo.Line) { Write-Debug "Line of Code: $($PSError.InvocationInfo.Line)" }
    }

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-CNtoDN([string]$CanonicalName) {

    # Parsing if an empty string is sent 
    if ([string]::IsNullOrEmpty($CanonicalName)) { return $Null }


    # Split the canonical name into separate bits 
    $Parts = $CanonicalName.Split("//")

    foreach ($Part in $Parts) {
        if ($Parts.IndexOf($Part) -eq 0) {
            $DistinguishedName = "DC=nyumc,DC=org"
        } else {
            $DistinguishedName = "OU=$Part," + $DistinguishedName
        }
    }

    return $DistinguishedName

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Convert-CSVtoXLSX($OutputCSV) {

    $OutputXLS = $OutputCSV -replace "csv", "xlsx"

    $Excel = New-Object -ComObject Excel.Application
    $Excel.Visible = $False                                   # Set to $true if you want actually see the script interact with Excel
    $Excel.DisplayAlerts = $False

    $WorkBook = $Excel.Workbooks.Open($OutputCSV)
 
    $WorkSheet = $WorkBook.Worksheets.Item(1)


    # Change page formatting
    $WorkSheet.Cells.Font.Size = 11
    $WorkSheet.Cells.Font.Name = "Consolas"
    $WorkSheet.Rows(1).Font.Bold = $True
    $WorkSheet.Rows(1).Font.Underline = $True
    $WorkSheet.Cells.VerticalAlignment = -4160               # xlVAlignTop - https://docs.microsoft.com/en-us/office/vba/api/excel.xlvalign


    # Enable filters on all columns
    [void]$WorkSheet.Cells.EntireColumn.AutoFilter() 

    
    # Highlight used cells
    [void]$WorkSheet.Range("A1").Select
    $Rows = $WorkSheet.UsedRange.Rows
    $Columns = $WorkSheet.UsedRange.Columns
    [void]$WorkSheet.UsedRange.Select

    $Range = $worksheet.UsedRange.Cells
    $ColCount = $Range.columns.count
    $CopyRange = $Worksheet.Range("1:$ColCount")
    $WorkSheet.Cells.Borders.LineStyle = 1 


    # Enable autofit on all rows and columns
    ### [void]$WorkSheet.Cells.EntireColumn.AutoFit()
    ### [void]$WorkSheet.Cells.EntireRow.AutoFit()
    [void]$WorkSheet.Columns.EntireColumn.AutoFit()
    [void]$WorkSheet.Rows.EntireRow.AutoFit()


    # Set 'PrintCommunication' property to False to force changes to PageSetup properties
    $Excel.PrintCommunication = $False

    # Set page size and orientation
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.Zoom = $False               # Set Zoom to False to force changes
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.PrintTitleRows = '$1:$1'    # print title header on every page
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.PaperSize = 5               # 5 = xlPaperLegal
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.Orientation = 2             # Set to Landscape mode
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.FitToPagesWide = 1          # Fit all columns
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.FitToPagesTall = $False     # to one page

    # Set the page margins to "Narrow" size
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.LeftMargin = $Excel.InchesToPoints(0.25)
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.RightMargin = $Excel.InchesToPoints(0.25)
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.TopMargin = $Excel.InchesToPoints(0.75)
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.BottomMargin = $Excel.InchesToPoints(0.75)
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.HeaderMargin = $Excel.InchesToPoints(0.3)
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.FooterMargin = $Excel.InchesToPoints(0.3)

    # Once changes have been made, set to True to commit the changes to PageSetup properties 
    $Excel.PrintCommunication = $True


    # Save the file in Excel XLSX format
    try { 
        $WorkBook.SaveAs($OutputXLS, 51)
        $WorkBook.Saved = $True
    }
    catch { $OutputXLS = $False }


    $Excel.Quit()

    Remove-Variable -Name Excel

    return $OutputXLS

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
cls#region Start running the clock$Script_StartTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"
Write-Output "`nProcessing Start`t: $Script_StartTime"
#endregion#region Get count of print queues in each print server$ServerConfig = "\\shares.nyumc.org\eude\misc\printer\server\config.PrintServers.txt"
$Servers = Get-Content $ServerConfig -ErrorAction SilentlyContinueWrite-Host "`n    - Counting number of printers for all print servers`n" Foreach ($Server in $Servers) {    $Server = $Server.ToUpper()    Write-Host "`t- Print Server [$Server]: " -NoNewline    if (Test-Connection -ComputerName $Server -Count 10 -Quiet) {        try {            $PrinterQueueList = (Get-Printer -ComputerName $Server -ErrorAction SilentlyContinue)            $PrinterQueueCount = $PrinterQueueList.Count            Write-Host "$PrinterQueueCount print queues" -ForegroundColor Green        }        catch {            Write-Host "ERROR: $($Error[0].Exception.Message)" -ForegroundColor Yellow        }    } else {        Write-Host "unreachable" -ForegroundColor Red    }}#endregionif (!$PrintServerCountsOnly) {    #region Get list of all groups
    $SearchBase = Convert-CNtoDN $GroupOU
    Write-Output "`n    - Enumerating all groups found in OU: $GroupOU" 

    $GroupList = (Get-ADGroup -Filter "Name -like 'grp.prn.*'" -SearchBase $SearchBase -SearchScope OneLevel).Name | Sort
    Write-Output "`n    - Total groups found = $($GroupList.Count)"
    #endregion
    #region Get list of all computers in every group    $TimeStamp = Get-Date -Format "yyyyMMdd-HHmmss"    $OutputCSV = "C:\TEMP\NYULHPRINTERGROUPS-$TimeStamp.csv"    Remove-Item $OutputCSV -Force -ErrorAction SilentlyContinue    Write-Output "`n    - Parsing each group..."    $PrinterGroupTable = @()    foreach ($Group in $GroupList) {        $Error.Clear()        $Index = [array]::Indexof($GroupList, $Group) + 1        # Display progress bar
        $PercentComplete = [int32](($Index / $GroupList.Count) * 100)
        Write-Progress -Activity "Now Scanning [$Index] out of [$($GroupList.Count)] Groups" `
            -CurrentOperation "Reading group name:  $Group" `
            -Status "$PercentComplete% complete" -PercentComplete $PercentComplete        if ($ShowProgress) { Write-Host "`t- Groupname = $Group" -NoNewline }        $ParsedName = $Group -split "\."        $PrintServer = $ParsedName[2]        $PrintQueue = $ParsedName[3]        $PrintQueuePath = "\\$PrintServer\$PrintQueue"        $PrinterInfo = Get-Printer -ComputerName $PrintServer -Name $PrintQueue -ErrorAction SilentlyContinue        if ([bool]$PrinterInfo) {            if ($ShowProgress) { Write-Host " (queue found = $PrintQueuePath)" -ForegroundColor Green }            $PrintQueueExists = $True        } else {            if ($ShowProgress) { Write-Host " (cannot access queue = $PrintQueuePath)" -ForegroundColor Red }            $PrintQueueExists = $False        }        $PrinterGroup = [PSCustomObject][ordered]@{
            "GroupName" = $Group;
            "PrintServer" = $PrintServer;
            "PrintQueue" = $PrintQueue;
             "QueueExists" = $PrintQueueExists;
            "PrinterName" = $PrinterInfo.Name;
            "ShareName" = $PrinterInfo.ShareName;
            "PrinterStatus" = $PrinterInfo.PrinterStatus;
            "DriverName" = $PrinterInfo.DriverName;
            "PortName" = $PrinterInfo.PortName;
            "Shared" = $PrinterInfo.Shared
        }        if ($AddComputers) { 
            try {                $Computers = (Get-ADGroupMember -Identity $Group -ErrorAction SilentlyContinue).Name | sort Name

                if ($CommaDelimiter) { $ComputerList = $Computers -join ", " } else { $ComputerList = $Computers -join "`n" }

                $PrinterGroup | Add-Member -MemberType NoteProperty -Name "MappedComputers" -Value $ComputerList
                $PrinterGroup | Add-Member -MemberType NoteProperty -Name "MappedCount" -Value $Computers.Count

            }
            catch {
                $ErrorMessage = "Unable to get members of group [$Group]"
                _Error-Handler -ScriptErrorMessage ("`t- " + $ErrorMessage) -PSError $Error[0]
                $PrinterGroup | Add-Member -MemberType NoteProperty -Name "ErrorMessage" -Value ($ErrorMessage + "`n" + $Error[0])
            }

        }

    
        $PrinterGroupTable += $PrinterGroup


        ### if ($Index -eq 15) { break }  # Enable for testing

    }
    #endregion


    #region Convert CSV output to Excel file
    $PrinterGroupTable | Export-Csv -Path $OutputCSV -Append -NoTypeInformation

    Write-Host "`n    - Converting output [$OutputCSV] to Excel format" -NoNewline

    $Process_StartTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"

    ### [IO.File]::OpenWrite($OutputCSV).Close()
    $OutputXLS = Convert-CSVtoXLSX $OutputCSV

    if ([bool]$OutputXLS) {
        $Process_EndTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"
        $Process_TimeDiff = New-TimeSpan -Start $Process_StartTime -End $Process_EndTime
        Write-Output " (done in $($Process_TimeDiff.Seconds) seconds)"
        Write-Output "`n    - Opening Excel file: $OutputXLS"
        Start-Process -FilePath "Excel.exe" -ArgumentList $OutputXLS -WindowStyle Maximized
    } else {
        Write-Host " (unable to convert - check CSV file instead)" -ForegroundColor Yellow
    }
    #endregion

}


#region Stop the clock and exit$Script_EndTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"
$TimeDiff = New-TimeSpan -Start $Script_StartTime -End $Script_EndTime

Write-Output "`n`nProcessing Stop`t`t: $Script_EndTime"
Write-Output "`nScript completed in $($TimeDiff.Hours) hours $($TimeDiff.Minutes) minutes $($TimeDiff.Seconds) seconds`n`n"
#endregion