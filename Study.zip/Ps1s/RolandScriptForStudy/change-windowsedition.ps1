﻿#==========================================================================================================================================# Program	: CHANGE-WINDOWSEDITION.PS1# Version	: 1.0.0# Date		: Apr 29 2022# Author	: Roland Thomas# Team		: MCIT / End User Device Engineering## This script will change the edition of a Windows 10 computer to either "Professional" or "Enterprise":#   - change product key and activate Windows 10 on the KMS./NYUMC.ORG server## 04-29-22 (v1.0.0): First release#Requires -Version 3.0

[cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]
param(
    [string]$KMSServer = "kms.nyumc.org",
    [string]$KMSServerPort = "1688",
    [ValidateSet("Pro", "Enterprise")]
    [string]$Edition,
    [switch]$Flip = $True,
    [switch]$EnableDebug = $False
)


#region Initialize general-purpose variables
$ScriptFileName = $MyInvocation.MyCommand.Definition
if ([bool]$ScriptFileName) {  # need to check because apparently $MyInvocation path is not capture if script runs from Workspace One cloud instance
    $ScriptName = (Split-Path $ScriptFileName -Leaf).ToUpper()
    $ScriptVersion = "v1.0.0 (042922)"
    $ScriptBuild = (Get-ChildItem -Path $ScriptFileName).LastWriteTime.ToString("MM-dd-yyyy hh:mm:ss tt")
    if ($ScriptFileName -like "C:\*") {
        $ScriptFullPath = $ScriptFileName.ToLower()
    } else {
        $ScriptUNCPath = (Resolve-Path -Path $ScriptFileName).Drive.DisplayRoot + ((Split-Path -Path $ScriptFileName -NoQualifier) -replace $ScriptName,"")
        $ScriptFullPath = ($ScriptUNCPath + $ScriptName).ToLower()
    }
} else {
    $ScriptName = "CHANGE-WINDOWSEDITION.PS1"
}


#region Prod / Dev context variables
if ($EnableDebug) {
    $DebugPreference = "Continue"
    $ErrorActionPreference = "Continue"
    $VerbosePreference = "Continue"
} else {
    $DebugPreference = "SilentlyContinue"
    $ErrorActionPreference = "SilentlyContinue"
    $VerbosePreference = "SilentlyContinue"
}
#endregion


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function _Error-Handler {

    param(
    [string]$ScriptErrorMessage,
    [switch]$ShowException,
    [switch]$ExitonError
    )

    Write-Warning $ScriptErrorMessage

    if ($ShowException) {
        if ([bool]$_.Exception.Message) { Write-Debug "Error message: $($_.Exception.Message)" -ErrorAction SilentlyContinue }
        if ([bool]$_.Exception.ErrorCode) { Write-Debug "Error code: $($_.Exception.ErrorCode)" -ErrorAction SilentlyContinue }
        if ([bool]$_.InvocationInfo.Line) { Write-Debug "Line of Code: $($_.InvocationInfo.Line)" -ErrorAction SilentlyContinue }
    }

    $Error.Clear()

    if ($ExitonError) { exit }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-DNtoCN ([string]$DistinguishedName) {

    # Parsing if an empty string is sent 
    if ([string]::IsNullOrEmpty($DistinguishedName)) { return $Null }


    # Strip off leading LDAP prefix if there is any
    if ($DistinguishedName -like "LDAP://*") { $DistinguishedName = $DistinguishedName -replace "LDAP://","" }


    # Split the distinguished name into separate bits 
    $Parts = $DistinguishedName.Split(",")
 
    foreach ($Part in $Parts) {
        if ($Part -like "OU=*") {
            $Subpart = $Part -replace "OU=",""
                $CanonicalName = "/$Subpart" + $CanonicalName
        }
    }

    $CanonicalName = $env:USERDNSDOMAIN + $CanonicalName

    return $CanonicalName

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Export-SessionInfotoCSV {

    [cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]
    param(
        [pscustomobject]$Object,
        [string]$Folder,
        [string]$Filename
    )

    $FileSizeLimit = [int]500  # max logfile size in kilobytes
    $ExportCSVFile = "$Folder\$Filename"

    if (Test-Path -Path $ExportCSVFile -ErrorAction SilentlyContinue) {

        $FileInfo = Get-ChildItem -Path $ExportCSVFile -Force -ErrorAction SilentlyContinue
        $FileSize = [int]($FileInfo.Length / 1KB)  ### '1KB' is language constant that means 1 kilobyte
        $FileTimeStamp = $FileInfo.LastWriteTime.ToString("MMddyyyy-HHmmss")
        $NewFileName = $FileInfo.BaseName + "-ARCHIVE-" + $FileTimeStamp + $Fileinfo.Extension
    
        if ($FileSize -ge $FileSizeLimit) {

            Rename-Item -Path $ExportCSVFile -NewName $NewFileName
            Start-Sleep -Seconds 3
            $Object | Export-Csv -Path $ExportCSVFile -NoTypeInformation -ErrorAction SilentlyContinue  # rename old file and create new one

        } else {

            $Object | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1 | Add-Content -Path $ExportCSVFile -ErrorAction SilentlyContinue # file already exist, append without header

        }

    } else {

        $Object | Export-Csv -Path $ExportCSVFile -NoTypeInformation -ErrorAction SilentlyContinue  # file does not exist, create with header

    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SessionInfo ($Machine) {

    $IPAddress = (Test-Connection -ComputerName $Machine -Count 1).IPV4Address.IPAddressToString

    $DNSDomain = (Get-CimInstance -Namespace "root\cimv2" -Class Win32_NetworkAdapterConfiguration -ComputerName $Machine -OperationTimeoutSec 30 `
        -Property * -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | ? {($_.IPEnabled -eq "True") -and ($_.DefaultIPGateway -ne $Null)}).DNSDomain

    $DNSName = ("$Machine.$DNSDomain").ToLower()

    $Subnet = Get-Subnet $Machine

    $SystemInfo = Get-SystemInfo $Machine

    $Value = Get-ItemPropertyValue -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\State\Machine" -Name "Distinguished-Name" -ErrorAction SilentlyContinue
    if ([bool]$Value) {
        $CurrentOU = Convert-DNtoCN -DistinguishedName ($Value -replace "LDAP://CN=$Machine,","")
    }

    $SessionInfo = [PSCustomObject][ordered]@{
        HostName = $Machine
        DNSName = $DNSName
        IPAddress = $IPAddress
        Subnet = if ([bool]$Subnet) { $Subnet } else { "UNKNOWN" }
        Manufacturer = $SystemInfo.Manufacturer
        Model = $SystemInfo.Model
        BIOS = $SystemInfo.BIOS
        Organization = $SystemInfo.Organization
        Owner = $SystemInfo.Owner
        SerialNumber = $SystemInfo.SerialNumber
        OldOSName = $SystemInfo.OSFullName
        OSUpgradeDate = $SystemInfo.OSUpgradeDate
        LastBootTime = $SystemInfo.BootTime
        CurrentOU = $CurrentOU
    }

    return $SessionInfo
    
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SystemInfo ($Machine) {  

    $ComputerInfo = if ($Machine.ToUpper() -eq $env:COMPUTERNAME.ToUpper()) { Get-ComputerInfo } else { Invoke-Command -ComputerName $Machine -ScriptBlock { Get-ComputerInfo } }


    # Windows 10 versions above 2004 do not return correct version in GET-COMPUTERINFO cmdlet so need to extract directly from registry
    $RegValue = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name "DisplayVersion" -ErrorAction SilentlyContinue).DisplayVersion
   
    if ([bool]$RegValue) { 
        $WindowsVersion = $RegValue
    } else {
        $WindowsVersion = $ComputerInfo.WindowsVersion
    }


    $SystemInfo = [PSCustomObject][ordered]@{
        Organization = $ComputerInfo.WindowsRegisteredOrganization
        Owner = $ComputerInfo.WindowsRegisteredOwner
        Manufacturer = $ComputerInfo.CsManufacturer
        Model = $ComputerInfo.CsModel
        BIOS = "$($ComputerInfo.BiosSMBIOSBIOSVersion) ($($ComputerInfo.BiosReleaseDate))"
        SerialNumber = $ComputerInfo.BiosSeralNumber
        WindowsEdition = $ComputerInfo.WindowsProductName
        WindowsVersion = $WindowsVersion
        OSBuild = $ComputerInfo.OSVersion
        OSFullName = "$($ComputerInfo.WindowsProductName) version $WindowsVersion (build $($ComputerInfo.OSVersion))"
        OSUpgradeDate = $ComputerInfo.OSInstallDate
        BootTime = $ComputerInfo.OSLastBootUpTime
    }

    return $SystemInfo

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-Subnet($Machine) {

    # See: https://social.technet.microsoft.com/Forums/windows/en-US/92d29727-de8c-41cc-b7e1-38e852069fda/powershell-subnet-function?forum=winserverpowershell

    try {
        $NetworkAdapters = Get-CimInstance -Namespace "root\cimv2" -Class Win32_NetworkAdapterConfiguration -ComputerName $Machine -OperationTimeoutSec 30 `
             -Property * -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | ? {($_.IPEnabled -eq "True") -and ($_.DefaultIPGateway -ne $Null)}

        $NetworkAdapters | % {
 
           # Compute the Subnet (Network ID) from the IP Address and Subnet Mask
           $IPAddress = @($_.IPAddress)[0]
           $IPAddress_Octets = $IPAddress -split "\."  # Split up IP Address into array of 4 octets
           $SubnetMask_Octets = @($_.IPSubnet)[0] -split "\."  # Do the same for the subnet mask
           $Subnet_Octets = @{}# Initialize hashtable for the subnet

           for ($i=0; $i -le 3; $i++) {# Do binary-and on all octets
               [int32]$Subnet_Octets[$i] = [int32]$IPAddress_Octets[$i] -band [int32]$SubnetMask_Octets[$i]
               $Subnet_NetworkID += ($Subnet_Octets[$i]).ToString() + "."  # Concatenate the result back into dotted-notation
           }

           $Subnet_NetworkID = $Subnet_NetworkID -replace ".$" # Strip off last dot (artifact of last command)

        }

    }

    catch { $Subnet_NetworkID = "OFFLINE" }

    return $Subnet_NetworkID

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function IsAdmin() {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}

# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------function Write-Log {    [cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]    param(        [string]$Message,        [string]$LogFile = $Script:TranscriptLog,        [string]$Color,        [string]$CallingFunction,        [string]$LineNumber    )    $ScriptName = $Script:Scriptname.ToUpper()    if (!$CallingFunction) { $CallingFunction = ((Get-Variable MyInvocation -Scope 1).Value.MyCommand.Name).ToUpper() } #-replace ".ps1",""     if (!$LineNumber) { $LineNumber = $MyInvocation.ScriptLineNumber }    $Now = Get-Date -format "yyyy-MM-dd_HH:mm:ss"    if ($CallingFunction -eq $ScriptName) {        $LogMsg = "${Now}: [Line:$LineNumber (Main Code Section)] ${Message}"    } else {        $LogMsg = "${Now}: [Line:$LineNumber (Function '$CallingFunction')] ${Message}"    }    if ($Color) {         Write-Host $LogMsg -ForegroundColor $Color    } else {        Write-Output $LogMsg     }    if (Test-Path $LogFile -ErrorAction SilentlyContinue) { Add-Content -Path $LogFile -Value $LogMsg -ErrorAction SilentlyContinue }}# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
cls


#region Validation
if (!(IsAdmin)) { _Error-Handler -ScriptErrorMessage "This script must run with elevated rights!" -ExitonError }
#endregion


#region Create transcript log
$Machine = $env:COMPUTERNAME.ToUpper()

$LocalLogFolder = "C:\TEMP"
$LogFilename = "$Machine-CHANGEEDITION"
$TranscriptLog = "$LocalLogFolder\$LogFilename.log"
$NetworkLogFolder = "\\shares.nyumc.org\eude\inventory\changeedition"
$SessionInfoLog = "SESSIONLOG.CSV"


# Stop any previously running transcript that may not have closed due to abnormal script termination
try { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null }
catch {}

if (!(Test-Path -Path $LocalLogFolder)) { New-Item -Path $LocalLogFolder -ItemType Directory -ErrorAction SilentlyContinue | Out-Null }
if (Test-Path -Path $TranscriptLog) { Remove-Item -Path $TranscriptLog -Force -ErrorAction SilentlyContinue }

try { Start-Transcript -Path $TranscriptLog -IncludeInvocationHeader -Force }
catch { _Error-Handler -ScriptErrorMessage "Unable to start the transcript log: [$TranscriptLog]" -ExitonError }
#endregion


#region Get system information
$StartTime = Get-Date

Write-Log "********** SCRIPT BEGINS **********"
Write-Log "Script Name       : $ScriptName"
Write-Log "Script Version    : $ScriptVersion"
Write-Log "Script Build      : $ScriptBuild"
Write-Log "Script Full Path  : $ScriptFullPath"
Write-Log "Script Start Time : $($StartTime.ToString("MM-dd-yyyy hh:mm:ss tt"))"

$SessionInfo = Get-SessionInfo $Machine
$SessionInfo
#endregion


#region Change edition, install product key and activate license

# Check if we can reach the KMS server
$Error.Clear()

$KMSServerResolved = (nslookup $KMSServer | ConvertFrom-String | ? { $_.P1 -like "*Name*" }).P2

Write-Log "Connecting to NYULH KMS Server [$KMSServer`:$KMSServerPort ($KMSServerResolved)]"

if ((Test-NetConnection -ComputerName $KMSServer -Port $KMSServerPort -ErrorAction SilentlyContinue).tcptestsucceeded) {

    try {

        # Need to register with the KMS before activating Windows
        Write-Log "Registering KMS service"
        $KMSService = Get-WMIObject -Class SoftwareLicensingService -ErrorAction SilentlyContinue
        $KMSService.SetKeyManagementServiceMachine($KMSServer) | Out-Null
        $KMSService.SetKeyManagementServicePort($KMSServerPort) | Out-Null
        $Status = "KMS Service successfully started"


        # Check if this license of Windows is already set to the edition that we want to change
        Write-Log "Getting info on current license"
        $ProductProperties = @("Name", "ApplicationID", "LicenseFamily", "LicenseStatus", "PartialProductKey")

        $LicenseInfo = Get-CimInstance -ClassName SoftwareLicensingProduct -Property $ProductProperties -Filter "Name LIKE 'Windows%' AND LicenseStatus = '1'" -ErrorAction SilentlyContinue | select $ProductProperties
        $LicenseInfo | ft

        $OldEdition = $LicenseInfo.LicenseFamily


        # This is just for debugging, to make it easier to do unit tests quickly
        if ($Flip) {
            if ($OldEdition -like "*Pro*") { $Edition = "Enterprise" }
            if ($OldEdition -like "*Enterprise*") { $Edition = "Pro" }
        }


        if ($OldEdition -like "*$Edition*") {

            $Status = "Windows Edition is already: $OldEdition"
            Write-Log $Status

        } else {

            # Parse the product key for the new edition
            Write-Log "Changing license on current edition [$($LicenseInfo.LicenseFamily)]"

            $ValidEdition = $True

            switch ($Edition) {
                "Pro" { $ProductKey = "W269N-WFGWX-YVC9B-4J6C9-T83GX" }
                "Enterprise" { $ProductKey = "NPPR9-FWDCX-D2C8J-H872K-2YT43" }
                default {
                    $Status = "Invalid new edition specified: $Edition"
                    Write-Log $Status
                    $ValidEdition = $False
                }
            }


            if ($ValidEdition) {

                try {
                    Write-Log "Installing new product key for edition [$Edition]"
                    $KMSService.InstallProductKey($ProductKey) | Out-Null

                    $Status = "Successfully installed product key"

                    Start-Sleep -Seconds 5
        
                    try {
                        Write-Log "Activating license"
                        $KMSService.RefreshLicenseStatus() | Out-Null

                        Start-Sleep -Seconds 5

                        Write-Log "Getting info again on license"
                        $LicenseInfo = Get-CimInstance -ClassName SoftwareLicensingProduct -Property $ProductProperties -Filter "Name LIKE 'Windows%' AND LicenseStatus = '1'" -ErrorAction SilentlyContinue | select $ProductProperties
                        $LicenseInfo | ft

                        $NewEdition = $LicenseInfo.LicenseFamily
                        $Status = "License changed.  New edition is [$NewEdition]"
                        Write-Log $Status

                    }
                    catch {
                        $Status = "Error in trying to activate Windows"
                        _Error-Handler -ScriptErrorMessage $Status -ShowException
                    }
                }

                catch {
                    $Status = "Error in trying to change product key"
                    _Error-Handler -ScriptErrorMessage $Status -ShowException
                }

            }

        }

    }
    catch {
        $Status = "Error in trying to change Windows license to [$Edition]"
        _Error-Handler -ScriptErrorMessage $Status -ShowException
    }

} else {
    $Status = "Unable to ping [$KMSServer`:$KMSServerPort]"
    _Error-Handler -ScriptErrorMessage $Status -ShowException 

}
#endregion


#region Stop and the transcript
$StopTime = Get-Date
$Duration = $StopTime - $StartTime
Write-Log "Script Stop Time : $($StopTime.ToString("MM-dd-yyyy hh:mm:ss tt"))"
Write-Log "Script executed in $($Duration.Minutes) minutes $($Duration.Seconds) seconds"
Write-Log "********** SCRIPT ENDS **********"

$Error.Clear()

Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
Start-Sleep -Seconds 5  # give enough time to close the file and flush any data streams
#endregion


#region Save log output to network share
# Save session data to CSV in the network log folder
if ([bool]$SessionInfo) {
    $SessionInfo | Add-Member -NotePropertyName OldEdition -NotePropertyValue $OldEdition -Force
    $SessionInfo | Add-Member -NotePropertyName NewEdition -NotePropertyValue $NewEdition -Force
    $SessionInfo | Add-Member -NotePropertyName Status -NotePropertyValue $Status -Force
    Export-SessionInfotoCSV -Object $SessionInfo -Folder $NetworkLogFolder -Filename $SessionInfoLog
}

# Copy logfile to network share
if (Test-Path -Path "$NetworkLogFolder" -ErrorAction SilentlyContinue) {
    Copy-Item -Path $TranscriptLog -Destination "$NetworkLogFolder" -Force -ErrorAction SilentlyContinue | Out-Null
}
#endregion
