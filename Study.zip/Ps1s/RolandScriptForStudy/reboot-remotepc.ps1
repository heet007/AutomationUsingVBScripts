#==========================================================================================================================================
# Program			: REBOOT-REMOTEPC.PS1
# Version			: 3.0.0
# Date				: March 13 2021
# Author			: Roland Thomas
# Team				: MCIT / End User Device Engineering
#
# This script will remotely reboot a single machine or list of machines.
#
# Usage				: REBOOT-REMOTEPC.PS1 [-Computers <Computer1, Computer2, Computer3,...> | -List <file>] [-ForceReboot] [-Report] [-Email]
#
#                     - Computer will not reboot if it is in use (user is logged in) unless -FORCEREBOOT switch is used
#                     - Output can be saved to \\shares.nyumc.org\eude\reports folder as Excel spreadsheet with -REPORT switch
#                     - Report can be emailed to user running the script with -EMAIL switch
#
# 02-21-17 (v1.0.0)	: First release.
# 07-25-19 (v2.0.0)	: Code rewrite.
# 03-13-21 (v3.0.0)	: Code rewrite.


[cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]
param(
    [string[]]$Computers,
    [string]$List,
    [switch]$ForceReboot = $False,
    [switch]$Report = $False,
    [switch]$Email = $False,
    [switch]$Testing = $False
)


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

#Initialize script-specific variables
$ScriptFileName = $PSCommandPath.ToUpper()
$ScriptFileInfo = Get-ChildItem -Path $ScriptFileName
$ScriptVersion = "v3.0.0 (031321)"
$ScriptBuild = $ScriptFileInfo.LastWriteTime.ToString("MM-dd-yyyy hh:mm:ss tt")

$ScriptName = $ScriptFileInfo.Name
$ScriptUNCPath = (Resolve-Path -Path $ScriptFileName).Drive.DisplayRoot + ((Split-Path -Path $ScriptFileName -NoQualifier) -replace $ScriptName,"")

$ScriptInfo = [PSCustomObject]@{
    Filename = $ScriptFileInfo.Name
    Fullname = $Scriptfileinfo.FullName
    Name = $ScriptFileInfo.BaseName
    Version = $ScriptVersion
    Build = $ScriptBuild
    Directory = $ScriptFileInfo.Directory
    UNCPath = $ScriptUNCPath
}


#Initialize general-purpose variables
$Today = Get-Date -format "yyyyMMdd-HHmmss"
$UserName = $env:USERNAME
$LocalTempFolder = "c:\temp"
$ReportFolder = "\\shares.nyumc.org\eude\reports"
$ErrorActionPreference = "SilentlyContinue"


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

function _Error-Handler {

    param(
        [string]$ScriptErrorMessage,
        [switch]$ShowException,
        [switch]$ExitonError
    )

    Write-Warning $ScriptErrorMessage

    if ($ShowException) {
        if ([bool]$_.Exception.Message) { Write-Debug "Error message: $($_.Exception.Message)" }
        if ([bool]$_.Exception.ErrorCode) { Write-Debug "Error code: $($_.Exception.ErrorCode)" }
        if ([bool]$_.InvocationInfo.Line) { Write-Debug "Line of Code: $($_.InvocationInfo.Line)" }
    }

    if ($ExitonError) {
        exit
    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-DNtoCN([string]$DistinguishedName) {

    # Parsing if an empty string is sent 
    if ([string]::IsNullOrEmpty($DistinguishedName)) { return $Null }


    # Strip off leading LDAP prefix if there is any
    if ($DistinguishedName -like "LDAP://*") { $DistinguishedName = $DistinguishedName -replace "LDAP://","" }


    # Split the distinguished name into separate bits 
    $Parts = $DistinguishedName.Split(",")
 
    foreach ($Part in $Parts) {
        if ($Part -like "OU=*") {
            $Subpart = $Part -replace "OU=",""
            $CanonicalName = "/$Subpart" + $CanonicalName
        }

    }

    $CanonicalName = "nyumc.org" + $CanonicalName

    return $CanonicalName

}

<#
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-CSVtoXLSX($ReportFile) {

    $ReportFile_XLSX = $ReportFile -replace "csv", "xlsx"

    $Excel = New-Object -ComObject Excel.Application
    $Excel.Visible = $False                                 # Set to $true if you want actually see the script interact with Excel
    $Excel.DisplayAlerts = $False

    $WorkBook = $Excel.Workbooks.Open($ReportFile)
 
    #$WorkSheet = $WorkBook.Worksheets.Item(1)

    $Excel.Rows.Item(1).Font.Bold = $True
    $Excel.Rows.Item(1).Font.Underline = $True

    [void]$Excel.Cells.EntireColumn.AutoFilter()
    $Excel.Columns.Borders.LineStyle = 1 
    [void]$Excel.Cells.EntireColumn.AutoFit()

    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.Orientation = 2             # Set to Landscape mode
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.FitToPagesWide = 1          # Fit all columns
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.FitToPagesTall = $False     # to one page

    $WorkBook.SaveAs($ReportFile_XLSX, 51)

    $WorkBook.Close()
    $Excel.Quit()

    Remove-Variable -Name Excel

}
#>

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-CSVtoXLSX($OutputCSV) {

    $OutputXLS = $OutputCSV -replace "csv", "xlsx"

    $Excel = New-Object -ComObject Excel.Application
    $Excel.Visible = $False                                   # Set to $true if you want actually see the script interact with Excel
    $Excel.DisplayAlerts = $False

    $WorkBook = $Excel.Workbooks.Open($OutputCSV)
 
    $WorkSheet = $WorkBook.Worksheets.Item(1)


    # Change page formatting
    $WorkSheet.Cells.Font.Size = 11
    $WorkSheet.Cells.Font.Name = "Consolas"
    $WorkSheet.Rows(1).Font.Bold = $True
    $WorkSheet.Rows(1).Font.Underline = $True
    $WorkSheet.Cells.VerticalAlignment = -4160               # xlVAlignTop - https://docs.microsoft.com/en-us/office/vba/api/excel.xlvalign


    # Enable filters on all columns
    [void]$WorkSheet.Cells.EntireColumn.AutoFilter() 

    
    # Highlight used cells
    [void]$WorkSheet.Range("A1").Select
    $Rows = $WorkSheet.UsedRange.Rows
    $Columns = $WorkSheet.UsedRange.Columns
    [void]$WorkSheet.UsedRange.Select

    $Range = $worksheet.UsedRange.Cells
    $ColCount = $Range.columns.count
    $CopyRange = $Worksheet.Range("1:$ColCount")
    $WorkSheet.Cells.Borders.LineStyle = 1 


    # Enable autofit on all rows and columns
    ### [void]$WorkSheet.Cells.EntireColumn.AutoFit()
    ### [void]$WorkSheet.Cells.EntireRow.AutoFit()
    [void]$WorkSheet.Columns.EntireColumn.AutoFit()
    [void]$WorkSheet.Rows.EntireRow.AutoFit()


    # Set 'PrintCommunication' property to False to force changes to PageSetup properties
    $Excel.PrintCommunication = $False

    # Set page size and orientation
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.Zoom = $False               # Set Zoom to False to force changes
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.PrintTitleRows = '$1:$1'    # print title header on every page
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.PaperSize = 5               # 5 = xlPaperLegal
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.Orientation = 2             # Set to Landscape mode
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.FitToPagesWide = 1          # Fit all columns
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.FitToPagesTall = $False     # to one page

    # Set the page margins to "Narrow" size
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.LeftMargin = $Excel.InchesToPoints(0.25)
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.RightMargin = $Excel.InchesToPoints(0.25)
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.TopMargin = $Excel.InchesToPoints(0.75)
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.BottomMargin = $Excel.InchesToPoints(0.75)
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.HeaderMargin = $Excel.InchesToPoints(0.3)
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.FooterMargin = $Excel.InchesToPoints(0.3)

    # Once changes have been made, set to True to commit the changes to PageSetup properties 
    $Excel.PrintCommunication = $True


    # Save the file in Excel XLSX format
    try { 
        $WorkBook.SaveAs($OutputXLS, 51)
        $WorkBook.Saved = $True
    }
    catch { $OutputXLS = $False }


    $Excel.Quit()

    Remove-Variable -Name Excel

    ### return $OutputXLS

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-CurrentRemoteUser ($Machine) {

    try {
        $ShellName = Invoke-Command -ComputerName $Machine -ScriptBlock { (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "Shell" -ErrorAction SilentlyContinue -Verbose)."Shell" }
        $ProcessName = (Split-Path -Path $ShellName -Leaf) -replace """",""

        $Process = Get-CimInstance -Namespace "root\cimv2" -Class Win32_Process -ComputerName $Machine -OperationTimeoutSec 30 -Filter "Name='$ProcessName'" -Property * -ErrorAction SilentlyContinue -WarningAction SilentlyContinue

        ### $ShellName, $ProcessName, $Process | fl *
        ### Write-Host "$Machine`t`t: $Process"
        ### exit

        if (!([bool]$Process)) {

            $CurrentUser, $CurrentUserSID = "NO_CURRENT_LOGON"

        } else {

            # If there is more than one user logged in, the first listed process should be the user running the script
            $CurrentProcess = $Process | Sort -Property CreationDate -Descending | select -First 1

            $Process_OwnerInfo = Invoke-CimMethod -InputObject $CurrentProcess -MethodName GetOwner
            $Process_OwnerSIDInfo = Invoke-CimMethod -InputObject $CurrentProcess -MethodName GetOwnerSID

            $CurrentUserDomain = ($Process_OwnerInfo.Domain).ToUpper()
            $CurrentUserName = ($Process_OwnerInfo.User).ToUpper()
            $CurrentUser = $CurrentUserDomain + "\" + $CurrentUserName

            $CurrentUserSID = ($Process_OwnerSIDInfo.SID).ToUpper()

        }

    }

    catch {

        $CurrentUser, $CurrentUserSID = "UNKNOWN"

    }

    return $CurrentUser, $CurrentUserSID

}


 # ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-OnlineStatus ($Machine) {

    $PingStatus = Test-Connection -ComputerName $Machine -Count 1 -Quiet
    if ($PingStatus) {

        $IPAddress = (Test-Connection -ComputerName $Machine -Count 1).IPV4Address.IPAddressToString
        $DNSHostName = ([System.Net.Dns]::GetHostEntry($Machine)).Hostname

        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "Yes"
            DNSHostName = $DNSHostName
            IPAddress = $IPAddress
        }

    } else {

        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "No"
            DNSHostName = "OFFLINE"
            IPAddress = "OFFLINE"
        }

    }

    return $ReturnObject

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-OSVersion ($OSName, $OSBuild) {

    if ($OSName -like "*Windows 7*") {

        $OSEdition = $OSName -replace "Windows 7","Win7"
        $OSVersion = "$OSEdition $OSBuild"

    } else {

        $OSEdition = $OSName -replace "Windows 10","Win10"

        switch -Wildcard ($OSBuild) {
            "*10240*" { $Win10_Version = "ver 1507 RTM" }
            "*10586*" { $Win10_Version = "ver 1511" }
            "*14393*" { $Win10_Version = "ver 1607" }
            "*15063*" { $Win10_Version = "ver 1703" }
            "*16299*" { $Win10_Version = "ver 1709" }
            "*17134*" { $Win10_Version = "ver 1803" }
            "*17763*" { $Win10_Version = "ver 1809" }
            "*18362*" { $Win10_Version = "ver 1903" }
            "*18363*" { $Win10_Version = "ver 1909" }
            "*19041*" { $Win10_Version = "ver 2004" }
            "*19042*" { $Win10_Version = "ver 20H2" }
            "*19043*" { $Win10_Version = "ver 21H1" }
            "*19044*" { $Win10_Version = "ver 21H2" }
            default { $Win10_Version = "ver UNKNOWN" }
        }

        $OSVersion = "$OSEdition ($Win10_Version - build $OSBuild)"

    }

    return $OSVersion

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-Subnet($Machine) {

    try {
        $NetworkAdapters = Get-CimInstance -Namespace "root\cimv2" -Class Win32_NetworkAdapterConfiguration -ComputerName $Machine -OperationTimeoutSec 30 -Property * -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | ? {($_.IPEnabled -eq "True") -and ($_.DefaultIPGateway -ne $Null)}

        $NetworkAdapters | % {
 
           # Compute the Subnet (Network ID) from the IP Address and Subnet Mask
           $IPAddress = @($_.IPAddress)[0]
           $IPAddress_Octets = $IPAddress -split "\."              # Split up IP Address into array of 4 octets
           $SubnetMask_Octets = @($_.IPSubnet)[0] -split "\."      # Do the same for the subnet mask
           $Subnet_Octets = @{}                                    # Initialize hashtable for the subnet

           for ($i=0; $i -le 3; $i++) {                            # Do binary-and on all octets
               [int32]$Subnet_Octets[$i] = [int32]$IPAddress_Octets[$i] -band [int32]$SubnetMask_Octets[$i]
               $Subnet_NetworkID += ($Subnet_Octets[$i]).ToString() + "."  # Concatenate the result back into dotted-notation
           }

           $Subnet_NetworkID = $Subnet_NetworkID -replace ".$"             # Strip off last dot (artifact of last command)

        }

    }

   catch { $Subnet_NetworkID = "OFFLINE" }

   return $Subnet_NetworkID

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SystemInfo ($Machine) {

    try {
        $OSInfo = Get-CimInstance -Namespace "root\cimv2" -Class Win32_OperatingSystem -ComputerName $Machine -OperationTimeoutSec 30 -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    }
    catch {
        $OSInfo = $False
        _Error-Handler -ScriptErrorMessage "Unable to query WMI Win32_OperatingSystem class on [$Machine]" -ShowException
    }

    if ($OSInfo) {

        # Get last boot tiime
        $LastBootTime = $OSInfo.LastBootUpTime    # Use this if enumerating with GET-CIMINSTANCE
        if ($LastBootTime -eq $Null) { $LastBootTime = "UNKNOWN" }


        # Get OS Version
        $OSName = $OSInfo.Caption -replace "Microsoft ",""

        if ($OSName -like "*Windows 7*") {

            $OSVersion = Get-OSVersion $OSName $OSInfo.CSDVersion

        } else {

            $OSVersion = Get-OSVersion $OSName $OSInfo.Version

        }

    } else {

        $OSVersion = "UNKNOWN"
        $LastBootTime = "UNKNOWN"

    }


    $ReturnObject = [PSCustomObject]@{
        OSVersion = $OSVersion
        LastBootTime = $LastBootTime
    }

    return $ReturnObject

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-YNPrompt([string]$PromptMessage) {
    do {
        $Prompt = (Read-host "`n$PromptMessage [Y / N] ").ToUpper()
    } while($Prompt -notmatch "[YN]")

    return $Prompt
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Is-Admin {

    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
Function Send-Email {
    [CMDLETBINDING(SupportsShouldProcess)]   
    param (
            [string]$To,
            [string]$Subject,
            [string]$Message,
            [string]$File
          )
                        
    $EmailParams = @{       
        From = "<${env:COMPUTERNAME}@nyulangone.org>"
        To = $To
        BCC = "roland.thomas@nyulangone.org"
        Subject = "ATTENTION: $Subject";
        Body = if (Test-Path -Path $Message) { Get-Content -Path $Message | Out-String } else { $Message }
        SmtpServer = "relay.nyumc.org";
        Port = 25;

    }


    if (Test-Path -Path $File) { 

        Send-MailMessage @EmailParams -Attachments $File -BodyAsHtml

    } else {

        Send-MailMessage @EmailParams

    }

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Usage {
    Write-Output "Usage: $ScriptName [-Computers <Computer1, Computer2, Computer3,...> | -List <file>] [-ForceReboot] [-Report] [-Email] [-Testing]"
    exit
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

clear

#region Validation
# Abort if no arguments, display usage help
if ($psboundparameters.count -eq 0) { Usage }

if (!(Is-Admin)) { Write-Output "This script requires admin privileges!  Please elevate and re-run the script." ; exit }
#endregion


#region Start transcript
$LocalTempFolder= "c:\temp"
$TranscriptLog = "$LocalTempFolder\$($ScriptInfo.Name).log"

try { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null }
catch {}

if (!(Test-Path -Path $LocalTempFolder)) { New-Item -Path $LocalTempFolder -ItemType Directory -ErrorAction SilentlyContinue | Out-Null }
if (Test-Path -Path $TranscriptLog) { Remove-Item -Path $TranscriptLog -Force -ErrorAction SilentlyContinue }

Start-Transcript -Path $TranscriptLog -IncludeInvocationHeader -Force

Write-Host ("-" * 80) "BEGIN SCRIPT" ("-" * 80) -ForegroundColor Green
#endregion


#region Parse text file of computers
if ($List) {

    $List = $List.ToUpper()

    if (Test-Path -Path $List) {

        $Computers = Get-Content -Path $List | Sort | % { $_.toupper().trim() } | ? { $_.trim() -ne ""  } | Set-Content $List -PassThru # sort and trim whitespace and blank lines from textfile

    } else {

        Write-Host "Cannot find computer list file [$List]" -ForegroundColor Red
        exit

    }

}
#endregion


#region Prompt for confirmation
if ($Testing) { Write-Warning "SIMULATION MODE ENABLED - NO COMPUTERS WILL BE RESTARTED`n`n" }

if (!$List) {
    $Computers = $Computers.ToUpper()
    $Answer = Get-YNPrompt "Do you want to remotely reboot [$Computers]"
} else {
    $Answer = Get-YNPrompt "Do you want to remotely reboot all the machines in [$List]"
}

if ($Answer -eq "N") { exit }
#endregion


#region Start running the clock
$Script_StartTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"
Write-Output "`n`nProcessing Start`t: $Script_StartTime`n"
#endregion


#region Initialization
$Counter = $Count_Pinged = $Count_NotPinged = 0
$ComputerTable = @()
#endregion


#region Iterate through the machine list and execute the requested action
Write-Output "`nAttempting to restart computers now...`n`n"

if ($Testing) { Write-Warning "SIMULATION MODE ENABLED - NO COMPUTERS WILL BE RESTARTED`n`n" }


foreach ($Computer in $Computers) {

    # Display progress bar
    $Counter++
    $PercentComplete = [int32](($Counter / $Computers.Count) * 100)
    Write-Progress -Activity "Now Scanning [$Counter] out of [$($Computers.Count)] Computers" `
        -CurrentOperation "Number of computers successfully pinged so far: $Count_Pinged" `
        -Status "$PercentComplete% complete" -PercentComplete $PercentComplete



    # Add Active Directory information about the computer
    $ADComputer = Get-ADComputer -Filter 'Name -like $Computer'
    if ([bool]$ADComputer) {
        $OUPath = Convert-DNtoCN $ADComputer.DistinguishedName
    } else {
        $OUPath = "COMPUTER DOES NOT EXIST IN AD"
    }


    # Check if the computer is online   
    $ComputerObject = Get-OnlineStatus $Computer
    $OnlineStatus = $ComputerObject.OnlineStatus


    if ($OnlineStatus -ne "Yes") {

        $Count_NotPinged++
        $DNSHostName = $IPAddress = $OSVersion = $Subnet = $ActiveUser = $Null

        $RebootStatus = @("SKIPPED", "Cannot ping computer - may be powered off", "Red", "UNAVAILABLE")

        ### _Error-Handler -ScriptErrorMessage "Unable to ping [$Computer] - it may be powered off"

    } else {

        $Count_Pinged++
        $DNSHostName = $ComputerObject.DNSHostName
        $IPAddress = $ComputerObject.IPAddress

        # Add system information details to the machine object
        $WinRM = [bool](Test-WSMan -ComputerName $Computer -ErrorAction SilentlyContinue)
        if ($WinRM) { 

            $Sysinfo = Get-SystemInfo $Computer
            $OSVersion = $Sysinfo.OSVersion

            # Get the machine's subnet
            $Subnet = Get-Subnet $Computer
    
            # Get current logged in user on the computer
            $ActiveUser = (Get-CurrentRemoteUser($Computer))[0]

        } else {

            $OSVersion = $Subnet = $ActiveUser = "UNKNOWN"

        }


        # Parse different computer types
        switch -Wildcard ($Computer) {

            "CTX*" {
                $RebootStatus = @("SKIPPED", "Computer is Citrix Session", "Yellow", "OUT-OF-SCOPE")
            }

            "$env:COMPUTERNAME" {
                $RebootStatus = @("SKIPPED", "Cannot reboot host computer", "Yellow", "OUT-OF-SCOPE")
            }

            default {

                if (($ActiveUser -ne "NO_CURRENT_LOGON") -and !$ForceReboot) {

                    if ($ActiveUser -eq "UNKNOWN") {
                        $RebootStatus = @("SKIPPED", "Unable to verify if any user was logged in", "Yellow", "UNKNOWN")
                    } else {
                        $RebootStatus = @("SKIPPED", "User was currently logged in", "Yellow", "ACTIVE")
                    }

                } else {
                    try {
                        Restart-Computer -ComputerName $DNSHostName -Force -WhatIf:$Testing

                        switch ($ActiveUser) {
                            "NO_CURRENT_LOGON" { $RebootStatus = @("REBOOTED", "No user was logged in", "Green", "NOT ACTIVE") }
                            "UNKNOWN" { $RebootStatus = @("REBOOTED", "Unable to verify if any user was logged in", "Green", "UNKNOWN") }
                            default { $RebootStatus = @("REBOOTED", "User was currently logged in", "Green", "ACTIVE") }
                        }

                    }
                    catch {
                        $RebootStatus = @("NOT REBOOTED", "Computer failed to restart", "Red", "")
                    }
                }

            }
        }
    }


    if ($RebootStatus[3] -eq "ACTIVE") {

        Write-Host "$Computer`t`t: $($RebootStatus[0]) - $($RebootStatus[1]) ($ActiveUser)" -ForegroundColor $RebootStatus[2]

    } else {

        Write-Host "$Computer`t`t: $($RebootStatus[0]) - $($RebootStatus[1])" -ForegroundColor $RebootStatus[2]

    }


    # Construct the object with all elements
    $ComputerProps = [pscustomobject][ordered]@{
        Name = $Computer
        Pingable = $OnlineStatus
        "Reboot Status" = $RebootStatus[0]
        Comments = $RebootStatus[1]
        "Current User" = $ActiveUser
        "OU Path" = $OUPath
        "DNS Name" = $DNSHostName
        "IP Address" = $IPAddress
        Subnet = $Subnet
        "OS Version" = $OSVersion
    }


    $ComputerTable += $ComputerProps

}
#endregion


#region Display to screen console
Write-Output "`n`nRestart operations complete...`n`n"

$ComputerTable | sort "Name" | ft * -AutoSize

Write-Output "Machines online`t`t=`t$Count_Pinged"
Write-Output "Machines offline`t=`t$Count_NotPinged"
Write-Output "Total machines`t`t=`t$($Count_Pinged + $Count_NotPinged)"
#endregion


#region Save output to spreadsheet if requested
if ($Report -or $Email) {

    # Build the report filename
    $ReportFile_CSV = "$LocalTempFolder\$($ScriptInfo.Name)-$Today.csv"

    # Convert Report CSV to XLSX
    $ComputerTable | Export-Csv -Path $ReportFile_CSV -Append -NoTypeInformation -Force
    Write-Host "`n- Converting report to Excel format" -NoNewline
    $Process_StartTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"

    try {
        [IO.File]::OpenWrite($ReportFile_CSV).Close()
        Convert-CSVtoXLSX $ReportFile_CSV
        $ReportFile = $ReportFile_CSV -replace "csv","xlsx"
        $Process_EndTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"
        $Process_TimeDiff = New-TimeSpan -Start $Process_StartTime -End $Process_EndTime
        Write-Host " (format is XLS, done in $($Process_TimeDiff.Seconds) seconds)"
    }
    catch {
        Write-Host " (format is CSV)"
        $ReportFile = $ReportFile_CSV
    }

    # Copy report from local folder to network share
    Write-Output "`n- Saving report [$ReportFolder\$([System.IO.Path]::GetFileName($ReportFile))]"
    Copy-Item -Path $ReportFile -Destination $ReportFolder
    Remove-Item -Path $ReportFile_CSV -Force -ErrorAction SilentlyContinue | Out-Null

    ### Start-Process -FilePath "Excel.exe" -ArgumentList $ReportFile -WindowStyle Maximized

    if ($Email) {
        $WMIQuery = "SELECT DS_mail,DS_name,ds_SAMAccountName FROM ds_user where ds_SAMAccountName='$UserName'"
        $User = Get-WmiObject -Query $WMIQuery -Namespace "root\Directory\LDAP"
        $EmailAddress = $($User.DS_mail).ToUpper()
        Write-Output "`n- Emailing report to: $EmailAddress"
        Send-Email -To $EmailAddress -Subject "COMPUTER REBOOT REPORT" -Message "Please review the attached report" -File $ReportFile
    }

}
#endregion


#region Stop the clock and exit
$Script_EndTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"
$TimeDiff = New-TimeSpan -Start $Script_StartTime -End $Script_EndTime
Write-Output "`n`nProcessing Stop`t`t: $Script_EndTime"
Write-Output "`nScript completed in $($TimeDiff.Hours) hours $($TimeDiff.Minutes) minutes $($TimeDiff.Seconds) seconds`n`n"

#endregion


#region Stop transcript
Write-Host ("-" * 80) "END SCRIPT" ("-" * 80) -ForegroundColor Green
Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
#endregion

