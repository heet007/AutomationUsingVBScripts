﻿# ==========================================================================================================================================
# Program			: INSTALL-OPTIONALFEATURE.PS1
# Version			: 1.0.0
# Date				: Dec 08 2020
# Author			: Roland Thomas
# Team				: MCIT / End User Device Engineering
#
# This script bypasses restrictions on WSUS to install optional features by using the Windows 10 optional feature folder under \\shares.nyumc.org\eude
#
# Reference Links:
# ---------------
#
# 12-08-20 (v1.0.0) : First release

[cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]
param(
    [string[]]$Computername = $env:COMPUTERNAME,
    [string]$Source = "\\shares.nyumc.org\eude\DML\DML\Windows\Windows 10\FeaturesOnDemand\Install",
    [string]$Package
)


#Initialize script-specific variables$ScriptFileName = $PSCommandPath.ToUpper()$ScriptFileInfo = Get-ChildItem -Path $ScriptFileName
$ScriptVersion = "v1.0.0 (120820)"
$ScriptBuild = $ScriptFileInfo.LastWriteTime.ToString("MM-dd-yyyy hh:mm:ss tt")

$ScriptName = $ScriptFileInfo.Name
$ScriptUNCPath = (Resolve-Path -Path $ScriptFileName).Drive.DisplayRoot + ((Split-Path -Path $ScriptFileName -NoQualifier) -replace $ScriptName,"")

$ScriptInfo = [PSCustomObject]@{
    Filename = $ScriptFileInfo.Name
    Fullname = $Scriptfileinfo.FullName
    Name = $ScriptFileInfo.BaseName
    Version = $ScriptVersion
    Build = $ScriptBuild
    Directory = $ScriptFileInfo.Directory
    UNCPath = $ScriptUNCPath
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Is-Admin {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Delete-RegValue ($Key, $Name) {
   
    $CurrentValue = (Get-ItemProperty -Path $Key -Name $Name -ErrorAction SilentlyContinue).$Name

    if (!($CurrentValue)) {

        Remove-ItemProperty -Path $Key -Name $Name -Force -ErrorAction SilentlyContinue | Out-Null
        return $True

    } else {

        return $False

    }

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

function Set-RegValue ($Key, $Name, $NewValue, $Type) {

    $CurrentValue = (Get-ItemProperty -Path $Key -Name $Name -ErrorAction SilentlyContinue).$Name

    if (!($CurrentValue)) {

        if (!(Get-Item -Path $Key -ErrorAction SilentlyContinue)) { 
        
            New-Item -Path $Key -Credential $Script:LocalCredential -ErrorAction SilentlyContinue | Out-Null
        }

        New-ItemProperty -Path $Key -Name $Name -Value $NewValue -PropertyType $Type -Force -ErrorAction SilentlyContinue | Out-Null

    } else {

        if ($CurrentValue -ne $NewValue) {

            Set-ItemProperty -Path $Key -Name $Name -Value $NewValue -Force -ErrorAction SilentlyContinue | Out-Null

        } else {

            return $False

        }

    }

    return $True

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

cls


if (!(Is-Admin)) { 

    Write-Output "`nThis script must be run with elevated rights!"
    exit

}


if (!$Package) {

    Write-Output "`nUsage: $ScriptName -Computername [[Computernames]] -Package [Packagename]"
    exit

} else {

    #region Initialize environment
    $Computername = $Computername.ToUpper()

    $Package = $Package.ToUpper()

    $LocalInstall = "C:\Temp\OptionalFeatures"

    $Logfile = "C:\Temp\$env:COMPUTERNAME-OPTIONALFEATURE-$Package.log"
    #endregion


    #region Validate and install if necessary the optional feature package
    Write-Output "`n--- Checking installation state of [*$Package*] optional feature on computer [$Computername] ...`n"

    $PackageDetails = Get-WindowsCapability -Online -Name "*$Package*"

    if (![bool]$PackageDetails) { Write-Output "Cannot determine if [*$Package*] optional feature is installed -- must abort"; exit }
    
    $PackageDetails | % {

        $PackageInfo = $_

        switch ($PackageInfo.State) {

            "Installed" { 

                Write-Output "`n--- Package already installed: $($PackageInfo.DisplayName)`n"
                $PackageInfo | ft Name, DisplayName, State -AutoSize

            }
        

            "NotPresent" {

                if ($PackageInfo.Name -ne $Null) {

                    #region Enumerate the optional feature source files
                    Write-Output "`n--- Searching Windows 10 Features on Demand folder share for [*$Package*] package files ...`n"

                    # This registry setting will allow the script to 'see' UNC paths if running in SYSTEM context
                    Set-RegValue -Key "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLinkedConnections" -NewValue 1 -Type "DWORD" | Out-Null
                    Set-RegValue -Key "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "UseWUServer" -NewValue 0 -Type "DWORD" | Out-Null
                    sleep -Seconds 5

                    $PackageNamePattern = "*$Package*en-us*.cab", "*$Package*~~.cab"

                    $SourceFiles = Get-ChildItem -Path $Source -Include $PackageNamePattern -Recurse -ErrorAction SilentlyContinue

                    if (![bool]$SourceFiles) { Write-Output "Cannot find the [*$Package*] package files -- must abort"; exit }
                    #endregion


                    #region Copy the package source files to the local disk
                    Write-Output "`n--- Copying [*$Package*] installation files to local folder [$LocalInstall] ...`n"

                    if (Test-Path -Path $LocalInstall) { Remove-Item -Path $LocalInstall -Recurse -Force -Confirm:$False -ErrorAction SilentlyContinue | Out-Null }
   
                    New-Item -Path $LocalInstall -ItemType Directory -ErrorAction SilentlyContinue | Out-Null

                    Copy-Item -Path $SourceFiles.FullName -Destination $LocalInstall -Force -ErrorAction SilentlyContinue | Out-Null
                    Copy-Item -Path "$Source\FoDMetadata_Client.cab" -Destination $LocalInstall -Force -ErrorAction SilentlyContinue | Out-Null
                    Copy-Item -Path "$Source\metadata" -Destination $LocalInstall -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
                    #endregion


                    #region Install the optional feature
                    Write-Output "`n--- Installing package on computer [$env:COMPUTERNAME]: $($PackageInfo.DisplayName)`n"

                    Remove-Item -Path $Logfile -Force -ErrorAction SilentlyContinue | Out-Null

                    Add-WindowsCapability -Online -Name $PackageInfo.Name -Source $LocalInstall `
                        -LimitAccess -LogPath $Logfile -LogLevel WarningsInfo -ErrorAction SilentlyContinue | Out-Null

                    Write-Output "`n--- Logfile saved to: $Logfile"

                    Get-WindowsCapability -Online -Name $PackageInfo.Name
                    #endregion


                 } else {

                    Write-Output "`n--- Package was not found: $Package"

                 }

            }

        }

    }

    Set-RegValue -Key "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "UseWUServer" -NewValue 1 -Type "DWORD" | Out-Null

    Delete-RegValue -Key "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "EnableLinkedConnections" | Out-Null

    Remove-Item -Path $LocalInstall -Recurse -Force -Confirm:$False -ErrorAction SilentlyContinue | Out-Null

    #endregion

}

