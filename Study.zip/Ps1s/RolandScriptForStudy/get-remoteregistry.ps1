﻿#==========================================================================================================================================# Program	: GET-REMOTEREGISTRY.PS1# Version	: 1.0.0# Date		: Mar 11 2021# Author	: Roland Thomas# Team		: MCIT / End User Device Engineering## This script will get value of registry from remote machines## Usage     : GET-REMOTEREGISTRY.PS1 -Computers <machinename># Usage     : GET-REMOTEREGISTRY.PS1 -Computers <machine1>, <machine2>, <machine3>, etc# Usage     : GET-REMOTEREGISTRY.PS1 -List <file>## 03-11-21 (v1.0.0): First release
[cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]param(    [string[]]$Computers = $env:COMPUTERNAME,
    [string]$List,
    [string]$Logfile = "c:\temp\remoteregistrycheck.csv",
    [string]$RegKeyPath = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows NT\CurrentVersion\Winlogon",
    [string]$RegKeyName = "DefaultDomainName"
)

cls


#region Initialization
$OutputTable = @()
$CompObject = [psobject][ordered]@{}
#endregion


#region Parse text file of computers
if ($List) {

    if (Test-Path -Path $List) {

        $Computers = Get-Content -Path $List -ErrorAction SilentlyContinue

    } else {

        Write-Host "Cannot find computer list file [$($List.ToUpper())]" -ForegroundColor Red
        exit

    }

}
#endregion


#region Iteration
foreach ($Computer in $Computers) {

    $Computer = $Computer.ToUpper()

    if (Test-Connection -ComputerName $Computer -Count 1 -Quiet) {

        Write-Host "Connecting to [$Computer]" -ForegroundColor Green

        $CompObject = Invoke-Command -ComputerName $Computer -ArgumentList $RegKeyPath, $RegKeyName -ScriptBlock {

            param ($RegPath, $RegName)

            ### Write-Output "Reading [$RegPath!$RegName]"
            
            $RegValue = (Get-ItemProperty -Path $RegPath -Name $RegName -ErrorAction SilentlyContinue).$RegName

            if (!([bool]$RegValue)) { $RegValue = "NOTFOUND" }

            return [PSCustomObject][ordered]@{
                "Computer" = $env:COMPUTERNAME
                "Pingable" = "YES"
                "RegValue [$RegPath!$RegName]" = $RegValue
            }

        }

    } else {

        Write-Warning "Cannot ping [$Computer]"

        $CompObject = [PSCustomObject][ordered]@{
            "Computer" = $Computer
            "Pingable" = "NO"
            "RegValue [$RegKeyPath!$RegKeyName]" = "N/A"
        }

    }

    $OutputTable += $CompObject

}
#endregion


#region Save output to file and screen
$Output = $OutputTable | select * -ExcludeProperty PS*,Runspace*

if (Test-Path -Path $Logfile) { Remove-Item -Path $Logfile -Force -ErrorAction SilentlyContinue }

$Output | Export-Csv -Path $Logfile -NoTypeInformation
$Output | ft * -AutoSize
#endregion


