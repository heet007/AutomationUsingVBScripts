﻿#==========================================================================================================================================
# Program			: INSTALL-WIN10FEATUREUPDATE.PS1
# Version			: 1.7.0
# Date				: Mar 07 2020
# Author			: Roland Thomas
# Team				: MCIT / End User Device Engineering
#
# This script upgrades the OS to a newer version of Windows 10
#
# Status information is saved in: 
#      - Locally : C:\TEMP\{ScriptName}-{MachineName}.log
#      - Network : \\shares.nyumc.org\EUDE\Inventory\OnDemand\Windows10\OSUpgrades\VersionXXXX (both local script logs as well as the SETUP.EXE logs)
#
# Reference Links:
# ---------------
# https://support.microsoft.com/en-us/help/12373/windows-update-faq
# https://docs.microsoft.com/en-us/windows/deployment/upgrade/resolve-windows-10-upgrade-errors
# https://docs.microsoft.com/en-us/windows/deployment/upgrade/setupdiag
# https://docs.microsoft.com/en-us/windows-hardware/manufacture/desktop/windows-setup-command-line-options
# https://docs.microsoft.com/en-us/windows-hardware/manufacture/desktop/deployment-troubleshooting-and-log-files
# https://support.microsoft.com/en-us/help/928901/log-files-that-are-created-when-you-upgrade-to-a-new-version-of-window
#
# 06-11-19 (v1.0.0) : First release
# 06-18-19 (v1.1.0) : Checks if Imprivata is installed and aborts if version is < 6.0
# 06-19-19 (v1.2.0) : Deletes leftover installation folders from previous upgrades that may interfere
# 07-09-19 (v1.3.0) : Added -REBOOT and -LOCALINSTALL switches
# 10-04-19 (v1.4.0) : Detect if machine is an autologon kiosk and disable autologon settings from registry and move computer to OU that does not have autologon GPO;
#                     this will prevent autologon policy from being re-enabled when computer reboots
# 10-10-19 (v1.5.0) : Disabled using the MOVE-COMPUTER function, instead will just toggle the Autologon settings in the registry for kiosk upgrades
#                     Added -DYNAMICUPDATE switch to toggle whether patches released after feature update are automatically downloaded and installed before upgrade is complete
# 10-31-19 (v1.6.0) : Added INSTALL-APP function to give more error handling control over the installation process
# 03-07-20 (v1.7.0) : Added -SENDLOG switch to email the upgrade logfile 
#                     Modified script to run itself with the -SENDLOG switch after the final reboot

#Requires -Version 3.0
### #Requires -RunAsAdministrator

[cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]
param(
    [ValidateSet('1709','1803','1903','2004')][string]$Win10UpgradeVersion = "2004",
    [switch]$DevTest = $False,
    [switch]$LocalInstall = $False,
    [switch]$DynamicUpdate = $False,
    [switch]$Reboot = $False,
    [switch]$Diagnostics = $False,
    [switch]$IgnoreUserLogon = $False,
    [switch]$SendLog = $False
)


# Set global script variables
###$ScriptName = $MyInvocation.MyCommand.Name.ToUpper() -replace ".ps1",""
if ($DevTest) {    # Hardcode script name because Altiris uses its own naming convention
    $ScriptName = "INSTALL-WIN10FEATUREUPDATE-DEV"
} else {
    $ScriptName = "INSTALL-WIN10FEATUREUPDATE"
}
$ScriptVersion = "v1.7.0 (2020-03-07)"
$SupportEmailAddress = "roland.thomas@nyulangone.org" ###, "joshua.hart@nyulangone.org"
$ErrorActionPreference = "SilentlyContinue"
$VerbosePreference = "SilentlyContinue"
$ExitonError = $True
$NoExitonError = $False


# Import the ActiveDirectory module without using RSAT installation
$AD_ModulePath = "\\mscsnyu01.nyumc.org\adbuild\DET_Builds\Packages\Microsoft Products\ActiveDirectory"
$AD_ModuleName = "$AD_ModulePath\Microsoft.ActiveDirectory.Management.dll"
$AD_ModuleScript = "$AD_ModulePath\Install-ActiveDirectoryModule.ps1"
if ((Test-Path -Path $AD_ModuleName) -and (Test-Path -Path $AD_ModuleScript)) { 
    Invoke-Expression -Command "$AD_ModuleScript" -Verbose
}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Error-Handler([string]$ErrorMessage, [boolean]$_ExitonError) {

    Write-Log "$ErrorMessage" "Red"

    try {

        ### $ExceptionMessage = $Error[0].Exception.Message
        ### if ($ExceptionMessage -ne $Null) { Write-Log "System error message was: '$ExceptionMessage'" "Yellow" }
        
        $HResultCode = $Error[0].Exception.HResult

        ### Write-Host "HResultCode = $HResultCode"

        if (([bool]$HResultCode) -and ($HResultCode -ne 0)) {
            $ExitCode = "0x" + $("{0:x}" -f $HResultCode)
        } else {
            $ExitCode = -1
        }

    }
    catch { 
        $ExitCode = -999
    }

    ### Write-Log "Returning to caller with Error Code: $ExitCode" "Yellow"

    if ($_ExitonError) {
        Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
        exit $ExitCode
    } else {
        return $ExitCode
    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-CNtoDN([string]$CanonicalName) {

    # Parsing if an empty string is sent 
    if ([string]::IsNullOrEmpty($CanonicalName)) { return $Null }


    # Split the canonical name into separate bits 
    $Parts = $CanonicalName.Split("//")

    foreach ($Part in $Parts) {
        if ($Parts.IndexOf($Part) -eq 0) {
            $DistinguishedName = "DC=nyumc,DC=org"
        } else {
            $DistinguishedName = "OU=$Part," + $DistinguishedName
        }
    }

    return $DistinguishedName

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-DNtoCN([string]$DistinguishedName) {

    # Parsing if an empty string is sent 
    if ([string]::IsNullOrEmpty($DistinguishedName)) { return $Null }


    # Strip off leading LDAP prefix if there is any
    if ($DistinguishedName -like "LDAP://*") { $DistinguishedName = $DistinguishedName -replace "LDAP://","" }


    # Split the distinguished name into separate bits 
    $Parts = $DistinguishedName.Split(",")
 
    foreach ($Part in $Parts) {
        if ($Part -like "OU=*") {
            $Subpart = $Part -replace "OU=",""
            $CanonicalName = "/$Subpart" + $CanonicalName
        }

    }

    $CanonicalName = "nyumc.org" + $CanonicalName

    return $CanonicalName

}



# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-OSBuildNumber ($OSBuild) {

    switch -Wildcard ($OSBuild) {

        "*10240*" { $OSVersion = "1507 RTM" }
        "*10586*" { $OSVersion = "1511" }
        "*14393*" { $OSVersion = "1607" }
        "*15063*" { $OSVersion = "1703" }
        "*16299*" { $OSVersion = "1709" }
        "*17134*" { $OSVersion = "1803" }
        "*17763*" { $OSVersion = "1809" }
        "*18362*" { $OSVersion = "1903" }
        "*19041*" { $OSVersion = "2004" }
        "*18845*" { $OSVersion = "InsiderPreview-20H1" }
        default { $OSVersion = "UNKNOWN" }
    }

    return $OSVersion


}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Create-CustomScheduledTask ($TaskName, $TaskXMLFilePath) {

    $ExportedTaskFile = "$TaskXMLFilePath\$TaskName.xml"

    if (Test-Path $ExportedTaskFile) {

        # Read in the exported task definition file
        $ImportedTask = (Get-Content -Path $ExportedTaskFile) | Out-String
    
        # Create the task
        Register-ScheduledTask -TaskName $Taskname -XML $ImportedTask -Force -Verbose

        # Retrieve and display task parameters
        $TaskObject = Get-ScheduledTask -TaskName $Taskname

        $Result = [PSCustomObject]@{
            Principal = $TaskObject.Principal
            Triggers = $TaskObject.Triggers
            Actions = $TaskObject.Actions
            Settings = $TaskObject.Settings
        }

        return $Result

    } else {

        return $False

    }
       
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Delete-OldWin10SetupFolder ($SetupFolder) {

    if (!(Test-Path $SetupFolder -ErrorAction SilentlyContinue)) {

        return $True

    } else {

        Write-Log "Deleting previous Windows 10 Setup folder: [$SetupFolder]"

        $SetupFolder = $SetupFolder.ToUpper()

        Write-Log "- - - Running ATTRIB"
        & attrib.exe -h -r $SetupFolder /s /d

        ### Write-Log "- - - Running ICACLS"
        ### & icacls.exe "$SetupFolder\*.*" /C /T /grant Administrators:F

        Write-Log "- - - Running TAKEOWN"
        & takeown.exe /f "$SetupFolder" /a /r /d Y
   
        Write-Log "- - - Running DELETE FOLDER"
        ### Get-ChildItem -Path $SetupFolder -Recurse -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
        ### Remove-Item -Path $SetupFolder -Force -Recurse -ErrorAction SilentlyContinue
        $RandomNumber = Get-Random
        $EmptyFolder = "c:\temp\robocopy-delete-win10upgrade-$RandomNumber"
        & mkdir $EmptyFolder
        & robocopy $EmptyFolder $SetupFolder /mir /r:10 /w:15 
        Remove-Item $EmptyFolder -Force -Recurse
        Remove-Item $SetupFolder -Force -Recurse

        Start-Sleep 5
        if (Test-Path -Path $SetupFolder -ErrorAction SilentlyContinue) {
            return $False
        } else {
            return $True
        }

    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-CurrentUser {

    $ProcessName = "explorer.exe"
    #$ProcessName = "ALMon.exe"         # the Sophos agent process
    #$ProcessName = "AeXAgentUIHost.exe" # the Symantec Management Agent process

    $Process = Get-WmiObject Win32_Process -Filter "Name='$ProcessName'" -ErrorAction SilentlyContinue

    if ([bool]$Process) {

        $UserName = ($Process | ForEach-Object { $_.GetOwner() } |  Select-Object -Unique -Expand User).ToUpper()

        $Principal = New-Object System.Security.Principal.NTAccount($env:USERDOMAIN, $UserName)

        $UserSID = ($Principal.Translate([System.Security.Principal.SecurityIdentifier])).Value

        ### Write-Log "Username = [$Username]; UserSID = [$UserSID]"

    } else {

        $UserName = $Null ; $UserSID = $Null

        ### Write-Log "Process [$ProcessName] was not found attached to any logged-on user"

    }

        
    $Result = [PSCustomObject]@{
        UserName = $UserName
        UserSID = $UserSID
    }

    return $Result
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-Subnet ($Machine) {

    try {
        $NetworkAdapters = Get-WmiObject -Class Win32_NetworkAdapterConfiguration -ComputerName $Machine | ? {($_.IPEnabled -eq "True") -and ($_.DefaultIPGateway -ne $Null)}
        $NetworkAdapters | % {

           # Compute the Subnet (Network ID) from the IP Address and Subnet Mask
           $IPAddress = @($_.IPAddress)[0]
           $IPAddress_Octets = $IPAddress -split "\."              # Split up IP Address into array of 4 octets
           $SubnetMask_Octets = @($_.IPSubnet)[0] -split "\."      # Do the same for the subnet mask
           $Subnet_Octets = @{}                                    # Initialize hashtable for the subnet

           for ($i=0; $i -le 3; $i++) {                            # Do binary-and on all octets
               [int32]$Subnet_Octets[$i] = [int32]$IPAddress_Octets[$i] -band [int32]$SubnetMask_Octets[$i]
               $Subnet_NetworkID += ($Subnet_Octets[$i]).ToString() + "."  # Concatenate the result back into dotted-notation
           }

           $Subnet_NetworkID = $Subnet_NetworkID -replace ".$"             # Strip off last dot (artifact of last command)

        }

    }

    catch { $Subnet_NetworkID = "UNKNOWN" }

    return $Subnet_NetworkID

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-OSVersion {

    $OSInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem -ErrorAction SilentlyContinue

    if ([bool]$OSInfo) {

        $OSLongName = $OSInfo.Caption -replace "Microsoft ",""
        $OSBuild = $OSInfo.Version

        if ($OSLongName -like "*Windows 7*") {

            $OSShortName = $OSLongName -replace "Windows 7","Win7"
            $OSFullName = "$OSLongName $OSBuild"

        } else {

            $OSVersion = Convert-OSBuildNumber $OSBuild
            $OSShortName = $OSLongName -replace "Windows 10","Win10"
            $OSFullName = "$OSLongName (ver $OSVersion - build $OSBuild)"

        }

    } else {

        $OSLongName = $OSShortName = $OSBuild = $OSVersion = $OSFullName = "UNKNOWN"

    }


    $OSVersionObject = [PSCustomObject]@{
        OSLongName = $OSLongName
        OSShortName = $OSShortName
        OSBuild = $OSBuild
        OSVersion = $OSVersion
        OSFullName = $OSFullName
    }


    return $OSVersionObject

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SystemInfo {

    $SysInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_ComputerSystem -ErrorAction SilentlyContinue

    if ([bool]$SysInfo) {

        return [PSCustomObject]@{
            Manufacturer = $SysInfo.Manufacturer
            Model = $SysInfo.Model
            BIOS = (Get-WmiObject -Namespace "root\cimv2" -Class Win32_BIOS  -ErrorAction SilentlyContinue).Description  # Also property SMBIOSBIOSVersion
        }

    } else {

        return $False

    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-TimeDifference([DateTime]$Start, [DateTime]$End) {
    [TimeSpan]$Diff = $End - $Start
        
    $Hours = $Diff.Hours
    $Mins = $Diff.Minutes
    $Secs = $Diff.Seconds
    $Millisecs = $Diff.Milliseconds
    
    $Result = ""
    if ($Hours -gt 0) { $Result +=  "${Hours} hours"  }
    if ($Mins -gt 0 ) { $Result +=  " ${Mins} minutes" }
    if ($Secs -gt 0 ) { $Result +=  " ${Secs} seconds" }
    if ($Millisecs -gt 0) { $Result +=  " ${Millisecs} milliseconds" }
    
    return $Result.Trim()
}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Install-App {

    param(
        [string]$Installer = $Null,
        [string]$InstallArgs = $Null,
        [string]$ProcesstoCheck = $Null,
        [string]$TimeLimit = $Null
    )


    $Result = [PSCustomObject]@{
        ExitCode = -1
        ExitReason = "N/A"
        ExitStatus = $False
    }


    $ScheduledStartTime = Get-Date
    $ScheduledStopTime = $ScheduledStartTime.addseconds($TimeLimit)

    Write-Log "Installer = $Installer"

    $InstallerPath = Split-Path -Path $Installer -Parent
    $InstallerFile = Split-Path -Path $Installer -Leaf

    Write-Log "Installer Path = $InstallerPath"
    Write-Log "Installer File = $InstallerFile"
  
    $Location = Set-Location -Path $InstallerPath -PassThru -Verbose -ErrorAction SilentlyContinue
    if ([bool]$Location) { 
        Write-Log "Folder location changed to: $Location"
        dir $Location -Recurse -Force
    }
  
    if ([string]::IsNullOrEmpty($InstallArgs)) {
        Write-Log "Executing command: $InstallerFile"
        $CommandProcess = Start-Process -FilePath $InstallerFile -WorkingDirectory $Location -WindowStyle Normal -PassThru -Verbose -ErrorAction SilentlyContinue
    } else {
        Write-Log "Executing command: $InstallerFile $InstallArgs"
        $CommandProcess = Start-Process -FilePath $InstallerFile -ArgumentList $InstallArgs -WorkingDirectory $Location -WindowStyle Normal -PassThru -Verbose -ErrorAction SilentlyContinue
    }


    <#
    Write-Log "Executing command: $InstallerFile $InstallArgs"
    & $InstallerFile $InstallerArgs
    #>


    if ([bool]$CommandProcess) {

        $CommandProcessName = $CommandProcess.ProcessName.ToUpper()
        Write-Log "Command Process has started: [$CommandProcessName]"

        ### if ([string]::IsNullOrEmpty($ProcesstoCheck)) { $ProcesstoCheck = $InstallerFile -replace ".exe","" }
        if ([string]::IsNullOrEmpty($ProcesstoCheck)) { 
       
            $MonitoringProcess = $CommandProcess

        } else {

            # We will wait a hard-coded timeout of 1 minute for the setup process to start, if it does not then failout gracefully
            $StartProcessTimeOut = 60
            Write-Log "Waiting [$StartProcessTimeOut] seconds for Monitoring Process [$ProcesstoCheck] to start... (will abort if timeout reached)"

            Do {
                Start-Sleep -Seconds 1
                $StartProcessTimeOut--
                $MonitoringProcess = Get-Process -Name $ProcesstoCheck
            } Until (([bool]$MonitoringProcess) -or ($StartProcessTimeOut -eq 0))

        }

        if ([bool]$MonitoringProcess) {

            $ProcessID = $MonitoringProcess.ID
            $ProcessHandle = $MonitoringProcess.Handle

            Write-Log "Monitoring Process [$($MonitoringProcess.Name.ToUpper())] has started - waiting [$TimeLimit] seconds for PID [$ProcessID] to complete... (will abort if timeout reached)"
            Wait-Process -Id $ProcessID -Timeout $TimeLimit -ErrorAction SilentlyContinue

            if ($MonitoringProcess.HasExited -eq $False) { 
        
                Stop-Process -Id $ProcessID -Force -ErrorAction SilentlyContinue -PassThru

                $Result.ExitStatus = $False
                $Result.ExitCode = $MonitoringProcess.ExitCode
                $Result.ExitReason = "Process terminated by force"

            } else {

                $Result.ExitStatus = $True
                $Result.ExitCode = $MonitoringProcess.ExitCode
                $Result.ExitReason = "Process terminated normally"

            }
   
        } else {

            Write-Log "Monitoring Process [$ProcesstoCheck] failed to start -- check Installer [$Installer]"
    
            $Result.ExitStatus = $False
            $Result.ExitCode = -999
            $Result.ExitReason = "Monitoring Process [$ProcesstoCheck] never started"

        }

    } else {

        Write-Log "Installer [$Installer] failed to launch"
    
        $Result.ExitStatus = $False
        $Result.ExitCode = -998
        $Result.ExitReason = "Installer [$Installer] failed to launch"

    }


    # Calculate the duration it took to install
    $ActualStopTime = Get-Date
    $Duration = New-TimeSpan -Start $ScheduledStartTime -End $ActualStopTime
   
    Write-Log "Scheduled Start Time = $ScheduledStartTime"
    Write-Log "Scheduled Stop Time = $ScheduledStopTime"
    Write-Log "Actual Stop Time = $ActualStopTime"
    Write-Log "Execution Time : $($Duration.Minutes) mins $($Duration.Seconds) secs"
    Write-Log "Process Exit Code   : $($Result.ExitCode)"
    Write-Log "Process Exit Status : $($Result.ExitStatus)"
    Write-Log "Process Exit Reason : $($Result.ExitReason)"
   
    return $Result

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Is-Admin() {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Is-AutologonEnabled () {

    $RegKey = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
    $RegName = "AutoAdminLogon"

    $Autologon = (Get-ItemProperty -Path $RegKey -Name $RegName -ErrorAction SilentlyContinue).$RegName

    if ($Autologon -eq "1") {

        return $True

    } else {

        return $False

    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Is-ImprivataInstalled () {

    # Bundle the properties to return to the caller
    $ReturnObject = [PSCustomObject]@{
            Status = $False
            FullName = ""
            Version = ""
    }


    # Check if Imprivata client is installed
    $Exe_Name = "isxagent.exe"
    $ImprivataPath_32 = "C:\Program Files\Imprivata\OneSign Agent"
    $ImprivataPath_64 = "C:\Program Files (x86)\Imprivata\OneSign Agent"
    $Found_ImprivataPath = Get-ChildItem -Path $ImprivataPath_32, $ImprivataPath_64 -File $Exe_Name -ErrorAction SilentlyContinue


    if ([bool]$Found_ImprivataPath) {
        $ReturnObject.Status = $True
        $ReturnObject.Fullname = $Found_ImprivataPath.FullName
        $ReturnObject.Version = $Found_ImprivataPath.VersionInfo.ProductVersion
    }


    return $ReturnObject

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Set-RegValue ($Key, $Name, $NewValue, $Type) {

    $CurrentValue = (Get-ItemProperty -Path $Key -Name $Name -ErrorAction SilentlyContinue -Verbose).$Name

    if (!($CurrentValue)) {

        if (!(Get-Item -Path $Key -ErrorAction SilentlyContinue -Verbose)) { 
        
            ### Write-Log "Create new registry key [$Key]"
            New-Item -Path $Key -ErrorAction SilentlyContinue | Out-Null
        }

        ### Write-Log "Create new registry setting [$Key!$Name] with value [$NewValue]"
        New-ItemProperty -Path $Key -Name $Name -Value $NewValue -PropertyType $Type -Force -ErrorAction SilentlyContinue -Verbose | Out-Null

    } else {

        ### Write-Log "Read current registry value: [$CurrentValue]"

        if ($CurrentValue -eq $NewValue) {
            ### Write-Log "Registry setting [$Key!$Name] is already set to [$CurrentValue]"
        } else {
            ### Write-Log "Change registry setting [$Key!$Name] from [$CurrentValue] to [$NewValue]"
            Set-ItemProperty -Path $Key -Name $Name -Value $NewValue -Force -ErrorAction SilentlyContinue -Verbose | Out-Null
        }

    }

}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Email-TranscriptLog ($To, $Subject, $Message) {

    $EmailParams = @{
        From = "EUDE DEV EMAIL <eudedev@nyulangone.org>";
        To = $To;
        Subject = $Subject;
        Body = if (Test-Path -Path $Message) { Get-Content -Path $Message | Out-String } else { $Message }
        SmtpServer = "relay.nyumc.org";
        Port = 25;
    }

    Send-MailMessage @EmailParams

}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Upload-TranscriptLog ($TranscriptLog, $LogFolder) {

    # Write status to network share
    if (Test-Path -Path $LogFolder) {
        Copy-Item -Path $TranscriptLog -Destination $LogFolder -PassThru -ErrorAction SilentlyContinue | ft name, length, lastwritetime
    }

}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Write-Log ([string]$Message, $Color) {

    $ScriptName = $Global:Scriptname.ToUpper()
    $CallingFunction = ((Get-Variable MyInvocation -Scope 1).Value.MyCommand.Name).ToUpper() -replace ".ps1",""
    $LineNumber = $MyInvocation.ScriptLineNumber

    $Now = Get-Date -format "yyyy-MM-dd_HH:mm:ss"

    if (($CallingFunction -eq $ScriptName) -or ($CallingFunction -like "ALTIRISSCRIPT*")) {
        $LogMsg = "${Now}: [Line:$LineNumber (Main Section)] ${Message}"
    } else {
        $LogMsg = "${Now}: [Line:$LineNumber (Function '$CallingFunction')] ${Message}"
    }


    if ([bool]$Color) {
        Write-Host $LogMsg -ForegroundColor $Color
    } else {
        Write-Host $LogMsg
    }

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

cls

#region Initialization
$Error.Clear()

$ScriptStartTime = Get-Date
$TimeStamp = $ScriptStartTime.ToString("yyyyMMdd-HHmmss")
$Win10UpgradeStatusTask = "EUDE_GET-WIN10UPGRADESTATUS"

$Machine = $env:COMPUTERNAME.ToUpper()

$LocalTempFolder = "C:\TEMP"
$OutputLogFolder = "\\shares.nyumc.org\eude\Inventory\OnDemand\Windows10\OSUpgrades\Version$Win10UpgradeVersion"


# Create transcript on local drive to be copied later to the network share
### $TranscriptLog = "$LocalTempFolder\$ScriptName-$Machine-$TimeStamp.log"
$TranscriptLog = "$LocalTempFolder\$Machine-Win10Upgrade.log"


if (Test-Path -Path $TranscriptLog) {

    # The -SENDLOG switch is used to email the status log from the last the time script was executed
    if ($SendLog) {
        Email-TranscriptLog $SupportEmailAddress "WIN10 UPGRADE LOG FOR: $Machine" $TranscriptLog
        if ([bool](Get-ScheduledTask -TaskName $Win10UpgradeStatusTask)) {
            Unregister-ScheduledTask -TaskName $Win10UpgradeStatusTask -Confirm:$False -ErrorAction SilentlyContinue
        }
        exit
    } else {
        Remove-Item -Path $TranscriptLog -Force -ErrorAction SilentlyContinue
    }

}

Start-Transcript -Path $TranscriptLog -IncludeInvocationHeader


Write-Log "-------------------------------- BEGIN WINDOWS 10 UPGRADE SCRIPT --------------------------------" "Green"
#endregion


#region Validate credentials

# Abort if user does not have local admin rights for certain functions
if (!(Is-Admin)) { Error-Handler "This script requires admin privileges!  Please elevate and re-run the script." $ExitonError }


<#
# Get service account credentials
$PasswordFile = "\\nyumc.org\NETLOGON\Win7\Computer\Rename-NYUMCDomainComputer.pwd"
try { $ServiceAccount = Import-Clixml $PasswordFile }
catch { Write-Log "Unable to read password file [$PasswordFile]" }
try { $ServiceAccountPassword = ConvertTo-SecureString $ServiceAccount.EncryptedPwd -Key $ServiceAccount.Key }
catch { Write-Log "Unable to convert encrypted password string for account [$($ServiceAccount.Username)]" }
try { $DomainCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $ServiceAccount.Username,$ServiceAccountPassword }
catch { Write-Log "Unable to create Credentials object for account [$($ServiceAccount.Username)]" }

#
$BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($DomainCredential.Password)
$UnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
Write-Log "ServiceAccount = $($ServiceAccount.Username); ServiceAccountPassword = $ServiceAccountPassword"
Write-Log "DomainUsername = $($DomainCredential.Username); DomainPassword = $UnsecurePassword"
### exit
#>
#endregion


#region Translate build number from Windows version number
# https://en.wikipedia.org/wiki/Windows_10_version_history#Rings
switch ($Win10UpgradeVersion) {
    "1709" { $Win10UpgradeBuild = "10.0.16299" }
    "1803" { $Win10UpgradeBuild = "10.0.17134" }
    "1903" { $Win10UpgradeBuild = "10.0.18362" }
    "2004" { $Win10UpgradeBuild = "10.0.19041" }
}

$OSVersionInfo = Get-OSVersion
$OSVersion = $OSVersionInfo.OSVersion
$OSBuild = $OSVersionInfo.OSBuild
$OSFullName = $OSVersionInfo.OSFullName

$NewOSVersion = "Windows 10 Enterprise (ver $Win10UpgradeVersion - build $Win10UpgradeBuild)"

$SysInfo = Get-SystemInfo

### $CurrentUser = Get-CurrentUser
### $CurrentUserName = $CurrentUser.Username
### $CurrentUserSID = $CurrentUser.UserSID
$CurrentUserName = $env:USERNAME


Write-Log "Currently running : $OSFullName"
Write-Log "Scheduled upgrade : $NewOSVersion"

#endregion


#region Check if current computer is candidate for the upgrade
if ([version]$OSBuild -ge [version]$Win10UpgradeBuild) {

    $Win10UpgradeFolder = "N/A"

    Write-Log "Nothing to upgrade: Computer [$Machine] is running greater or equal to the required version"

    $SetupResult = [PSCustomObject]@{
        ExitCode = 0
        ExitReason = "Computer running OS >= version $Win10UpgradeVersion"
        ExitStatus = $Null
    }

} else {

    #region Pre-upgrade validation

    # Check if a human user is currently logged in
    if ($CurrentUserName -ne ("$env:COMPUTERNAME`$")) {

        if ($IgnoreUserLogon) {
            Write-Log "User [$CurrentUserName] is currently logged in; -IGNOREUSERLOGIN switch used so upgrade will continue"
        } else {
            Error-Handler "Script abort: User [$CurrentUserName] is currently logged in; logout before proceeding or use -IGNOREUSERLOGON switch" $ExitonError
        }

    } else {

        Write-Log "Computer is logged out, okay to proceed with upgrade"

        $CurrentUserName = "NONE"
        ### $CurrentUserSID = "NONE"
    }


    # Check if computer is running Windows 10
    if ($OSFullName -notlike "*Windows 10*") {
        Error-Handler "Script abort: Computer [$Machine] is not running Windows 10" $ExitonError
    }


    # Check if machine has sufficient disk space to install
    $MinDiskSpace = 35
    $FreeDiskSpace = [math]::Round((Get-PSDrive -Name C).Free / 1GB)
    if ($FreeDiskSpace -lt $MinDiskSpace) { Error-Handler "Script abort: Free disk space of [$FreeDiskSpace GB] is less than minimum [$MinDiskSpace GB] required for upgrade" $ExitonError }


    # Check that machine can access the Windows upgrade source files
    $Win10UpgradeSource = "\\shares.nyumc.org\eude\DML\DML\Windows\Windows 10\FeatureUpdates\$Win10UpgradeVersion"


    if (!(Test-Path -Path $Win10UpgradeSource)) { 
        Error-Handler "Script abort: User account [$CurrentUserName] could not access Windows 10 Upgrade Source folder [$Win10UpgradeSource]" $ExitonError
    }


    # Check if Imprivata is installed and if it is correct version
    $Imprivata = Is-ImprivataInstalled
    if ($Imprivata.Status) {

        Write-Log "Imprivata agent is installed on this machine: $($Imprivata.Fullname)"
        if ([version]$Imprivata.Version -ge [version]"6.0.0.0") {
            Write-Log "Version [$($Imprivata.Version)] meets minimum requirements for the Windows 10 upgrade - OK to proceed"
        } else {
            Error-Handler "Script abort: Imprivata version [$($Imprivata.Version)] does NOT meet minimum requirements for the Windows 10 upgrade" $ExitonError
        }
 
    } else {
 
        Write-Log "Imprivata agent is NOT installed on this machine - OK to proceed"
 
    }

    #endregion


    <#
    #region Delete setup folders from previous Windows 10 upgrades
    $Win10SetupFolder = 'C:\$WINDOWS.~BT'   # need to put path in single quotes to escape the $ char that is in the path name
    $Win10SetupFolderDeleted = Delete-OldWin10SetupFolder $Win10SetupFolder
    If ($Win10SetupFolderDeleted) { 
        Write-Log "Windows 10 Setup folder [$Win10SetupFolder] does not exist, upgrade process will create this folder"
    } else {
        Error-Handler "Script abort: Windows 10 Setup folder [$Win10SetupFolder] still exists, maybe from a previous failed upgrade" $ExitonError
    }
    #endregion
    #>


    #region Disable autologon setting temporarily so that the reboot after installation can work correctly 
    if (!(Is-AutologonEnabled)) {

        Write-Log "Computer [$Machine] is not configured to autologon"

    } else {

        Write-Log "Computer [$Machine] is configured to autologon -- this needs to be disabled before upgrading the OS"

        # Disable the autologon setting so that it doesn't happen when Windows reboots
        $RegKey = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
        $RegName = "AutoAdminLogon"
        Write-Log "- - - Disabling '$RegName' setting in registry under [$RegKey]"
        Set-RegValue $RegKey $RegName "0" "STRING"

    }
    #endregion


    #region Execute upgrade process
    if ($LocalInstall) {

        $Win10UpgradeFolder = "$LocalTempFolder\Win10Upgrade"
        Write-Log "Copying Windows 10 Upgrade Files [$Win10UpgradeSource] to [$Win10UpgradeFolder]"

        $CopyStartTime = Get-Date

        try {
            Get-ChildItem -Path $Win10UpgradeFolder -Recurse -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
        }
        catch {
            Error-Handler "Unabled to delete old [Win10UpgradeFolder] destination folder" $ExitonError
        }

        try {
            robocopy $Win10UpgradeSource $Win10UpgradeFolder /mir /r:10 /w:15 /np /ns /nc /nfl /ndl
        }
        catch {
            Error-Handler "Unabled to access [Win10UpgradeSource] source folder" $ExitonError
        }


        $Duration = New-TimeSpan -Start $CopyStartTime -End (Get-Date)
        Write-Log "File Copy Time : $($Duration.Minutes) mins $($Duration.Seconds) secs"

    } else {

        $Win10UpgradeFolder = $Win10UpgradeSource

    }


    $Win10UpgradeDrive = "WIN10UPGRADE"
    if ([bool](Get-PSDrive -Name $Win10UpgradeDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
        Remove-PSDrive -Name $Win10UpgradeDrive -Force
    }


    $Win10UpgradeDriveStatus = New-PSDrive -Name $Win10UpgradeDrive -PSProvider FileSystem -Root $Win10UpgradeFolder -ErrorAction SilentlyContinue
    if (!([bool]($Win10UpgradeDriveStatus))) {

        Error-Handler "Script abort: Unable to map to setup folder [$Win10UpgradeFolder]" $ExitonError

    } else {

        # Stamp registry to make sure the device can download post-upgrade Windows Update patches
        # Fixes possible issues described here:
        # https://community.spiceworks.com/topic/2072278-all-win10-wsus-updates-showing-as-not-applicable-if-upgraded-to-creators
        # https://social.technet.microsoft.com/Forums/en-US/e9939d89-34fc-4f9e-a9ac-9e09cf6f8b57/windows-10-computers-not-getting-the-1709-update-possibly-down-to-quotbranchreadinesslevelquot?forum=ConfigMgrCompliance

        Write-Log "Applying registry fix for possible issue with Windows Update patches not downloading after Win10 upgrade"

        $RegKeys = "HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings", "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
        $Name = "BranchReadinessLevel"
        $NewValue = "0x10"

        foreach ($RegKey in $RegKeys) {
            Set-RegValue $RegKey $Name $NewValue "DWORD"
        }


        # Copy setup diagnostic in case it is needed later
        $Source = "\\mscsnyu01.nyumc.org\adbuild\DET_Builds\Packages\Microsoft Products\Diagnostics"
        $Target = "C:\TEMP"
        $Exec = "SetupDiag.exe"
        $SetupDiagInstaller = "$Source\$Exec"

        $CopyResult = Copy-Item -Path $SetupDiagInstaller -Destination $Target -ErrorAction SilentlyContinue -Force -PassThru
        if ([bool]$CopyResult) {
            Write-Log "This log captures the preparation steps for the Windows 10 Setup, not the log of the upgrade itself"
            Write-Log "To get the actual upgrade logs, run '$Target\$Exec' and analyze the '$Target\SetupDiagResults.log' and LOGS.ZIP files"
        }


        # And now we kick off the upgrade process
        Write-Log "Launching SETUP.EXE from setup folder [$Win10UpgradeFolder]"

        if ($DynamicUpdate) { $DynamicUpdateFlag = "enable" } else { $DynamicUpdateFlag = "disable" }

        # Can also add '/copylogs $OutputLogFolder' switch to redirect output of logfiles
        $SetupInstaller = "$Win10UpgradeDrive`:\Setup.exe"


        if ($Diagnostics) {

            # Define where the detailed seetup logs will be copied to
            $OutputLogFolder_SetupLogs = "$OutputLogFolder\$Machine"
            if (Test-Path -Path $OutputLogFolder_SetupLogs -PathType Container) {
                Get-ChildItem -Path $OutputLogFolder_SetupLogs -Recurse -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
            }
            New-Item -Path $OutputLogFolder_SetupLogs -ItemType Directory | Out-Null

            $SetupArgs = "/auto upgrade /dynamicUpdate $DynamicUpdateFlag /uninstall enable /telemetry enable /copylogs $OutputLogFolder_SetupLogs"

        } else {

            $SetupArgs = "/auto upgrade /dynamicUpdate $DynamicUpdateFlag /uninstall enable"

        }


        $SetupResult = Install-App -Installer $SetupInstaller -InstallArgs $SetupArgs -TimeLimit 5400  # time limit of 90 minutes (5400 seconds) to install
        ### $SetupResult = Install-App -Installer "c:\windows\system32\calc.exe" -ProcesstoCheck "Calculator" -TimeLimit 10

        if ($SetupResult.ExitStatus -eq $True) {

            Write-Log "Upgrade of Windows 10 was successful!"
           
            <#
            if ($LocalInstall) { 
                Write-Log "Removing local upgrade folder cache: $Win10UpgradeFolder"
                Get-ChildItem -Path $Win10UpgradeFolder -Recurse -ErrorAction SilentlyContinue | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
            }
            #>

            if ($Reboot) {
                Write-Log "Restarting computer to complete the upgrade..."
            } else {
                Write-Log "Please reboot this computer to complete the upgrade..."
            }

        } else {

            Write-Log "Upgrade of Windows 10 was *NOT* successful!"

        }

    }
    #endregion

} 

#endregion


#region Update log and exit script
$ScriptEndTime = Get-Date
$ScriptRunTime = Get-TimeDifference $ScriptStartTime $ScriptEndTime


$UpgradeStatus = [PSCustomObject]@{
    ScriptName = $ScriptName;
    ScriptVersion = $ScriptVersion;
    ScriptStartTime = $ScriptStartTime;
    ScriptEndTime = $ScriptEndTime;
    ScriptRunTime = $ScriptRunTime;
    Computer = $Machine;
    Manufacturer = $SysInfo.Manufacturer
    Model = $SysInfo.Model
    BIOS = $SysInfo.BIOS
    IPAddress = (Get-WmiObject -Class Win32_NetworkAdapterConfiguration | Where {$_.DefaultIPGateway -ne $Null}).IPAddress | Select-Object -First 1;
    Subnet = Get-Subnet $Machine;
    CurrentUserName = if ($CurrentUserName) {$CurrentUserName} else {"NO_CURRENT_LOGON"}
    ### CurrentUserSID = if ($CurrentUserSID) {$CurrentUserSID} else {"NO_CURRENT_LOGON"}
    "Current OS" = $OSFullName;
    "Upgrade OS" = $NewOSVersion;
    UpgradeLogFolder = $OutputLogFolder;
    SetupResult_ExitCode = $SetupResult.ExitCode;
    SetupResult_ExitStatus = $SetupResult.ExitStatus;
    SetupResult_ExitReason = $SetupResult.ExitReason;
}


# Write status to Windows Event Log
$EventLogName = "EUDE"
try {
    New-EventLog -LogName $EventLogName -Source $ScriptName  -ErrorAction SilentlyContinue 
    Write-EventLog -LogName $EventLogName -Source $ScriptName -EntryType Information -EventId 1980 -Message (Out-String -InputObject $UpgradeStatus)
    Write-Log "Wrote upgrade status information shown below to the [$EventLogName] Windows Event log"
}
catch {
    Error-Handler "Unable to write upgrade status information shown below to the [$EventLogName] Windows Event log" $NoExitonError
}

$UpgradeStatus

Write-Log "--------------------------------- END WINDOWS 10 UPGRADE SCRIPT ---------------------------------" "Green"


Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
Start-Sleep -Seconds 5
Upload-TranscriptLog $TranscriptLog $OutputLogFolder


# Begin the restart process if requested and return exit code back to caller
if ($SetupResult.ExitStatus -eq $True) { 

    <#
    # Define command to execute at the next reboot
    $ScriptFile = "\\mscsnyu01\adbuild\DET_Builds\Scripts\EUDE\install-win10featureupdate-dev.ps1"
    $CmdtoRun = "C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe -nologo -noprofile -windowstyle hidden -file ""$ScriptFile"" -SendLog"

    # Set HKLM RunOnce key to run script with the -SENDLOG switch - this will email the status after machine reboots *AND* when any domain user logs in
    # Preface value name in $RegName with a ! to defer deletion of the value until after the command runs. 
    # Without the ! prefix, if the RunOnce operation fails the associated program will not be asked to run the next time you start the computer.
    # https://docs.microsoft.com/en-us/windows/win32/setupapi/run-and-runonce-registry-keys
    $RegKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
    $RegName = "Get-Win10FeatureUpdateStatus"
    Set-RegValue $RegKey $RegName $CmdtoRun "STRING"
    #>


    # Create a scheduled task that will run at next reboot under SYSTEM context (so it does not require domain user to login to run it)
    Create-CustomScheduledTask -TaskName $Win10UpgradeStatusTask -TaskXMLFilePath $PSScriptRoot


    if ($Reboot) {
        $ShutdownComment = "Computer [$Machine] has been upgraded to: $NewOSVersion"
        & shutdown.exe -g -f -t 30 -d p:2:3 -c "$ShutdownComment"       
    }


    exit $SetupResult.ExitCode

} else {

    Email-TranscriptLog $SupportEmailAddress "WIN10 UPGRADE LOG FOR: $Machine" $TranscriptLog

    exit
    
}
#endregion

