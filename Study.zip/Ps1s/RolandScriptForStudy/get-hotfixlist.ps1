﻿#==========================================================================================================================================
# Program			: GET-HOTFIXLIST.PS1
# Version			: 1.0.0
# Date				: Feb 18 2020
# Author			: Roland Thomas
# Team				: MCIT / End User Device Engineering
#
# This script runs a Win10 setup diagnostic on a remote computer and then copies the logs back to the local machine in C:\TEMP\Win10SetupDiag_<machinename>
#
# 02-18-20 (v1.0.0) : First release
[cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]param(    [string[]]$Computername = $Null,    [string]$KBID = $Null)


$ScriptName = $MyInvocation.MyCommand.Name.ToUpper()
$ExitonError = $True
$NoExitonError = $False


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Error-Handler([string]$ErrorMessage, [boolean]$_ExitonError) {
    Write-Host -ForegroundColor Red "`r`n$($Script:ScriptName): $ErrorMessage"
    ### Write-Log $ErrorMessage

    if ($_.Exception.Message -ne $null) {
        Write-Host -ForegroundColor Red "`r`nSystem error message was:" $_.Exception.Message
        ### Write-Log $_.Exception.Message
     }

    if ($_ExitonError) { exit }
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-OnlineStatus($Machine) {    $PingStatus = Test-Connection -ComputerName $Machine -Count 1 -Quiet -ErrorAction SilentlyContinue    if ($PingStatus) {    ### $PingStatus = Ping-Computer -ComputerName $Machine    ### if ($PingStatus.Online) {        $Machine_IPAddress = (Test-Connection -ComputerName $Machine -Count 1).IPV4Address.IPAddressToString        $FQDN_Machine = ([System.Net.Dns]::GetHostEntry($Machine)).Hostname        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "Yes"
            DNSHostName = $FQDN_Machine
            IPAddress = $Machine_IPAddress
        }

    } else {        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "No"
            DNSHostName = "OFFLINE"
            IPAddress = "OFFLINE"
        }
    }    return $ReturnObject}
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-OSVersion ($OSName, $OSBuild) {

    if ($OSName -like "*Windows 7*") {

        $OSEdition = $OSName -replace "Windows 7","Win7"
        $OSVersion = "$OSEdition $OSBuild"    } else {        $OSEdition = $OSName -replace "Windows 10","Win10"        switch -Wildcard ($OSBuild) {            "*10240*" { $Win10_Version = "ver 1507 RTM" }
            "*10586*" { $Win10_Version = "ver 1511" }
            "*14393*" { $Win10_Version = "ver 1607" }
            "*15063*" { $Win10_Version = "ver 1703" }
            "*16299*" { $Win10_Version = "ver 1709" }
            "*17134*" { $Win10_Version = "ver 1803" }
            "*17763*" { $Win10_Version = "ver 1809" }
            "*18362*" { $Win10_Version = "ver 1903" }            "*18363*" { $Win10_Version = "ver 1909" }            "*19041*" { $Win10_Version = "ver 2004" }            "*19042*" { $Win10_Version = "ver 20H2" }            default { $Win10_Version = "ver UNKNOWN" }        }        $OSVersion = "$OSEdition ($Win10_Version - build $OSBuild)"
    }    return $OSVersion}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-Subnet($Machine) {

    try {
        $NetworkAdapters = Get-CimInstance -Namespace "root\cimv2" -Class Win32_NetworkAdapterConfiguration -ComputerName $Machine -OperationTimeoutSec 30 `
             -Property * -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | ? {($_.IPEnabled -eq "True") -and ($_.DefaultIPGateway -ne $Null)}

        $NetworkAdapters | % {
 
           # Compute the Subnet (Network ID) from the IP Address and Subnet Mask
           $IPAddress = @($_.IPAddress)[0]
           $IPAddress_Octets = $IPAddress -split "\."              # Split up IP Address into array of 4 octets
           $SubnetMask_Octets = @($_.IPSubnet)[0] -split "\."      # Do the same for the subnet mask
           $Subnet_Octets = @{}                                    # Initialize hashtable for the subnet

           for ($i=0; $i -le 3; $i++) {                            # Do binary-and on all octets
               [int32]$Subnet_Octets[$i] = [int32]$IPAddress_Octets[$i] -band [int32]$SubnetMask_Octets[$i]
               $Subnet_NetworkID += ($Subnet_Octets[$i]).ToString() + "."  # Concatenate the result back into dotted-notation
           }

           $Subnet_NetworkID = $Subnet_NetworkID -replace ".$"             # Strip off last dot (artifact of last command)

        }

    }

   catch { $Subnet_NetworkID = "OFFLINE" }

   return $Subnet_NetworkID

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SystemInfo ($Machine) {

    try {
        $OSInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem -ComputerName $Machine -ErrorAction SilentlyContinue    }    catch {        $OSInfo = $False        Error-Handler "Unable to query WMI Win32_OperatingSystem class on [$Machine]" $ExitonError
    }    if ($OSInfo) {        # Get last boot tiime        $BootTime = $OSInfo.ConvertToDateTime($OSInfo.LastBootUpTime)  # Use this if enumerating with GET-WMIOBJECT        ### $BootTime = $OSInfo.LastBootUpTime    # Use this if enumerating with GET-CIMINSTANCE        if ($BootTime -eq $Null) { $BootTime = "UNKNOWN" }
        # Get OS Version
        $OSName = $OSInfo.Caption -replace "Microsoft ",""        if ($OSName -like "*Windows 7*") {

            $OSVersion = Get-OSVersion $OSName $OSInfo.CSDVersion        } else {            $OSVersion = Get-OSVersion $OSName $OSInfo.Version        }

    } else {

        $OSVersion = "UNKNOWN"
        $BootTime = "UNKNOWN"
    }


    $ReturnObject = [PSCustomObject]@{
        OSVersion = $OSVersion
        BootTime = $BootTime
    }    return $ReturnObject
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function IsAdmin() {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Abort if user does not have local admin rights for certain functions
if (!(IsAdmin)) { Write-Warning "`nThis script requires admin privileges!  Please elevate and re-run the script."; exit }

$LocalTempFolder = "C:\TEMP"


if ($Computername) {

    cls


    foreach ($Computer in $Computername) {

        $Computer = $Computer.ToUpper()

        #region Create transcript on local drive to be added later to event log
        $TranscriptLog = "$LocalTempFolder\$Computer-HotFixList.log"

        #region Stop any previously running transcript that may not have closed due to abnormal script termination
        try{ Stop-Transcript| Out-Null }
        catch [System.InvalidOperationException]{}

        if (!(Test-Path -Path $LocalTempFolder)) { New-Item -Path $LocalTempFolder -ItemType Directory -ErrorAction SilentlyContinue | Out-Null }
        if (Test-Path -Path $TranscriptLog) { Remove-Item -Path $TranscriptLog -Force -ErrorAction SilentlyContinue }

        Start-Transcript -Path $TranscriptLog -IncludeInvocationHeader -Force
        #endregion

        Write-Host "`n" ("*" * 160) -ForegroundColor Cyan

        $ComputerStatus = Get-OnlineStatus $Computer

        if ($ComputerStatus.OnlineStatus -ne "Yes") {
            Write-Host "`nCannot ping machine [$Computer] - it may be offline`n" -ForegroundColor Red
            ### Error-Handler "`nCannot ping machine [$Computer] - it may be offline`n" $NoExitonError

        } else {

            $Subnet = Get-Subnet $Computer
            $SystemInfo = Get-SystemInfo $Computer

            $RemotePC = [PSCustomObject]@{
                HostName = $ComputerStatus.DNSHostName
                IPAddress = $ComputerStatus.IPAddress
                Subnet = if ($Subnet) {$Subnet} else {"UNKNOWN"}
                OSVersion= $SystemInfo.OSVersion
                LastBoot = $SystemInfo.BootTime
            }


            Write-Host "`nComputer [$Computer] is online and reporting this information:" -ForegroundColor Green
            $RemotePC | fl *


            try {
                if ($KBID) {

                    $Results = Get-HotFix -ComputerName $Computer -Id $KBID -ErrorAction SilentlyContinue | sort InstalledOn -Descending | ft -Autosize

                } else {
                    
                    $Results = Get-HotFix -ComputerName $Computer -ErrorAction SilentlyContinue | sort InstalledOn -Descending | ft -Autosize

                }


                if ([bool]$Results) {

                    $Results | fl *

                } else {

                    if ($KBID) {
                        Write-Host "Hotfix ID [$KBID] was not found installed on computer [$Computer]`n" -ForegroundColor Yellow
                        ### Error-Handler "Hotfix ID [$KBID] was not found installed on computer [$Computer]`n" $NoExitonError
                    } else {
                        Write-Host "No hotfixes were found installed on computer [$Computer]`n" -ForegroundColor Yellow
                        ### Error-Handler "No hotfixes were found installed on computer [$Computer]`n" $NoExitonError
                    }

                }


            }

            catch {
                Write-Warning "Unable to retrieve list of hotfixes installed on Computer [$Computer]"                ### Error-Handler "Unable to retrieve list of hotfixes installed on Computer [$Computer]" $NoExitonError          
            }

        }
      
    }       Stop-Transcript -ErrorAction SilentlyContinue | Out-Null

    Write-Host "Please review logfile written to --> $TranscriptLog" -ForegroundColor Yellow} else {

    Write-Host "`nUsage: $ScriptName -Computername <computer(s)> [-KBID <hotfixid>]"

}

