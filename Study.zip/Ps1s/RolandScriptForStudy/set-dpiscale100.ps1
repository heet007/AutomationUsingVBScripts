﻿#======================================================================================================================================================================# Program	: SET-DPISCALE100.PS1# Version	: 1.0.0# Date		: Oct 07 2020# Author	: Roland Thomas# Team		: MCIT / End User Device Engineering
#


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Copy-LogFiletoNetwork ($TranscriptLog, $NetworkLogFolder) {

    $Error.Clear()

    Stop-Transcript -ErrorAction SilentlyContinue | Out-Null

    # Copy logfile to network share
    if (Test-Path -Path $NetworkLogFolder) {
        Start-Sleep -Seconds 5
        Copy-Item -Path $TranscriptLog -Destination $NetworkLogFolder -Force -ErrorAction SilentlyContinue | Out-Null
    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-CurrentUser {

    $ProcessName = "explorer.exe"

    $Process = Get-WmiObject Win32_Process -Filter "Name='$ProcessName'" -ErrorAction SilentlyContinue

    if ([bool]$Process) {

        $UserName = ($Process | ForEach-Object { $_.GetOwner() } |  Select-Object -Unique -Expand User).ToUpper()

        $Principal = New-Object System.Security.Principal.NTAccount($env:USERDOMAIN, $UserName)

        $UserSID = ($Principal.Translate([System.Security.Principal.SecurityIdentifier])).Value

        ### Write-Log "Username = [$Username]; UserSID = [$UserSID]"

    } else {

        $UserName = $Null ; $UserSID = $Null

        Write-Log "Process [$ProcessName] was not found attached to any logged-on user"

    }

        
    $Result = [PSCustomObject]@{
        UserName = $UserName
        UserSID = $UserSID
    }

    return $Result
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-MonitorInfo {

    $MonitorInfo = @()

    $Monitors = Get-CimInstance -Namespace root\wmi -ClassName wmimonitorid

    foreach ($Monitor in $Monitors) {

        $MonitorProperties = [ordered]@{
            ModelName = ($Monitor.UserFriendlyName -notmatch '^0$' | foreach {[char]$_}) -join ""
            SerialNumber = ($Monitor.SerialNumberID -notmatch '^0$' | foreach {[char]$_}) -join ""
            ProductID = ($Monitor.ProductCodeID -notmatch '^0$' | foreach {[char]$_}) -join ""
            Manufacturer = ($Monitor.ManufacturerName -notmatch '^0$' | foreach {[char]$_}) -join ""
        }

        $MonthofManufacture = $($Monitor.WeekOfManufacture | % { $Month = [math]::Ceiling(($_/52)*12) ; [cultureinfo]::InvariantCulture.DateTimeFormat.GetMonthName($Month) })
        $ManufactureDate = $MonthofManufacture + " " + $Monitor.YearofManufacture        $MonitorProperties.Add("ManufactureDate", $ManufactureDate)

        $PrefixID = $MonitorProperties.Manufacturer + $MonitorProperties.ProductID + $MonitorProperties.SerialNumber
        $MonitorProperties.Add("PrefixID", $PrefixID)
        $MonitorInfo += [PSCustomObject]$MonitorProperties

    }

    return $MonitorInfo

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Is-Admin {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Set-RegValue ($Key, $Name, $NewValue, $Type) {

    $CurrentValue = (Get-ItemProperty -Path $Key -Name $Name -ErrorAction SilentlyContinue).$Name

    if (!($CurrentValue)) {

        if (!(Get-Item -Path $Key -ErrorAction SilentlyContinue)) { 

            try {
                New-Item -Path $Key -Force -ErrorAction SilentlyContinue | Out-Null
                Write-Host "Created new registry key [$Key]"
            }
            catch {
                $Error[0].Exception.Message
                return $False
            }

        }

        try {
            New-ItemProperty -Path $Key -Name $Name -Value $NewValue -PropertyType $Type -Force -ErrorAction SilentlyContinue | Out-Null
            Write-Host "Created new registry setting [$Key!$Name] with value [$NewValue]" -ForegroundColor Green
        }
        catch {
            $Error[0].Exception.Message
            return $False
        }


    } else {

        if ($CurrentValue -ne $NewValue) {

            try {
                Set-ItemProperty -Path $Key -Name $Name -Value $NewValue -Force -ErrorAction SilentlyContinue | Out-Null
                Write-Host "Change registry setting [$Key!$Name] from [$CurrentValue] to [$NewValue]" -ForegroundColor Green
            }
            catch {
                $Error[0].Exception.Message
                return $False
            }

        } else {

            Write-Host "Registry setting [$Key!$Name] already set to [$NewValue]" -ForegroundColor Green
            ### return $Null

        }

    }

    return $True

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------


cls


#region Initialize variables and arrays
$Computername = $env:COMPUTERNAME.ToUpper()

$Username = $env:USERNAME.ToUpper()
### $CurrentUser = Get-CurrentUser
### $Username = $CurrentUser.UserName
### $UserSID = $CurrentUser.UserSID

$DpiValue = -1 # DWORD:0xFFFFFFFF == 100% DPI scaling

$ActiveMonitorsKey = "HKCU:\Control Panel\Desktop\PerMonitorSettings"
### $ActiveMonitorsKey = "HKEY_USERS:\$UserSID\Control Panel\Desktop\PerMonitorSettings"
$EnumeratedMonitorsKey = "HKLM:\System\CurrentControlSet\Control\GraphicsDrivers\ScaleFactors"
#endregion


#region Create transcript log
$LocalTempFolder = "C:\TEMP"
$LogFilename = "$Computername-$Username-SETDPISCALE"
$TranscriptLog = "$LocalTempFolder\$LogFilename.log"
$NetworkLogFolder = "\\shares.nyumc.org\eude\Inventory\OnDemand\Radiology\PACS"


# Stop any previously running transcript that may not have closed due to abnormal script termination
try { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null }
catch {}

if (!(Test-Path -Path $LocalTempFolder)) { New-Item -Path $LocalTempFolder -ItemType Directory -ErrorAction SilentlyContinue | Out-Null }
if (Test-Path -Path $TranscriptLog) { Remove-Item -Path $TranscriptLog -Force -ErrorAction SilentlyContinue }

Start-Transcript -Path $TranscriptLog -IncludeInvocationHeader -ForceWrite-Host "********** SCRIPT BEGINS **********"
Write-Host "Computer Name    : $Computername"Write-Host "User Name        : $Username"#endregion

if (!(Is-Admin) ) {

    Write-Warning "This script requires local administrator rights.   Please run from an elevated Powershell prompt." 

} else {

    Write-Host "Script is running in elevated mode"

    #region Enumerate attached monitors and force scaling to 100%
    $MonitorInfo = Get-MonitorInfo

    ForEach ($Monitor in $MonitorInfo) {
        $MonitorIDKey = (Get-ChildItem -Path "$EnumeratedMonitorsKey\$($Monitor.PrefixID)*" -ErrorAction SilentlyContinue).PSChildName

        if ([bool]$MonitorIDKey) {

            $PerMonitorSettings = $ActiveMonitorsKey + '\' + $MonitorIDKey

            if (Test-Path -Path $PerMonitorSettings -ErrorAction SilentlyContinue) {

                Write-Host ("Changing existing DPIVALUE to 100% for monitor: {0} (Serial Number: {1})" -f $Monitor.ModelName, $Monitor.SerialNumber)

            } else {

                Write-Host ("Setting new DPIVALUE to 100% for monitor: {0} (Serial Number: {1})" -f $Monitor.ModelName, $Monitor.SerialNumber)

        	}

            Set-RegValue -Key $PerMonitorSettings -Name "DpiValue" -NewValue $DpiValue -Type DWORD | Out-Null

        }

    }
    #endregion


    #region Settings provided by Barco vendor
    $ControlPanelDesktopKey = "HKCU:\Control Panel\Desktop"
    Set-RegValue -Key $ControlPanelDesktopKey -Name "DpiScalingVer" -NewValue 4096 -Type DWORD | Out-Null
    Set-RegValue -Key $ControlPanelDesktopKey -Name "LogPixels" -NewValue 96 -Type DWORD | Out-Null
    Set-RegValue -Key $ControlPanelDesktopKey -Name "Win8DpiScaling" -NewValue 0x0 -Type DWORD | Out-Null
    #endregion
    

    #region Display monitor info and current screen resolution
    Write-Host "`n`nList of discovered display monitors:"
    $MonitorInfo | sort ModelName | ft *
    Write-Host "`n`nList of discovered video adapters:"
    Get-WmiObject -Class Win32_VideoController -Property * | ft Name, DriverVersion, Status, Current*Resolution -AutoSize
    #endregion}#region Stop the transcript, save log to network folder
Copy-LogFiletoNetwork $TranscriptLog $NetworkLogFolder
#endregion
