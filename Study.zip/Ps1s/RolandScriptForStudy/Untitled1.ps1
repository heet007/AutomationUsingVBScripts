﻿cls

$Monitors = Get-CimInstance -Namespace root\wmi -ClassName wmimonitorid

$Month
$Monitors.WeekOfManufacture

$Monitors.WeekOfManufacture | % { $Month = [math]::Ceiling(($_/52)*12) ; [cultureinfo]::InvariantCulture.DateTimeFormat.GetMonthName($Month) } 
