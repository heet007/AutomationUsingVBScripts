﻿#--------------------------------------------------
#
# Program			: Find_Dups_From_WS1.PS1
# Version			: 1.0.0
# Date				: Apr 28 2022
# Author			: Tai Nguyen
# Team				: MCIT / End User Device Engineering
#
# 04-28-2022 v1.0.0 : First release
#
#region Functions
Function Set-FileName { 

param($Extension,$Title)  
    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") |
    Out-Null

    $SaveFileDialog = New-Object System.Windows.Forms.SaveFileDialog
    #$SaveFileDialog.initialDirectory = $initialDirectory
    $SaveFileDialog.filter = "$Extension (*.$Extension)| *.$Extension"
    $SaveFileDialog.Title = $Title
    $SaveFileDialog.ShowDialog() | Out-Null
    $SaveFileDialog.filename

    #end function Set-FileName

    # *** Entry Point to Script ***

    #Set-FileName -initialDirectory "c:\fso"
}
Function Get-FileName {

param($initialDirectory,$Title,$Extension)   
    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") |
    Out-Null

    $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
    $OpenFileDialog.initialDirectory = $initialDirectory
    $OpenFileDialog.Title = $Title
    $OpenFileDialog.filter = "$Extension (*.$Extension)| *.$Extension"
    $OpenFileDialog.ShowDialog() | Out-Null
    $OpenFileDialog.filename

    #end function Get-FileName

    # *** Entry Point to Script ***

    #Get-FileName -initialDirectory "c:\fso"
}
Function Write-Log {
param($Message)
    $Time = Get-Date -Format "MM-dd-yyyy hh:mm:ss tt"
    Write-Output "[$Time] :: $Message"
}
$global:Alerts = New-Object -comObject Wscript.Shell #$Alerts.popup("Message",[int]delay,"Title",[int]Type)
#endregion Functions
#region Main
Write-Log "Starting Script"
Write-Log "Loading Device Data....."
$SaveFile = Set-FileName -Extension "csv" -Title "Save Duplicates Export"
$DeviceFile = Get-FileName -Extension "csv" -Title "Select Device Data"
$UserFile = Get-FileName -Extension "csv" -Title "Select User Data"
$a=Start-Job {param($DeviceFile); Import-Csv $DeviceFile} -ArgumentList $DeviceFile -Name "Device_Data" | Out-Null
$b=Start-Job {param($UserFile); Import-Csv $UserFile} -ArgumentList $UserFile -Name "User_Data" | Out-Null

Do{Get-Job | select Name,State ; sleep 10}while( $((Get-Job).State) -contains "Running")
$DeviceData = Receive-Job -Name "Device_Data"
$UserData = Receive-Job -Name "User_Data"
Get-Job | Remove-Job 
Write-Log "Data Loaded!"
Write-Log "Sorting Array..."
#Sort Array
$KIDs = $UserData.Device_Enrollment_user_name | Sort-Object -Descending
$Duplicates=@()
for($i=0;$i -lt $KIDs.count; $i++){
    if($($KIDs[$i]) -ne $null){
        Write-Log "$($KIDs[$i]) - $($i+1) of $($KIDs.count) - ($([math]::Round(($i*100)/$($KIDs.count)))%)"
        if($KIDs[$i] -eq $KIDs[$($i-1)]){
            Write-Warning "Found duplicate - $($KIDs[$i])"
            $Duplicates += $KIDs[$i]
        }
    }

}
$Duplicate_Report=@()
$d=1
$Duplicates = $Duplicates | select -Unique
foreach ($Dup in $Duplicates){
    Write-Log "Populating $Dup ($d of $($Duplicates.Count))"
    $Temp = $UserData | Where-Object{ $_.device_enrollment_user_name -eq $Dup}
    if($Temp.user_security_type -eq "Directory"){
        $Device_Count = $DeviceData | Where-Object {$_._user_name -eq $Dup} 
        $Temp | Add-Member -MemberType NoteProperty -Name "Device Count" -Value $(($Device_Count | Measure-Object).count) 
        $Temp | Add-Member -MemberType NoteProperty -Name "Device Enrolled" -Value $($Device_Count|Out-String)
        $Duplicate_Report += $Temp
        }else{
            $Duplicate_Report += $Temp
        }
    $d++
    }
$Duplicate_Report | export-csv $SaveFile -NoTypeInformation
Write-Log "Finished!"
$OpenFile = $Alerts.Popup("Script Completed, File saved to $SaveFile `n Would you like to open file now?",0,"$($MyInvocation.MyCommand)",1)
if($OpenFile -eq 1){Start-Process $SaveFile}
#endregion Main
