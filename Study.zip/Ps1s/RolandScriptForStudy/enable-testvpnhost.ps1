﻿# ==========================================================================================================================================# Program	: ENABLE-TESTVPNHOST.PS1# Version	: 1.0.0# Date		: Feb 01 2021# Author	: Roland Thomas# Team		: MCIT / End User Device Engineering## Toggle the HOSTS file on a local or remote computer to use the prod or test VPN environment
#
# v1.0.0 (02-01-21): First release
#
[cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]
param (
    [string[]]$Computers = $env:COMPUTERNAME,
    [string]$List,
    [switch]$Restore = $False
)



#region Initialize script-specific variables$ScriptFileName = $PSCommandPath.ToUpper()$ScriptFileInfo = Get-ChildItem -Path $ScriptFileName
$ScriptVersion = "v1.0.0 (020121)"
$ScriptBuild = $ScriptFileInfo.LastWriteTime.ToString("MM-dd-yyyy hh:mm:ss tt")

$ScriptName = $ScriptFileInfo.Name
$ScriptUNCPath = (Resolve-Path -Path $ScriptFileName).Drive.DisplayRoot + ((Split-Path -Path $ScriptFileName -NoQualifier) -replace $ScriptName,"")

$ScriptInfo = [PSCustomObject]@{
    Filename = $ScriptFileInfo.Name
    Fullname = $Scriptfileinfo.FullName
    Name = $ScriptFileInfo.BaseName
    Version = $ScriptVersion
    Build = $ScriptBuild
    Directory = $ScriptFileInfo.Directory
    UNCPath = $ScriptUNCPath
}

$ErrorActionPreference = "SilentlyContinue"
#endregion


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Is-Admin {

    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

cls


#region Initialization
$HostString = "216.165.125.88      nyuremotemobile.nyulangone.org nyuremotemobile.nyumc.org"
$HostPath = "c:\windows\system32\drivers\etc"
$LocalTempFolder = "c:\temp"
$NetworkLogFolder = "\\shares.nyumc.org\eude\logon\vpn\fulltunnel"
$Computername = $env:COMPUTERNAME.ToUpper()
#endregion


#region Validation
# Quit if not running with elevated rights
if (!(Is-Admin)) { Write-Output "This script requires admin privileges!  Please elevate and re-run the script." ; exit 999 }

# Quit if this is a Citrix session - hostnames begin with CTX
if ($Computername -like "CTX*") { Write-Output "This computername [$Computername] begins with 'CTX' which may mean a Citrix Network Desktop session" ; exit 997 }
#endregion


#region Start transcript
$TranscriptLog = "$LocalTempFolder\$($ScriptInfo.Name)-$Computername.log"

try { Stop-Transcript -ErrorAction SilentlyContinue | Out-Null }
catch {}

if (!(Test-Path -Path $LocalTempFolder)) { New-Item -Path $LocalTempFolder -ItemType Directory -ErrorAction SilentlyContinue | Out-Null }
if (Test-Path -Path $TranscriptLog) { Remove-Item -Path $TranscriptLog -Force -ErrorAction SilentlyContinue }

Start-Transcript -Path $TranscriptLog -IncludeInvocationHeader -Force

Write-Host ("-" * 50) "BEGIN SCRIPT" ("-" * 50) -ForegroundColor Green
#endregion


#region Parse text file of computers
Write-Output "`nHost String Pattern: $HostString `n"

if ($List) {

    if (Test-Path -Path $List) {

        $Computers = Get-Content -Path $List

    } else {

        Write-Host "Cannot find computer list file [$($List.ToUpper())]" -ForegroundColor Red
        exit 998

    }

}
#endregion


#region Iteration
foreach ($Computer in $Computers) {

    $Computer = $Computer.ToUpper()

    if (Test-Connection -ComputerName $Computer -Count 2 -Quiet) {
		
		$Result = Invoke-Command -ComputerName $Computer -ArgumentList $HostString, $HostPath, $LocalTempFolder, $Restore -EnableNetworkAccess -ErrorAction SilentlyContinue -ScriptBlock {

            param ($HostString, $HostPath, $LocalTempFolder, $Restore)

            # Backup the current HOSTS file to C:\TEMP
            Copy-Item -Path "$HostPath\hosts" -Destination $LocalTempFolder -Force

            # Either add or remove the new host IP address using the backup copy of the HOSTS file
            if (!$Restore) {

                # append the VPN host address to the end of the file
                $HostString | Add-Content -Path "$LocalTempFolder\hosts" -Force
                $StatusMessage = "updated"

            } else {

                # this will read in contents of the HOSTS file, strip out the line with the VPN address, and save the contents back to the same file
                Set-Content -Path "$LocalTempFolder\hosts" -Value (Get-Content -Path "$LocalTempFolder\hosts" | Select-String -Pattern $HostString -NotMatch)
                $StatusMessage = "restored"

            }

            # Copy the new HOSTS file back to the system folder
            Copy-Item -Path "$LocalTempFolder\hosts" -Destination $HostPath -Force
            Remove-Item -Path "$LocalTempFolder\hosts" -Force
            return $StatusMessage

        }

        # Output the contents of the HOSTS file to the screen
        Write-Host "`n[$Computer]: START OUTPUT - $($HostPath.ToUpper())\HOSTS file" -ForegroundColor Yellow
        Get-Content -Path "\\$Computer\C$\windows\system32\drivers\etc\hosts"
        Write-Host "[$Computer]: STOP OUTPUT - $($HostPath.ToUpper())\HOSTS file" -ForegroundColor Yellow
        Write-Host "`n[$Computer]: The local HOSTS file has been $Result (changes will take effect after reboot)." -ForegroundColor Green

    } else {

        Write-Host "[$Computer]: Could not ping computer." -ForegroundColor Red

    }

}
#endregion


#region Copy logfile to network share
Write-Host ("-" * 50) "END SCRIPT" ("-" * 50) -ForegroundColor Green

Stop-Transcript -ErrorAction SilentlyContinue | Out-Null

if (Test-Path -Path $NetworkLogFolder -ErrorAction SilentlyContinue) { Copy-Item -Path $TranscriptLog -Destination $NetworkLogFolder -Force -ErrorAction SilentlyContinue | Out-Null }

$ReturnCode = $LASTEXITCODE

exit $ReturnCode
#endregion

