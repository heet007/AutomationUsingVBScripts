﻿$Package = "XPS*"

$Logfile = "c:\temp\$env:COMPUTERNAME-XPS-VIEWER.log"

Get-WindowsCapability -Online -Name $Package | % {

    if ($_.State -eq "Installed") { 

        Write-Host "Package already installed : $($_.DisplayName)" 

    } else { 

        Write-Host "Installing package`t: $($_.DisplayName)" ;

        Add-WindowsCapability -Online -Name $($_.Name) -LogPath $Logfile `
            -Source "\\shares.nyumc.org\eude\DML\DML\Windows\Windows 10\FeaturesOnDemand\Install" `
            -LimitAccess | Out-Null

        Write-Host "Logfile saved to`t: $Logfile"

        Get-WindowsCapability -Online -Name $($_.Name)

    }

}
