﻿#==========================================================================================================================================# Program	: GET-WPRTRACESTATUS.PS1# Version	: 1.0.0# Date		: Jan 15 2020# Author	: Roland Thomas# Team		: MCIT / End User Device Engineering## This script will get status of a Windows Performance Recorder (WPR) boot/logon trace on a remote computer.### Usage     : GET-WPRTRACESTATUS.PS1 <machinespec>## 01-15-20 (v1.0.0): First release#Requires -Version 3.0### #Requires -RunAsAdministrator

[cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]param(    [string]$Computer = $Null)


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-OnlineStatus($Machine) {    $PingStatus = Test-Connection -ComputerName $Machine -Count 1 -Quiet    if ($PingStatus) {    ### $PingStatus = Ping-Computer -ComputerName $Machine    ### if ($PingStatus.Online) {        $Machine_IPAddress = (Test-Connection -ComputerName $Machine -Count 1).IPV4Address.IPAddressToString        $FQDN_Machine = ([System.Net.Dns]::GetHostEntry($Machine)).Hostname        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "Yes"
            DNSHostName = $FQDN_Machine
            IPAddress = $Machine_IPAddress
        }

    } else {        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "No"
            DNSHostName = "OFFLINE"
            IPAddress = "OFFLINE"
        }
    }    return $ReturnObject}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-RemoteCommandOutput {    [cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]    param(        [string]$Computer = $Null,        [string]$Location = $Null,        [string]$Command = $Null,        [string]$Arguments = $Null
    )


    $Results = Invoke-Command -ComputerName $Computer -HideComputerName -ArgumentList $Location, $Command, $Arguments -ScriptBlock { 

        param ($Location, $Command, $Arguments)

        $CommandPath = "$Location\$Command"

        if (Test-Path -Path $CommandPath) {

            Push-Location -Path $Location

            $CmdOutput = & $Command $Arguments

            Pop-Location

            return $CmdOutput

        } else {

            return $False

        }

    }

    return $Results

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-RemoteLocalGroupMember {    [cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]    param(        [string]$Computer = $Null,        [string]$GroupName = $Null,        [string]$UserName = $Null    )


    $Results = Invoke-Command -ComputerName $Computer -HideComputerName -ArgumentList $Computer, $GroupName, $UserName -ScriptBlock { 

        param ($RemoteComputer, $Group, $User) 

        return (Get-LocalGroupMember -Group $Group -Member $User -ErrorAction SilentlyContinue)

    }

    return $Results

}
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-RemoteProcessUpTime {    [cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]    param(        [string]$Computer = $Null    )


    $Results = Invoke-Command -ComputerName $Computer -HideComputerName -ScriptBlock { 

        $Properties = @{}
        $ProcessDuration = @()

        $ProcessList = Get-Process -ErrorAction SilentlyContinue

        foreach ($Process in $ProcessList) {

            $Properties = [ordered]@{
                Name = $Process.Name
                ID = $Process.ID
                Version = $Process.FileVersion
            }

            if ($Process.StartTime -ne $Null) {

                $TimeSpan = New-TimeSpan -Start $Process.StartTime -ErrorAction SilentlyContinue

                $Properties += [ordered]@{
                    StartTime = $Process.StartTime
                    Days = $TimeSpan.Days
                    Hours = $TimeSpan.Hours
                    Minutes = $TimeSpan.Minutes
                    Seconds = $TimeSpan.Seconds
                }

            }

            $ProcessDuration += New-Object -TypeName PSObject -Property $Properties

        }

        return ( $ProcessDuration | ? { $_.Name -ne "Idle" } ) # return all processes except the "Idle" process

    }

    return $Results

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-RemoteRegValue {

    [cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]    param(        [string]$Computer = $Null,        [string]$RegKeyPath = $Null,        [string]$RegKeyName = $Null    )


    $Results = Invoke-Command -ComputerName $Computer -HideComputerName -ArgumentList $Computer, $RegKeyPath, $RegKeyName -ScriptBlock { 

        param ($RemoteComputer, $Key, $Name) 

        return (Get-ItemProperty -Path $Key -Name $Name -ErrorAction SilentlyContinue).$Name
       
    }

    return $Results

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-RemoteTaskStatus {    [cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]    param(        [string]$Computer = $Null,        [string]$TaskName = $Null    )


    $Results = Invoke-Command -ComputerName $Computer -HideComputerName -ArgumentList $Computer, $TaskName -ScriptBlock { 

        param ($RemoteComputer, $Name) 

        return (Get-ScheduledTask -TaskName $Name -ErrorAction SilentlyContinue)

    }

    return $Results

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-RemoteUserProfile {    [cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]    param(        [string]$Computer = $Null    )


    $Results = Invoke-Command -ComputerName $Computer -HideComputerName -ArgumentList $Computer -ScriptBlock { 

        param ($RemoteComputer)

        $Properties = @{}
        $ProfileInfo = @()

        $ProfileList = Get-WmiObject -Class Win32_UserProfile -ErrorAction SilentlyContinue

        foreach ($Profile in $ProfileList) {
            
            try {
                $UserSID = New-Object System.Security.Principal.SecurityIdentifier($Profile.SID)
                $User = $UserSID.Translate([System.Security.Principal.NTAccount])
                $User
                $UserName = $User.Value
                $Username
            } catch {
                $UserName = $Profile.SID
            }


            switch ($Profile.Status){
                1 { $ProfileType = "Temporary" }
                2 { $ProfileType = "Roaming" }
                4 { $ProfileType = "Mandatory" }
                8 { $ProfileType = "Corrupted" }
                default { $ProfileType = "LOCAL" }
            }


            $Properties = [ordered]@{
                UserName = $UserName
                UserSID = $UserSID
                ProfileType = $ProfileType 
                ProfilePath = $Profile.LocalPath
                LastUseTime = ($Profile.ConvertToDateTime($Profile.LastUseTime)).ToString()
                ReferenceCount = $Profile.RefCount
                IsInUse = $Profile.Loaded
                IsSystemAccount = $Profile.Special
            }

            $ProfileInfo += New-Object -TypeName PSObject -Property $Properties

        }

        return $ProfileInfo

    }

    return $Results

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

$ScriptName = $MyInvocation.MyCommand.Name.ToUpper()
$Domain = $env:USERDOMAIN
$TestUser = "EUDEWIN10TEST05"
$UserName = "$Domain\$TestUser"


if ($Computer) { 

    $Computer = $Computer.ToUpper()

    $ComputerStatus = Get-OnlineStatus $Computer

    if ($ComputerStatus.OnlineStatus -ne "Yes") {        Write-Host "Cannot ping machine [$Computer] - it may be offline" -ForegroundColor Red
        exit
    }    


    cls

    $TranscriptLog = "c:\temp\wprtracestatus-$Computer.log"

    ### Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
    Start-Transcript -Path $TranscriptLog -Force -IncludeInvocationHeader

    Write-Host "`n" ("*" * 160) "`n" -ForegroundColor Cyan

    Write-Host "WPR Trace Status for Computer [$Computer]`r`n" -ForegroundColor Yellow

    # Get setup log file
    $Logfile = ("\\" + $Computer + '\c$\scripts\wprtools\wprtrace-setup.log').ToUpper()
    Write-Host "`nLOGFILE INFORMATION: $Logfile`n" -ForegroundColor Green
    if (Test-Path -Path $Logfile) { 
        cat $Logfile
    } else {
        Write-Host "LOGFILE NOT FOUND" -ForegroundColor Red
    }


    Write-Host "`n" ("*" * 160) "`n" -ForegroundColor Cyan


    # Get task status
    $Taskname = "EUDE_BOOTTRACE"
    $TaskStatus = Get-RemoteTaskStatus $Computer $Taskname
    Write-Host "`nTASK STATUS INFORMATION`n" -ForegroundColor Green
    if ($TaskStatus) { 
        $TaskStatus | Select-Object -Property * -ExcludeProperty RunspaceID | fl
    } else {
        Write-Host "TASK NOT FOUND: $Taskname" -ForegroundColor Red
    }


    Write-Host "`n" ("*" * 160) "`n" -ForegroundColor Cyan


    # Get autologon status 
    Write-Host "`nAUTOLOGON STATUS INFORMATION`n" -ForegroundColor Green
    $RegKey = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
    $RegName = @("AutoAdminLogon", "ForceAutoLogon", "DefaultDomainName", "DefaultUserName", "DefaultPassword")
    foreach ($Name in $RegName) {
        $RegValue = Get-RemoteRegValue $Computer $RegKey $Name
        if ($RegValue) { 
            Write-Host "$RegKey\$Name = $RegValue"
        } else {
            Write-Host "REGISTRY SETTING NOT FOUND: $RegKey\$Name" -ForegroundColor Red
        }
    }


    Write-Host "`n" ("*" * 160) "`n" -ForegroundColor Cyan


    # Get local admin status
    Write-Host "`nLOCAL ADMINISTRATOR RIGHTS INFORMATION" -ForegroundColor Green
    $GroupName = "Administrators"
    $MemberStatus = Get-RemoteLocalGroupMember $Computer $GroupName $UserName
    if ($MemberStatus) { 
        $MemberStatus | Select-Object -Property * -ExcludeProperty RunspaceID | fl
    } else {
        Write-Host "`nUSER [$UserName] NOT FOUND IN GROUP [$GroupName]" -ForegroundColor Red
    }


    Write-Host "`n" ("*" * 160) "`n" -ForegroundColor Cyan


    # Get user profile status
    Write-Host "`nUSER PROFILE INFORMATION" -ForegroundColor Green
    $ProfileStatus = Get-RemoteUserProfile $Computer | ? { $_.UserName -like "*$TestUser*" } | Select-Object -Property * -ExcludeProperty RunspaceID | fl
    if ($ProfileStatus) { 
        $ProfileStatus
    } else {
        Write-Host "`nUSER PROFILE [$UserName] NOT FOUND" -ForegroundColor Red
    }


    Write-Host "`n" ("*" * 160) "`n" -ForegroundColor Cyan


    # Get logon trace file status
    $Location = "\\$Computer\c$\temp\traces"
    Write-Host "`nREMOTE BOOT TRACE FILE INFORMATION: [$Location]" -ForegroundColor Green
    if (Test-Path -Path $Location -PathType Container) {

        dir $Location
        dir "\\$Computer\c$\scripts\wprtools"
        ### dir "\\$Computer\c$\windows\temp"
        ### dir "\\$Computer\c$\users\$TestUser\appdata\local\temp"

        $DiskSpace = Invoke-Command -ComputerName $Computer -ScriptBlock {

            $FreeDiskSpace = [math]::Round((Get-PSDrive -Name C).Free / 1GB)
            $UsedDiskSpace = [math]::Round((Get-PSDrive -Name C).Used / 1GB)
            $TotalDiskSpace = $FreeDiskSpace + $UsedDiskSpace

            return [PSCustomObject]@{
                Free = $FreeDiskSpace
                Used = $UsedDiskSpace
                Total = $TotalDiskSpace
            }

        }

        Write-Host "`n`nUsed Disk Space C:`t=`t$($DiskSpace.Used) GB"
        Write-Host "Free Disk Space C:`t=`t$($DiskSpace.Free) GB"
        Write-Host "Total Disk Space C:`t=`t$($DiskSpace.Total) GB"

    } else {
        Write-Host "`nWINDOWS EVENT TRACE LOG (ETL) TRACE FILES NOT FOUND" -ForegroundColor Red
    }


    Write-Host "`n" ("*" * 160) "`n" -ForegroundColor Cyan

    # Get user profile status
    $Location = "c:\scripts\wprtools"
    $Command = "wpr.exe"
    $Arguments = "-status"
    Write-Host "`nREMOTE COMMAND OUTPUT INFORMATION: [$Location\$Command $Arguments]" -ForegroundColor Green
    $CommandOutput = Get-RemoteCommandOutput $Computer $Location $Command $Arguments
    if ($CommandOutput) { 
        $CommandOutput
    } else {
        Write-Host "`nNO OUTPUT RETURNED" -ForegroundColor Red
    }


    Write-Host "`n" ("*" * 160) "`n" -ForegroundColor Cyan
       
    <#
    # Get user profile status
    Write-Host "`nREMOTE PROCESS INFORMATION" -ForegroundColor Green
    Get-RemoteProcessUpTime $Computer | sort StartTime -Descending | Select-Object -Property * -ExcludeProperty RunspaceID | ft
    #>

    Stop-Transcript -ErrorAction SilentlyContinue | Out-Null

} else {

    Write-Host "Usage: $ScriptName [-Computer <computername>]"

}
