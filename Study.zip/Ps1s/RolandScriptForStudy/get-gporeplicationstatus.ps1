﻿#==========================================================================================================================================# Program	: CHECK-VPNSTATUS.PS1# Version	: 1.2.0# Date		: Mar 28 2020# Author	: Roland Thomas# Team		: MCIT / End User Device Engineering## This script will enumerate all DCs and compare a specific GPO (timestamp, computer and user versioning) across the SYSVOL of all DCs##Requires -Version 3.0#Requires -RunAsAdministrator[cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]param(    [string]$GPOName = $Null)
Import-Module ActiveDirectory
cls

if ([string]::IsNullOrEmpty($GPOName)) { Write-Warning "GPO name not entered"; exit }

$GPOName = $GPOName.ToUpper()

if (!(Get-GPO -Name $GPOName -ErrorAction SilentlyContinue)) { Write-Warning "GPO [$GPOName] was not found in AD!" ; exit }

Write-Host "`n`nSearching for GPO [$GPOName] across all domain controllers..."

$ReplStatusTable = @()  # initialize empty table array for all the objects (one object created for each DC)
$ReplStatusProps = @{}   # initialize empty hashtable for the properties in each object

$DCList = Get-ADDomainController -Filter *

foreach ($DC in $DCList) {

    $GPOInformation = Get-GPO -Name $GPOName -Server $DC

    $GPOGUID = $GPOInformation.ID.ToString().ToUpper()

    $ReplStatusProps = [ordered] @{
        "DC Name" = $DC.Name;
        "Enabled" = $DC.Enabled;
        "IPAddress" = $DC.IPv4Address;
        "Server Operating System" = $DC.OperatingSystem;
        "Creation DateTime" = $GPOInformation.CreationTime;
        "Modification DateTime" = $GPOInformation.ModificationTime;
        "User Version (AD)" = $GPOInformation.User.DSVersion;
        "Computer Version (AD)" = $GPOInformation.Computer.DSVersion;
        "User Version (SYSVOL)" = $GPOInformation.User.SysvolVersion;
        "Computer Version (SYSVOL)" = $GPOInformation.Computer.SysvolVersion
        "GPO Settings Status" = $GPOInformation.GpoStatus
        ### "User Settings Enabled" = $GPOInformation.User.Enabled;
        ### "Computer Settings Enabled" = $GPOInformation.Computer.Enabled;
    }

    $ReplStatusTable += New-Object -TypeName PSObject -Property $ReplStatusProps    

}

Write-Host "`nGPO Name = $($GPOInformation.DisplayName)" -ForegroundColor Yellow
Write-Host "GPO GUID = {$GPOGUID}" -ForegroundColor Yellow

$ReplStatusTable | Sort DC* | ft *

Write-Host "Number of Domain Controllers scanned: $($DCList.Count)`n"
