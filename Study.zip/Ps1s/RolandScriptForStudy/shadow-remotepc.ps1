﻿#==========================================================================================================================================# Program	: SHADOW-REMOTEPC.PS1# Version	: 1.0.0# Date		: Feb 05 2020# Author	: Roland Thomas# Team		: MCIT / End User Device Engineering## This script uses RDP to login remotely to a domain-bound machine or to shadow a user active screen (with their consent).## Usage     : SHADOW-REMOTEPC.PS1 -Computer <computername> [-Shadow] [-Username <username> -Password <password>] [-Local]## 02-05-20 (v1.0.0): First release#Requires -Version 3.0### #Requires -RunAsAdministrator

[cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]param(    [string]$Computer = $Null,    [switch]$Shadow = $False,    [switch]$Force = $False,    [switch]$Local = $False,    [string]$UserName,
    [string]$Password
)


$ScriptName = $MyInvocation.MyCommand.Name.ToUpper()
$ErrorActionPreference = "SilentlyContinue"
$VerbosePreference = "SilentlyContinue"
$ExitonError = $True
$NoExitonError = $False


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Error-Handler([string]$ErrorMessage, [boolean]$_ExitonError) {
    Write-Host -ForegroundColor Red "`r`n$($Script:ScriptName): $ErrorMessage"
    ### Write-Log $ErrorMessage

    if ($_.Exception.Message -ne $null) {
        Write-Host -ForegroundColor Red "`r`nSystem error message was:" $_.Exception.Message
        ### Write-Log $_.Exception.Message
     }

    if ($_ExitonError) { exit }
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-DNtoCN([string]$DistinguishedName) {

    # Parsing if an empty string is sent 
    if ([string]::IsNullOrEmpty($DistinguishedName)) { return $Null }


    # Strip off leading LDAP prefix if there is any
    if ($DistinguishedName -like "LDAP://*") { $DistinguishedName = $DistinguishedName -replace "LDAP://","" }


    # Split the distinguished name into separate bits 
    $Parts = $DistinguishedName.Split(",")
 
    foreach ($Part in $Parts) {
        if ($Part -like "OU=*") {
            $Subpart = $Part -replace "OU=",""
            $CanonicalName = "/$Subpart" + $CanonicalName
        }

    }

    $CanonicalName = "nyumc.org" + $CanonicalName

    return $CanonicalName

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-OnlineStatus($Machine) {    $PingStatus = Test-Connection -ComputerName $Machine -Count 1 -Quiet -ErrorAction SilentlyContinue    if ($PingStatus) {    ### $PingStatus = Ping-Computer -ComputerName $Machine    ### if ($PingStatus.Online) {        $Machine_IPAddress = (Test-Connection -ComputerName $Machine -Count 1).IPV4Address.IPAddressToString        $FQDN_Machine = ([System.Net.Dns]::GetHostEntry($Machine)).Hostname        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "Yes"
            DNSHostName = $FQDN_Machine
            IPAddress = $Machine_IPAddress
        }

    } else {        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "No"
            DNSHostName = "OFFLINE"
            IPAddress = "OFFLINE"
        }
    }    return $ReturnObject}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-CurrentRemoteUser ($Machine) {

    try {

        $UserInfo = Invoke-Command -ComputerName $Machine -ErrorAction SilentlyContinue -ScriptBlock {
            $ErrorActionPreference = "SilentlyContinue"
            $Quser = quser.exe
            if ($Quser) {
                return ($QuserInfo = $Quser[1] -replace '\s+',' ' -split " ")
            } else {
                return $False
            }
        }


        if ($UserInfo) {
            try { if (Get-Process logonui -ComputerName $Machine -ErrorAction Stop) { $WorkstationState = "LOCKED" } } 
            catch { $WorkstationState = "UNLOCKED" } 

            $UserName = $UserInfo[1].ToUpper()       
            $UserFullName = (Get-ADUser -Identity $UserName -Properties DisplayName).DisplayName

            if ($UserInfo.Count -eq 8) { # HACK: if number of elements = 8, that means the SessionName is blank, and need to decrement index
    
                $CurrentRemoteUser = [PSCustomObject]@{
                    UserName = $UserName
                    UserFullName = $UserFullName
                    SessionName = "NONE"
                    SessionID = $UserInfo[2]
                    UserState = $UserInfo[3].ToUpper()
                    IdleTime= $UserInfo[4]
                    LogonTime = $UserInfo[5] + " " + $UserInfo[6] + $UserInfo[7]
                    WorkstationState = $WorkstationState
                }

            } else {

                $CurrentRemoteUser = [PSCustomObject]@{
                    UserName = $UserName
                    UserFullName = $UserFullName
                    SessionName = $UserInfo[2].ToUpper()
                    SessionID = $UserInfo[3]
                    UserState = $UserInfo[4].ToUpper()
                    IdleTime= $UserInfo[5]
                    LogonTime = $UserInfo[6] + " " + $UserInfo[7] + $UserInfo[8]
                    WorkstationState = $WorkstationState
               }

            }

        } else {
            $CurrentRemoteUser = $False
        }

    }


    catch {
        $CurrentRemoteUser = $False
    }

    return $CurrentRemoteUser}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-OSVersion ($OSName, $OSBuild) {

    if ($OSName -like "*Windows 7*") {

        $OSEdition = $OSName -replace "Windows 7","Win7"
        $OSVersion = "$OSEdition $OSBuild"    } else {        $OSEdition = $OSName -replace "Windows 10","Win10"        switch -Wildcard ($OSBuild) {            "*10240*" { $Win10_Version = "ver 1507 RTM" }
            "*10586*" { $Win10_Version = "ver 1511" }
            "*14393*" { $Win10_Version = "ver 1607" }
            "*15063*" { $Win10_Version = "ver 1703" }
            "*16299*" { $Win10_Version = "ver 1709" }
            "*17134*" { $Win10_Version = "ver 1803" }
            "*17763*" { $Win10_Version = "ver 1809" }
            "*18362*" { $Win10_Version = "ver 1903" }            "*18845*" { $Win10_Version = "ver InsiderPreview-20H1" }            default { $Win10_Version = "ver UNKNOWN" }        }        $OSVersion = "$OSEdition ($Win10_Version - build $OSBuild)"
    }    return $OSVersion}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-Subnet($Machine) {

    try {
        $NetworkAdapters = Get-CimInstance -Namespace "root\cimv2" -Class Win32_NetworkAdapterConfiguration -ComputerName $Machine -OperationTimeoutSec 30 `
             -Property * -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | ? {($_.IPEnabled -eq "True") -and ($_.DefaultIPGateway -ne $Null)}

        $NetworkAdapters | % {
 
           # Compute the Subnet (Network ID) from the IP Address and Subnet Mask
           $IPAddress = @($_.IPAddress)[0]
           $IPAddress_Octets = $IPAddress -split "\."              # Split up IP Address into array of 4 octets
           $SubnetMask_Octets = @($_.IPSubnet)[0] -split "\."      # Do the same for the subnet mask
           $Subnet_Octets = @{}                                    # Initialize hashtable for the subnet

           for ($i=0; $i -le 3; $i++) {                            # Do binary-and on all octets
               [int32]$Subnet_Octets[$i] = [int32]$IPAddress_Octets[$i] -band [int32]$SubnetMask_Octets[$i]
               $Subnet_NetworkID += ($Subnet_Octets[$i]).ToString() + "."  # Concatenate the result back into dotted-notation
           }

           $Subnet_NetworkID = $Subnet_NetworkID -replace ".$"             # Strip off last dot (artifact of last command)

        }

    }

   catch { $Subnet_NetworkID = "OFFLINE" }

   return $Subnet_NetworkID

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SystemInfo ($Machine) {

    try {
        $OSInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem -ComputerName $Machine -ErrorAction SilentlyContinue    }    catch {        $OSInfo = $False        Error-Handler "Unable to query WMI Win32_OperatingSystem class on [$Machine]" $ExitonError
    }    if ($OSInfo) {        # Get last boot tiime        $BootTime = $OSInfo.ConvertToDateTime($OSInfo.LastBootUpTime)  # Use this if enumerating with GET-WMIOBJECT        ### $BootTime = $OSInfo.LastBootUpTime    # Use this if enumerating with GET-CIMINSTANCE        if ($BootTime -eq $Null) { $BootTime = "UNKNOWN" }
        # Get OS Version
        $OSName = $OSInfo.Caption -replace "Microsoft ",""        if ($OSName -like "*Windows 7*") {

            $OSVersion = Get-OSVersion $OSName $OSInfo.CSDVersion        } else {            $OSVersion = Get-OSVersion $OSName $OSInfo.Version        }

    } else {

        $OSVersion = "UNKNOWN"
        $BootTime = "UNKNOWN"
    }


    $ReturnObject = [PSCustomObject]@{
        OSVersion = $OSVersion
        BootTime = $BootTime
    }    return $ReturnObject
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function IsAdmin() {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-YesNoAnswer ([string]$PromptMessage) {

    do {

        $Prompt = (Read-Host "`n$PromptMessage [Y / N] ").ToUpper()

    } while($Prompt -notmatch "[YN]")

    return $Prompt
}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Abort if user does not have local admin rights for certain functions
if (!(IsAdmin)) { Write-Warning "This script requires admin privileges!  Please elevate and re-run the script."; exit }


# Parameter validation
if ($Username -and !$Password) { Write-Host "Username entered but missing Password" ; exit }
if ($Password -and !$UserName) { Write-Host "Password entered but missing Username" ; exit }
if ($Local) { $ContextType = "local" } else { $ContextType = "domain" }


if ($Computer) { 

    cls

    $Computer = $Computer.ToUpper()

    $ComputerStatus = Get-OnlineStatus $Computer

    if ($ComputerStatus.OnlineStatus -ne "Yes") {        Write-Host "`nCannot ping machine [$Computer] - it may be offline" -ForegroundColor Red
        exit
    }    


    if ($UserName) {

        $UserName = $UserName.ToUpper()

        Write-Host "`nValidating $ContextType credentials for [$Username] " -NoNewline

        try {
            if ($Local) {   # we need to validate the local credentials on the remote computer itself using INVOKE-COMMAND
                $Domain = "localhost"
                Write-Host "on remote computer [$Computer] ... " -NoNewline
                $ValidCreds = Invoke-Command -ComputerName $Computer -ArgumentList $Computer, $UserName, $Password -ScriptBlock {
                    param ($Computer, $UserName, $Password)
                    Add-Type -AssemblyName System.DirectoryServices.AccountManagement
                    $DS = New-Object System.DirectoryServices.AccountManagement.PrincipalContext('machine',$Computer) -ErrorAction SilentlyContinue
                    return ($DS.ValidateCredentials($UserName, $Password))
                }
            } else {
                $Domain = $env:USERDOMAIN
                Write-Host "on the $Domain domain ... " -NoNewline
                Add-Type -AssemblyName System.DirectoryServices.AccountManagement
                $DS = New-Object System.DirectoryServices.AccountManagement.PrincipalContext('domain',$Domain) -ErrorAction SilentlyContinue
                $ValidCreds = $DS.ValidateCredentials($UserName, $Password)
            }
    

            if ($ValidCreds) {
                $ValidCreds = $True
                Write-Host "validated and cached" -ForegroundColor Green
                cmdkey.exe /generic:TERMSRV/$Computer /user:$Domain\$UserName /pass:$Password #| Out-Null
            } else {
                Write-Host "unable to validate credentials" -ForegroundColor Red
                exit
            }
        }
        catch { Write-Host "`nCannot access security principal for user [$Username] in the [$Domain] context" -ForegroundColor Red ; exit }

    }

    ### cmdkey.exe /list:TERMSRV/$Computer
    ### exit
    
    Write-Host "`nChecking to see if Computer [$Computer] is online ..."

    $Subnet = Get-Subnet $Computer
    $SystemInfo = Get-SystemInfo $Computer
    $CurrentOU = Convert-DNtoCN (Get-ADComputer -Filter 'Name -like $Computer').DistinguishedName
    $CurrentUser = Get-CurrentRemoteUser $Computer

    if ([bool]$CurrentUser) { 
        $CurrentUserName = $CurrentUser.UserName
        if ([bool]($CurrentUser.UserFullName)) { 
            $CurrentUserFullName = $CurrentUser.UserFullName
        } else {
            $CurrentUserFullName = $CurrentUserName
        }
        $LogonTime = $CurrentUser.LogonTime
        $UserState = $CurrentUser.UserState
        $WorkstationState = $CurrentUser.WorkstationState
    } else {
        $CurrentUserName, $CurrentUserFullName, $LogonTime, $UserState, $WorkstationState = "N/A"
    }

    $RemotePC = [PSCustomObject]@{
        HostName = $ComputerStatus.DNSHostName
        IPAddress = $ComputerStatus.IPAddress
        Subnet = if ($Subnet) {$Subnet} else {"UNKNOWN"}
        OSVersion= $SystemInfo.OSVersion
        CurrentOU = $CurrentOU
        BootTime = $SystemInfo.BootTime
        CurrentUser = $CurrentUserName
        FullName = $CurrentUserFullName
        LogonTime = $LogonTime
        UserState = $UserState
        WorkstationState = $WorkstationState
    }

    Write-Host "`nComputer [$Computer] is online and reporting this information:"
    $RemotePC


    if ($CurrentUser -eq $False) {
    
        Write-Host "`nThe computer currently has no one logged in" -ForegroundColor Green
        $Answer = Get-YesNoAnswer "Do you want to connect remotely to [$Computer]"

    } else {

        Write-Host "`nThe computer currently has user [$CurrentUserName] logged in" -ForegroundColor Green
        $Answer = Get-YesNoAnswer "Do you want to shadow [$CurrentUserName] on [$Computer]"

    }

    
    if ($Answer -eq "Y") {

        if ($Shadow) {

            Invoke-Command -ComputerName $Computer -ScriptBlock {
                reg add "HKLM\Software\Policies\Microsoft\Windows NT\Terminal Services" /v Shadow /d 2 /t REG_DWORD
                start-sleep -Seconds 3
            }

            switch ($WorkstationState) {

                "Locked" {
                    Write-Host "`nAttempting to connect to [$Computer] - workstation was locked by current user [$CurrentUserName] ..."
                    if ($ValidCreds) { $Arguments = "/v:$Computer" } else { $Arguments = "/v:$Computer /prompt" }
                }

                "Unlocked" {
                    Write-Host "`nAttempting to connect to [$Computer] and shadow current user [$CurrentUserName] ..."
                    if ($Force) {
                        $Arguments = "/v:$Computer /control /shadow:$($CurrentUser.SessionID) /noconsentprompt"
                    } else {
                        $Arguments = "/v:$Computer /control /shadow:$($CurrentUser.SessionID)"
                    }
                }        

                default {
                    Write-Host "`nAttempting to logon to [$Computer] - no user is currently logged on ..."
                    $Arguments = "/v:$Computer /prompt"
                }        

            }
       
        } else {

            if ($CurrentUser) {
                Write-Host "`nAttempting to connect to [$Computer] - this will disconnect current user [$CurrentUserName] ..."
                if ($ValidCreds) { $Arguments = "/v:$Computer" } else { $Arguments = "/v:$Computer /prompt" }
            } else {
                Write-Host "`nAttempting to logon to [$Computer] - no user is currently logged on ..."
                if ($ValidCreds) { $Arguments = "/v:$Computer" } else { $Arguments = "/v:$Computer /prompt" }              
            }        

        }


        try {

            ### & { $Process = Start-Process mstsc.exe -ArgumentList "$Arguments" -PassThru }
            $Process = Start-Process mstsc.exe -ArgumentList "$Arguments" -PassThru            Start-Sleep -Seconds 10  # wait arbitary number of seconds so that RDP connection can be established before clearing the credential cache
            $Events = Get-WinEvent -ComputerName $Computer -LogName "Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational" -ErrorAction SilentlyContinue | ? { ($_.ID -eq 1149) -or ($_.ID -eq 20506) -or ($_.ID -eq 20510) } | select -First 1

            ### $Events | fl *

            if ([bool]$Events) {

                $RecordedEvents = "`nThe 'Microsoft-Windows-TerminalServices-RemoteConnectionManager\Operational' Event Log on remote computer [$Computer] recorded this event at $($Events.TimeCreated):" + (Out-String -InputObject ($Events | fl ID, TimeCreated, UserID, Message))

                Write-Host $RecordedEvents -ForegroundColor Yellow

                # Write status to Windows Event Log
                $EventLogName = "EUDE"
                try {
                    New-EventLog -LogName $EventLogName -Source $ScriptName  -ErrorAction SilentlyContinue 
                    Write-EventLog -LogName $EventLogName -Source $ScriptName -EntryType Information -EventId 1984 -Message (Out-String -InputObject $RecordedEvents)
                    Write-Host "This event information was written to the [$EventLogName] Event log on host computer [$env:COMPUTERNAME]" -ForegroundColor Green
                }
                catch {
                    Error-Handler "Unable to write this event information to the [$EventLogName] Event log on host computer [$env:COMPUTERNAME]" $NoExitonError
                }
           
            }
        }

        catch { Error-Handler "Failed to connect to: $Computer" $ExitonError }

    }    if ( (cmdkey.exe /list:TERMSRV/$Computer) -notlike "*NONE*") {
        cmdkey.exe /delete:TERMSRV/$Computer | Out-Null
    }
} else {

    Write-Host "Usage: $ScriptName -Computer <computername> [-Shadow] [-Username <username> -Password <password>] [-Local]"

}

