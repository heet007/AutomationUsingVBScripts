﻿#==========================================================================================================================================
# Program			: GET-USERPROFILES.PS1
# Version			: 1.0.0
# Date				: May 20 2020
# Author			: Roland Thomas
# Team				: MCIT / End User Device Engineering
#
# This script retrieves list of all user profiles from a remote computer
# 
# REFERENCE LINKS
# ---------------
# https://docs.microsoft.com/en-us/previous-versions/windows/desktop/legacy/bb776896(v%3dvs.85)
#

# 05-20-20 (v1.0.0) : First release
[cmdletbinding (SupportsShouldProcess=$True, ConfirmImpact="High")]param(    [string]$Computer = $env:COMPUTERNAME,    [switch]$CurrentUser = $True,    [switch]$ShowProgress = $False)


$ScriptName = $MyInvocation.MyCommand.Name.ToUpper()
$ExitonError = $True
$NoExitonError = $False
$Target = "C:\TEMP"


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Error-Handler([string]$ErrorMessage, [boolean]$_ExitonError) {
    Write-Host -ForegroundColor Red "`r`n$($Script:ScriptName): $ErrorMessage"
    ### Write-Log $ErrorMessage

    if ($_.Exception.Message -ne $null) {
        Write-Host -ForegroundColor Red "`r`nSystem error message was:" $_.Exception.Message
        ### Write-Log $_.Exception.Message
     }

    if ($_ExitonError) { exit }
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-DNtoCN([string]$DistinguishedName) {

    # Parsing if an empty string is sent 
    if ([string]::IsNullOrEmpty($DistinguishedName)) { return $Null }


    # Strip off leading LDAP prefix if there is any
    if ($DistinguishedName -like "LDAP://*") { $DistinguishedName = $DistinguishedName -replace "LDAP://","" }


    # Split the distinguished name into separate bits 
    $Parts = $DistinguishedName.Split(",")
 
    foreach ($Part in $Parts) {
        if ($Part -like "OU=*") {
            $Subpart = $Part -replace "OU=",""
            $CanonicalName = "/$Subpart" + $CanonicalName
        }

    }

    $CanonicalName = "nyumc.org" + $CanonicalName

    return $CanonicalName

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-OnlineStatus($Machine) {    $PingStatus = Test-Connection -ComputerName $Machine -Count 1 -Quiet -ErrorAction SilentlyContinue    if ($PingStatus) {    ### $PingStatus = Ping-Computer -ComputerName $Machine    ### if ($PingStatus.Online) {        $Machine_IPAddress = (Test-Connection -ComputerName $Machine -Count 1).IPV4Address.IPAddressToString        $FQDN_Machine = ([System.Net.Dns]::GetHostEntry($Machine)).Hostname        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "Yes"
            DNSHostName = $FQDN_Machine
            IPAddress = $Machine_IPAddress
        }

    } else {        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "No"
            DNSHostName = "OFFLINE"
            IPAddress = "OFFLINE"
        }
    }    return $ReturnObject}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-CurrentRemoteUser ($Machine) {

    try {

        $UserInfo = Invoke-Command -ComputerName $Machine -ErrorAction SilentlyContinue -ScriptBlock {
            $ErrorActionPreference = "SilentlyContinue"
            $Quser = quser.exe
            if ($Quser) {
                return ($QuserInfo = $Quser[1] -replace '\s+',' ' -split " ")
            } else {
                return $False
            }
        }


        if ($UserInfo) {
            try { if (Get-Process logonui -ComputerName $Machine -ErrorAction Stop) { $WorkstationState = "LOCKED" } } 
            catch { $WorkstationState = "UNLOCKED" } 
    
            if ($UserInfo.Count -eq 8) { # HACK: if number of elements = 8, that means the SessionName is blank, and need to decrement index
    
                $CurrentRemoteUser = [PSCustomObject]@{
                    UserName = $UserInfo[1].ToUpper()
                    SessionName = "NONE"
                    SessionID = $UserInfo[2]
                    UserState = $UserInfo[3].ToUpper()
                    IdleTime= $UserInfo[4]
                    LogonTime = $UserInfo[5] + " " + $UserInfo[6] + $UserInfo[7]
                    WorkstationState = $WorkstationState
                }

            } else {

                $CurrentRemoteUser = [PSCustomObject]@{
                    UserName = $UserInfo[1].ToUpper()
                    SessionName = $UserInfo[2].ToUpper()
                    SessionID = $UserInfo[3]
                    UserState = $UserInfo[4].ToUpper()
                    IdleTime= $UserInfo[5]
                    LogonTime = $UserInfo[6] + " " + $UserInfo[7] + $UserInfo[8]
                    WorkstationState = $WorkstationState
               }

            }

        } else {
            $CurrentRemoteUser = $False
        }

    }


    catch {
        $CurrentRemoteUser = $False
    }

    return $CurrentRemoteUser}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-DiskSpaceInfo ($Machine) {

    try {
        $Results = Invoke-Command -ComputerName $Machine -ErrorAction SilentlyContinue -ScriptBlock {
            $FreeDiskSpace = [math]::Round((Get-PSDrive -Name C).Free / 1GB)
            $UsedDiskSpace = [math]::Round((Get-PSDrive -Name C).Used / 1GB)

            return [PSCustomObject]@{
                "Free Space" = "$FreeDiskSpace GB"
                "Used Space" = "$UsedDiskSpace GB"
                "Total Space" = "{0} GB" -f ($FreeDiskSpace + $UsedDiskSpace)
            }
        }
    }
    catch { $Results = $False }


    return $Results

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-OSVersion ($OSName, $OSBuild) {

    if ($OSName -like "*Windows 7*") {

        $OSEdition = $OSName -replace "Windows 7","Win7"
        $OSVersion = "$OSEdition $OSBuild"    } else {        $OSEdition = $OSName -replace "Windows 10","Win10"        switch -Wildcard ($OSBuild) {            "*10240*" { $Win10_Version = "ver 1507 RTM" }
            "*10586*" { $Win10_Version = "ver 1511" }
            "*14393*" { $Win10_Version = "ver 1607" }
            "*15063*" { $Win10_Version = "ver 1703" }
            "*16299*" { $Win10_Version = "ver 1709" }
            "*17134*" { $Win10_Version = "ver 1803" }
            "*17763*" { $Win10_Version = "ver 1809" }
            "*18362*" { $Win10_Version = "ver 1903" }            "*18845*" { $Win10_Version = "ver InsiderPreview-20H1" }            default { $Win10_Version = "ver UNKNOWN" }        }        $OSVersion = "$OSEdition ($Win10_Version - build $OSBuild)"
    }    return $OSVersion}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-Subnet($Machine) {

    try {
        $NetworkAdapters = Get-CimInstance -Namespace "root\cimv2" -Class Win32_NetworkAdapterConfiguration -ComputerName $Machine -OperationTimeoutSec 30 `
             -Property * -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | ? {($_.IPEnabled -eq "True") -and ($_.DefaultIPGateway -ne $Null)}

        $NetworkAdapters | % {
 
           # Compute the Subnet (Network ID) from the IP Address and Subnet Mask
           $IPAddress = @($_.IPAddress)[0]
           $IPAddress_Octets = $IPAddress -split "\."              # Split up IP Address into array of 4 octets
           $SubnetMask_Octets = @($_.IPSubnet)[0] -split "\."      # Do the same for the subnet mask
           $Subnet_Octets = @{}                                    # Initialize hashtable for the subnet

           for ($i=0; $i -le 3; $i++) {                            # Do binary-and on all octets
               [int32]$Subnet_Octets[$i] = [int32]$IPAddress_Octets[$i] -band [int32]$SubnetMask_Octets[$i]
               $Subnet_NetworkID += ($Subnet_Octets[$i]).ToString() + "."  # Concatenate the result back into dotted-notation
           }

           $Subnet_NetworkID = $Subnet_NetworkID -replace ".$"             # Strip off last dot (artifact of last command)

        }

    }

   catch { $Subnet_NetworkID = "OFFLINE" }

   return $Subnet_NetworkID

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SystemInfo ($Machine) {

    try {
        $OSInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem -ComputerName $Machine -ErrorAction SilentlyContinue    }    catch {        $OSInfo = $False        Error-Handler "Unable to query WMI Win32_OperatingSystem class on [$Machine]" $ExitonError
    }    if ($OSInfo) {        # Get last boot tiime        $BootTime = $OSInfo.ConvertToDateTime($OSInfo.LastBootUpTime)  # Use this if enumerating with GET-WMIOBJECT        ### $BootTime = $OSInfo.LastBootUpTime    # Use this if enumerating with GET-CIMINSTANCE        if ($BootTime -eq $Null) { $BootTime = "UNKNOWN" }
        # Get OS Version
        $OSName = $OSInfo.Caption -replace "Microsoft ",""        if ($OSName -like "*Windows 7*") {

            $OSVersion = Get-OSVersion $OSName $OSInfo.CSDVersion        } else {            $OSVersion = Get-OSVersion $OSName $OSInfo.Version        }

    } else {

        $OSVersion = "UNKNOWN"
        $BootTime = "UNKNOWN"
    }


    $ReturnObject = [PSCustomObject]@{
        OSVersion = $OSVersion
        BootTime = $BootTime
    }    return $ReturnObject
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function IsAdmin() {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Abort if user does not have local admin rights for certain functions
if (!(IsAdmin)) { Write-Warning "This script requires admin privileges!  Please elevate and re-run the script."; exit }

$StartTime = Get-Date


if ($Computer) { 

    cls

    $Computer = $Computer.ToUpper()

    Write-Host "`nChecking to see if Computer [$Computer] is online -- " -NoNewline

    $ComputerStatus = Get-OnlineStatus $Computer

    if ($ComputerStatus.OnlineStatus -ne "Yes") {        Write-Host "cannot ping machine (it may be offline)" -ForegroundColor Red
        exit
    }     

    $Subnet = Get-Subnet $Computer
    $SystemInfo = Get-SystemInfo $Computer
    $CurrentOU = Convert-DNtoCN (Get-ADComputer -Filter 'Name -like $Computer').DistinguishedName


    $RemotePC = [PSCustomObject]@{
        HostName = $ComputerStatus.DNSHostName
        IPAddress = $ComputerStatus.IPAddress
        Subnet = if ($Subnet) {$Subnet} else {"UNKNOWN"}
        OSVersion= $SystemInfo.OSVersion
        CurrentOU = $CurrentOU
        BootTime = $SystemInfo.BootTime
    }


    Write-Host "`n`nComputer [$Computer] is online and reporting this information:"
    $RemotePC


    # Get free / used / total disk space information
    $DiskSpace = Get-DiskSpaceInfo $Computer
    if ([bool]$DiskSpace) {
        $DiskSpace | select "*Space" 
    } else {
        Write-Host "Unable to retrieve Free/Used/Total Disk Space information" -ForegroundColor Red
    }



    $UserProfileTable = @()
    $UserProfileList = Get-CimInstance -Class Win32_UserProfile -Computer $Computer -ErrorAction SilentlyContinue
    Write-Host "`nNumber of user profiles reported found on [$Computer]: $($UserProfileList.Count)`n"


    foreach ($UserProfile in $UserProfileList) {

        $Index = [array]::IndexOf($UserProfileList, $UserProfile) + 1
        $PercentComplete = [int32](($Index / $($UserProfileList.Count)) * 100)

        # Get user name and SID
        try {
            $UserProfileSID = New-Object System.Security.Principal.SecurityIdentifier($UserProfile.sid)
            $UserPrincipal = $UserProfileSID.Translate([System.Security.Principal.NTAccount])
            $Username = $UserPrincipal.value
        } catch {
    		$Username = $UserProfile.sid
        }


        Write-Progress -Activity "$($Username.ToUpper()) : $Index out of $($UserProfileList.Count)" -Status "$PercentComplete% complete" -PercentComplete $PercentComplete


        # FOR DEBUGGING -- skip domain accounts to speed up the script
        ###if ($Username -like "*NYUMC*") { continue }


        # Determine status for each profile
        switch ($UserProfile.status){
            1 { $ProfileType="Temporary" }
            2 { $ProfileType="Roaming" }
            4 { $ProfileType="Mandatory" }
            8 { $ProfileType="Corrupted" }
            default { $ProfileType = "LOCAL" }
        }


        # Get AD user attributes linked to the profile
        if ($Username -like "NYUMC\*") {
            $DomainAccountName = $Username -replace "NYUMC\\",""
            $ADUser = Get-ADUser -Identity $DomainAccountName -Properties Created,Displayname,Enabled,LastLogonDate,SamAccountName,SID,PasswordLastSet -ErrorAction SilentlyContinue
        } else {
            $ADUser = $False
        }


        # Determine size of the profile path (use SMB share instead of Get-ChildItem -Force to avoid ReparsePoint / Junction bug)    
        $ProfilePath = $UserProfile.LocalPath.ToLower()
        $UNCPath = $ProfilePath -replace "c:\\","\\$Computer\c$\"
        if ($ShowProgress) { Write-Host "   - Getting profile size for [$Username]: " -NoNewline }

        if (Test-Path -Path $UNCPath -ErrorAction SilentlyContinue) {

            $Output = "\\$Computer\c$\temp\profilepath-$($UserProfile.sid).txt"

            $cmd = 'cmd.exe /c dir "{0}" /s /a-l /-c' -f $UNCPath
            Invoke-Expression $cmd -ErrorAction SilentlyContinue | Out-File -FilePath $Output -Force

            $Size = (Get-Content -Path $Output -Tail 2 | Select-Object -First 1).Split(" ",[StringSplitOptions]'RemoveEmptyEntries')[2]

            Remove-Item -Path $Output -Force

            $ProfileFolderSize = [math]::Round(([long]$Size) / 1GB, 2)
            if ($ShowProgress) { Write-Host "$ProfileFolderSize GB" }

        } else {

            $ProfileFolderSize = $Null
            if ($ShowProgress) { Write-Host "path not found [$ProfilePath]" -ForegroundColor Red }

        }


        # Build the object 
        $UserProfileProps = [ordered]@{
            ProfileName = $Username
            ### ProfileSID = $UserProfileSID
            ProfilePath = if ($ProfileFolderSize -ne $Null) { $ProfilePath } else { "NOT FOUND" }
            ### ProfileType = $ProfileType
            ProfileIsinUse = $UserProfile.loaded
            ProfileIsSystemAccount = $UserProfile.special
            ProfileLastUseTime = $UserProfile.lastusetime
            ProfileSize = if ($ProfileFolderSize -ne $Null) { "{0,8:N2} GB" -f $ProfileFolderSize } else { "{0,11}" -f "N/A" }
            "Domain Username" = $ADUser.Displayname
            KerberosID = $ADUser.SamAccountName
            ### "Domain UserSID" = $ADUser.SID
            "Active Account" = $ADUser.Enabled 
            "Last Domain Logon" = $ADUser.LastLogonDate
        }

        $UserProfileTable += New-Object -TypeName PSObject -Property $UserProfileProps
    }
  
    Write-Progress -Activity "$($Username.ToUpper()) : $Index out of $($UserProfileList.Count)" -Status "Completed" -Completed

    $UserProfileTable | ft * -AutoSize
 } else {

    Write-Host "`nUsage: $ScriptName -Computer <computername>"

}


$StopTime = Get-Date
$Duration = $StopTime - $StartTime
"`nScript executed in [{0}] minutes [{1}] seconds" -f $Duration.Minutes, $Duration.Seconds
