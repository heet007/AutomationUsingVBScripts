﻿#==========================================================================================================================================# Program	: XSCAN.PS1# Version	: 1.7.0# Date		: Sep 20 2019# Author	: Roland Thomas# Team		: MCIT / End User Device Engineering## This script will determine if a machine or group of machines are pingable and report back specific information.  ## The machine can also be force-rebooted.## If the machine is pingable, it can capture the AD OU, IP Address, DNS name and current user who is logged in.## It can also report the lastboottime with the "-CHECKBOOTTIME" switch## It can also retrieve specific registry information using the "-CHECKREGISTRY" switch (script needs to be customized for each data to be captured)## Finally the data can be exported to an Excel spreadsheet with the "-REPORT" switch.  The report is saved to C:\TEMP### Usage     : XSCAN.PS1 <machinespec> [-CheckBootTime] [-GetComputerGroups] [-GetUserGroups] [-ADOnly] [-CheckRegistry] [-CheckOSUpdateReady] [-GetAppEvents <eventid>] [-GetSecurityEvents <eventid>] [-GetSystemEvents <eventid>] [-Report] [-SortbyOU]#             XSCAN.PS1 <machinename> [-RDP]#             XSCAN.PS1 <machinespec> [-ForceReboot] (note that the [-OUPath] switch is explicitly forbidden with [-ForceReboot])#             where <machinespec> is one of#                   MachineName#                   MachineNameswithWildCards*#                   [-List] <MachineNames.txt> or <MachineNames.csv>#                   [-Groupname] DomainGroupName#                   [-OUPath] CanonicalPath]## 02-21-17 (v1.0.0): First release# 10-04-17 (v1.1.0): Added support for domain groups and canonical OUs# 10-22-17 (v1.1.1): Added -RDP switch# 11-11-17 (v1.1.2): Added -GETCOMPUTERGROUPS and -GETUSERGROUPS switches, removed -LASTUSERINFO switch# 04-01-18 (v1.1.3): Added -CHECKOSUPDATEREADY switch# 06-01-18 (v1.2.0): Reworked the method to identify the FQDN - use the GetHostEntry method of the SYSTEM.NET.DNS Class# 08-09-18 (v1.3.0): Added -GETAPPEVENTS, -GETSECURITYEVENTS and -GETSYSTEMEVENTS switches to get these events remotely
#                    Added functions to perform LDAP queries on User, Computer, Group and OU objects
#                    Reworked parsing of command line parameters that pipeline the computers (-NAME, -LIST, -GROUP, -OUPATH)
#                    Reworked logic handling forced reboot function
#                    Added custom ping function that is much faster than Powershell native TEST-CONNECTION cmdlet
# 09-19-18 (v1.4.0): Added -GETAPPVERSION switch
# 02-24-19 (v1.4.1): Modified function to identify current user by looking at process loaded by Shell (default is EXPLORER.EXE
#                    but it is whatever is defined by 'Shell' value under HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon)
# 03-15-19 (v1.5.0): Added -TASKACTION and -TASKNAME switches to handle enabling/disabling of scheduled tasks
# 06-15-19 (v1.6.0): Modified LDAP query routines to use the "svc_CompObj" service account for authentication 1and binding
# 09-20-19 (v1.7.0): Added -GETWINDOWSUPDATES switch to get history of Windows Update patches and in-place OS Upgrades (if running Windows 10)
# PLANNED  (v2.0.0): Rewrite to make it more readable and refactor to accept pipeline workflow as parallel job#Requires -Version 3.0### Requires -RunAsAdministrator[cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]param(    [switch]$DevTest = $False,    [string[]]$List = $Null,    [string]$Group = $Null,    [string]$OUPath = $Null,    [string]$LocalUsername = "mcitadmin",    [string]$LocalPassword = $Null,    [switch]$CheckBootTime = $False,    [switch]$ForceReboot = $False,    [switch]$Report = $False,    [switch]$SortbyOU = $False,    [switch]$CheckRegistry = $False,    [switch]$ADOnly = $False,    [switch]$GetAppVersion = $False,    [switch]$GetComputerGroups = $False,    [switch]$GetUserGroups = $False,    [switch]$GetWindowsUpdates = $False,    [switch]$RDP = $False,    [switch]$CheckOSUpdateReady = $False,    [switch]$Override = $False,    [ValidateSet('Check','Enable','Disable','Delete')][string]$TaskAction = $Null,    [string]$TaskName = $Null,    [string]$GetAppEvents = $Null,    [string]$GetSecurityEvents = $Null,    [string]$GetSystemEvents = $Null,    [ValidateSet('DisableReboot','EnableReboot')][string]$Special = $Null)# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------Import-Module ActiveDirectory#Initialize general-purpose variables
$Domain = $env:USERDOMAIN 
$Computername = $($env:COMPUTERNAME).ToUpper()
$ExitonError = $True
$NoExitonError = $False
$Today = Get-Date -Format "yyyyMMdd-HHmmss"
#Initialize script-specific variables$ScriptVersion="2019-09-20 (v1.7.0)"
$ScriptName = $MyInvocation.MyCommand.Name.ToUpper() -replace ".PS1",""
$OutputFolder = "c:\temp"
$ReportFolder = "\\shares.nyumc.org\eude\reports"
$PasswordFile = "\\nyumc.org\NETLOGON\Win7\Computer\Rename-NYUMCDomainComputer.pwd"
# Set global script preferences
if ($DevTest) {
    $ErrorActionPreference = "Stop"
    $VerbosePreference = "Continue"
    ### $VerbosePreference = "Continue"
    try { Stop-Transcript -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | Out-Null }
    catch {}
    ### Set-PSDebug -Trace 2
    ### Set-TraceSource
    Start-Transcript -Path "C:\TEMP\_TRANSCRIPT-$ScriptName-$ComputerName.log" -Force -IncludeInvocationHeader
} else {
    $ErrorActionPreference = "SilentlyContinue"
    $VerbosePreference = "SilentlyContinue"
    $WarningPreference = "SilentlyContinue"
    Set-PSDebug -Off
}
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Config-ScheduledTask ($Computer, $Action, $Name) {

    try {        $TaskObject = Invoke-Command -ComputerName $Computer -ArgumentList $Action, $Name -ErrorAction Stop -ScriptBlock { 

            param ($TaskAction, $TaskName)
            ### Set-PSBreakpoint -Variable Task            $Task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue              If ([bool]$Task) {                switch ($TaskAction) {  # CHECK is an allowed argument but it is implicitly defined as default                    "ENABLE" {                        try { $Task = Enable-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue -Verbose }                        catch { $Error[0] }                    }                    "DISABLE" {                        try { $Task = Disable-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue -Verbose }                        catch { $Error[0] }                    }                     "DELETE" {                        try { $Task = Unregister-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue -Confirm:$False -PassThru -Verbose }                        catch { $Error[0] }                    }                }                if (($Task.State) -is [int]) {
                    $State = switch ($Task.State) {
                        0 {'UNKNOWN'}
                        1 {'DISABLED'}
                        2 {'QUEUED'}
                        3 {'READY'}
                        4 {'RUNNING'}
                        Default {'UNKNOWN'}
                    }                } else {                                        $State = "$($Task.State)".ToUpper()                }                $TaskProps = [ordered] @{'Status'=$True; 'Name'=$TaskName; 'State'=$State}
            } else {

                $TaskProps = [ordered] @{'Status'=$True; 'Name'=$TaskName; 'State'="DOES_NOT_EXIST"}    
            }

            return $TaskProps
        }    
    }    catch {        $TaskObject = [ordered] @{'Status'=$False; 'Name'=$TaskName; 'State'="CANNOT_GET_STATUS"}    }
    $Results = New-Object -TypeName PSObject -Property $TaskObject     #$Results | fl *    #exit    return $Results
}
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-CNtoDN([string]$CanonicalName) {

    # Parsing if an empty string is sent 
    if ([string]::IsNullOrEmpty($CanonicalName)) { return $Null }


    # Split the canonical name into separate bits 
    $Parts = $CanonicalName.Replace("\","/").Split("//")

    foreach ($Part in $Parts) {
        if ($Parts.IndexOf($Part) -eq 0) {
            $DistinguishedName = "DC=nyumc,DC=org"
        } else {
            $DistinguishedName = "OU=$Part," + $DistinguishedName
        }
    }

    return $DistinguishedName

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-DNtoCN([string]$DistinguishedName) {

    # Parsing if an empty string is sent 
    if ([string]::IsNullOrEmpty($DistinguishedName)) { return $Null }


    # Strip off leading LDAP prefix if there is any
    if ($DistinguishedName -like "LDAP://*") { $DistinguishedName = $DistinguishedName -replace "LDAP://","" }


    # Split the distinguished name into separate bits 
    $Parts = $DistinguishedName.Split(",")
 
    foreach ($Part in $Parts) {
        if ($Part -like "OU=*") {
            $Subpart = $Part -replace "OU=",""
            $CanonicalName = "/$Subpart" + $CanonicalName
        }

    }

    $CanonicalName = "nyumc.org" + $CanonicalName

    return $CanonicalName

}
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Convert-CSVtoXLSX($ReportFile) {

    $ReportFile_XLSX = $ReportFile -replace "csv", "xlsx"

    $Excel = New-Object -ComObject Excel.Application
    $Excel.Visible = $False                                 # Set to $true if you want actually see the script interact with Excel
    $Excel.DisplayAlerts = $False

    $WorkBook = $Excel.Workbooks.Open($ReportFile)
 
    #$WorkSheet = $WorkBook.Worksheets.Item(1)

    $Excel.Rows.Item(1).Font.Bold = $True
    $Excel.Rows.Item(1).Font.Underline = $True

    [void]$Excel.Cells.EntireColumn.AutoFilter()
    $Excel.Columns.Borders.LineStyle = 1 
    [void]$Excel.Cells.EntireColumn.AutoFit()

    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.Orientation = 2             # Set to Landscape mode
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.FitToPagesWide = 1          # Fit all columns
    $Excel.ActiveWorkbook.ActiveSheet.PageSetup.FitToPagesTall = $False     # to one page

    $WorkBook.SaveAs($ReportFile_XLSX, 51)

    $Excel.Quit()

    Remove-Variable -Name Excel

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Convert-XLSXtoCSV($ReportFile) {

    $ReportFile_CSV = $ReportFile -replace "xlsx", "csv"

    $Excel = New-Object -ComObject Excel.Application
    $Excel.Visible = $False
    $Excel.DisplayAlerts = $False

    $WorkBook = $Excel.Workbooks.Open($ReportFile)

    $Workbook.SaveAs($ReportFile_CSV, 6)

    $WorkBook.Close()
    $Excel.Quit()

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Error-Handler([string]$ErrorMessage, [boolean]$_ExitonError) {
    Write-Host -ForegroundColor Red "`r`n$($Script:ScriptName): $ErrorMessage"
    ### Write-Log $ErrorMessage

    if ($_.Exception.Message -ne $null) {
        Write-Host -ForegroundColor Red "`r`nSystem error message was:" $_.Exception.Message
        ### Write-Log $_.Exception.Message
     }

    if ($_ExitonError) { exit }
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-AppVersion ($Machine, $ServiceName, $ExePath) {

    $Service = Get-Service -ComputerName $Machine -Name $ServiceName -ErrorAction SilentlyContinue

    if ($Service.Status -eq "Running") {

        $UNC_ExePath = $ExePath -replace "C:\\", "\\$Machine\C$\"
        $TestPath = "filesystem::$UNC_ExePath"

        $ExePath
        $UNC_ExePath
        $TestPath
        #exit

        if (Test-Path $UNC_ExePath -ErrorAction SilentlyContinue) {
        #if ([bool](Get-ChildItem -Path $TestPath -Force -ErrorAction SilentlyContinue)) {

            $FileVersion = (Get-Command $UNC_ExePath -ErrorAction SilentlyContinue).FileVersionInfo.FileVersion
            $FileVersion
            exit
            if ([bool]$FileVersion) { return $FileVersion }
        } 

    }

    return "UNKNOWN"  # fall through if process is not 'Running' status or unable to get file version of executable

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-CurrentRemoteUser ($Machine) {

    try {

        ### $ProcessName = "explorer.exe"
        ### $ProcessName = "kiosk.exe"
        $ShellName = Invoke-Command -ComputerName $Machine -ScriptBlock { (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -Name "Shell" -ErrorAction SilentlyContinue -Verbose)."Shell" }
        $ProcessName = (Split-Path -Path $ShellName -Leaf) -replace """",""

        ### $Process = Get-WmiObject -Class Win32_Process -ComputerName $Machine -Filter "Name='$Processname'" -Property * -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
        ### $Process = Get-WmiCustom -Class "Win32_Process" -ComputerName $Machine -Namespace "root\cimv2" -Timeout 15 | ? { $_.ProcessName -eq "$ProcessName" }
        $Process = Get-CimInstance -Namespace "root\cimv2" -Class Win32_Process -ComputerName $Machine -OperationTimeoutSec 30 -Filter "Name='$ProcessName'" -Property * -ErrorAction SilentlyContinue -WarningAction SilentlyContinue

        ### $ShellName, $ProcessName, $Process | fl *
        ### Write-Host "$Machine`t`t: $Process"
        ### exit

        if (!([bool]$Process)) {

            $CurrentUser, $CurrentUserSID = "NO_CURRENT_LOGON"

        } else {

            # If there is more than one user logged in, the first listed process should be the user running the script
            $CurrentProcess = $Process | Sort -Property CreationDate -Descending | select -First 1

            $Process_OwnerInfo = Invoke-CimMethod -InputObject $CurrentProcess -MethodName GetOwner
            $Process_OwnerSIDInfo = Invoke-CimMethod -InputObject $CurrentProcess -MethodName GetOwnerSID

            $CurrentUserDomain = ($Process_OwnerInfo.Domain).ToUpper()
            $CurrentUserName = ($Process_OwnerInfo.User).ToUpper()
            $CurrentUser = $CurrentUserDomain + "\" + $CurrentUserName

            $CurrentUserSID = ($Process_OwnerSIDInfo.SID).ToUpper()

        }

    }

    catch {

        $CurrentUser, $CurrentUserSID = "UNKNOWN"

    }

    return $CurrentUser, $CurrentUserSID
}# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-DiskSpace ($Machine) {    $DiskSpace = Invoke-Command -ComputerName $Machine -ScriptBlock {

        $FreeDiskSpace = [math]::Round((Get-PSDrive -Name C).Free / 1GB)
        $UsedDiskSpace = [math]::Round((Get-PSDrive -Name C).Used / 1GB)
        $TotalDiskSpace = $FreeDiskSpace + $UsedDiskSpace

        return [PSCustomObject]@{
            Free = $FreeDiskSpace
            Used = $UsedDiskSpace
            Total = $TotalDiskSpace
        }

    }

    return $DiskSpace
}# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-DomainStatus($Machine, $Credential) {
    try {
        $Result = Invoke-Command -ComputerName $Machine -Credential $Credential -ScriptBlock { "Test-ComputerSecureChannel -Credential $Credential -ErrorAction SilentlyContinue" }
    }
    catch { 
        $Result = $False
    }

    return $Result

}
 
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-LocalCredential ($Machine, $LocalUsername, $LocalPassword) {

    $LocalUsername = $LocalUsername.ToLower()

    if ($LocalUsername -ne "mcitadmin") {
                
        if (!$LocalPassword) {
            Error-Handler "Password missing for local admin username [$LocalUsername].  Please supply with -LocalPassword switch." $ExitonError
        }

    } else {

        $PPath = "\\nyumc.org\SYSVOL\nyumc.org\scripts\users"
        . "$PPath\encrypt.ps1"  # dot-source this script to include the encrypt/decrypt functions
        $Encrypted = Get-Content "$PPath\duserp.txt"
        $Passphrase = Get-Content "$PPath\phrasep.txt"
        $LocalPassword = Decrypt-String -Encrypted $Encrypted -Passphrase $Passphrase

    }
 
    $LocalAdminAccount = "$Machine\$LocalUsername"
    $SecurePassword = $LocalPassword | ConvertTo-SecureString -AsPlainText -Force
    $LocalCredential = New-Object System.Management.Automation.PsCredential($LocalAdminAccount, $SecurePassword)

    <#
    $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($LocalCredential.Password)
    $UnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
    Write-host "LocaAdminUsername = $($LocalCredential.Username); LocalPassword = $UnsecurePassword"
    #exit
    #>

    return $LocalCredential

}
 # ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-OnlineStatus($Machine) {    $PingStatus = Test-Connection -ComputerName $Machine -Count 1 -Quiet    if ($PingStatus) {    ### $PingStatus = Ping-Computer -ComputerName $Machine    ### if ($PingStatus.Online) {        $Machine_IPAddress = (Test-Connection -ComputerName $Machine -Count 1).IPV4Address.IPAddressToString        $FQDN_Machine = ([System.Net.Dns]::GetHostEntry($Machine)).Hostname        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "Yes"
            DNSHostName = $FQDN_Machine
            IPAddress = $Machine_IPAddress
        }

    } else {        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "No"
            DNSHostName = "OFFLINE"
            IPAddress = "OFFLINE"
        }
    }    return $ReturnObject}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-OSVersion ($OSName, $OSBuild) {

    if ($OSName -like "*Windows 7*") {

        $OSEdition = $OSName -replace "Windows 7","Win7"
        $OSVersion = "$OSEdition $OSBuild"    } else {        $OSEdition = $OSName -replace "Windows 10","Win10"        switch -Wildcard ($OSBuild) {            "*10240*" { $Win10_Version = "ver 1507 RTM" }
            "*10586*" { $Win10_Version = "ver 1511" }
            "*14393*" { $Win10_Version = "ver 1607" }
            "*15063*" { $Win10_Version = "ver 1703" }
            "*16299*" { $Win10_Version = "ver 1709" }
            "*17134*" { $Win10_Version = "ver 1803" }
            "*17763*" { $Win10_Version = "ver 1809" }
            "*18362*" { $Win10_Version = "ver 1903" }            "*18363*" { $Win10_Version = "ver 1909" }            "*19041*" { $Win10_Version = "ver 2004" }            default { $Win10_Version = "ver UNKNOWN" }        }        $OSVersion = "$OSEdition ($Win10_Version - build $OSBuild)"
    }    return $OSVersion}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Convert-OSBuildNumber ($OSBuild) {

    switch -Wildcard ($OSBuild) {
        "*10240*" { $OSVersion = "1507 RTM" }
        "*10586*" { $OSVersion = "1511" }
        "*14393*" { $OSVersion = "1607" }
        "*15063*" { $OSVersion = "1703" }
        "*16299*" { $OSVersion = "1709" }
        "*17134*" { $OSVersion = "1803" }
        "*17763*" { $OSVersion = "1809" }
        "*18362*" { $Win10_Version = "ver 1903" }        "*18363*" { $Win10_Version = "ver 1909" }        "*19041*" { $Win10_Version = "ver 2004" }        default { $OSVersion = "UNKNOWN" }    }    return $OSVersion

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-OSVersion-NEW {

    $OSInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem -ErrorAction SilentlyContinue

    if ([bool]$OSInfo) {

        $OSLongName = $OSInfo.Caption -replace "Microsoft ",""
        $OSBuild = $OSInfo.Version

        if ($OSLongName -like "*Windows 7*") {

            $OSShortName = $OSLongName -replace "Windows 7","Win7"
            $OSFullName = "$OSLongName $OSBuild"        } else {            $OSVersion = Convert-OSBuildNumber $OSBuild
            $OSShortName = $OSLongName -replace "Windows 10","Win10"            $OSFullName = "$OSLongName (ver $OSVersion - build $OSBuild)"
        }    } else {        $OSLongName = $OSShortName = $OSBuild = $OSVersion = $OSFullName = "UNKNOWN"
    }    $OSVersionObject = [PSCustomObject]@{
        OSLongName = $OSLongName
        OSShortName = $OSShortName
        OSBuild = $OSBuild
        OSVersion = $OSVersion
        OSFullName = $OSFullName
    }


    return $OSVersionObject

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-RemoteEventLog ($Machine, $EventID, $EventLogname, $Credential) {

    <#

    Event Logname: SECURITY

    4608 (Startup)
    4609 (Shutdown)
    4624 (An account was successfully logged on)
    4634 (User completed logoff)
    4647 (User initiated logoff)
    4778 (A RDP session was reconnected to a Window station)
    4779 (A RDP session was disconnected from a Window Station)
    4800 (The workstation was locked)
    4801 (The workstation was unlocked)
    4802 (Screensaver invoked)
    4803 (Screensaver dismissed)


    Event Logname: SYSTEM - 12,41,1074,6008,6009

    12 ("The operating system started at system time: X")
    41 ("The system has rebooted without cleanly shutting down first. This error could be caused if the system stopped responding, crashed, or lost power unexpectedly." - Source: "Kernel-Power")
    1074 ("The process X has initiated the restart / shutdown of computer on behalf of user Y for the following reason: Z.")
    6005 (System startup, "The Event log service was started")
    6006 (System shutdown normal, "The Event log service was stopped")
    6008 (System shutdown abend, "The previous system shutdown was unexpected")
    6009 (System startup, "The user restarted or shut down the computer by clicking Start or pressing CTRL+ALT+DELETE, and then clicking Shut Down." The message displays thr Windows product name, version, build number, service pack number, and operating system type detected at boot time.)

    #>


    $Events = Get-EventLog -ComputerName $Machine -LogName $EventLogname  | ? { $_.EventID -eq $EventID } | Select MachineName, EntryType, TimeGenerated, Source, EventID, Message |ft * -HideTableHeaders -Wrap

    ### $Events = Invoke-Command -ComputerName $Machine -Credential $Credential -ScriptBlock { Get-EventLog -ComputerName $Machine -LogName System  | ? { $_.EventID -eq $EventID } | Select MachineName, EntryType, TimeGenerated, Source, EventID, Message }
    ### Invoke-Command -ComputerName $Machine -Credential $Credential -ScriptBlock { Get-ScheduledTask | Get-ScheduledTaskInfo | Sort LastRunTime -Descending } | ft TaskName,TaskPath,LastRunTime,LastTaskResult } | Out-File c:\temp\$Machine-scheduled-tasks.log -Force


    if ([bool]$Events) {
        return $Events
    } else {
        return $False
    }

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-RemoteRegValue($Computer, $Path, $Name) {

    $Subkey = ($Path -split ":\\")[1]

    switch -wildcard ($Path) {
        "HKU*"  { $RegObject = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey("User", $Computer) }
        "HKCU*" { $RegObject = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey("CurrentUser", $Computer) }
        "HKLM*" { $RegObject = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey("LocalMachine", $Computer) }
    }

    $RegKey = $RegObject.OpenSubKey($Subkey)

    $RegValue = $RegKey.GetValue($Name, $Null, "DoNotExpandEnvironmentNames")

    return $RegValue

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-RemoteRegistryTable($RegistryTable) {

    foreach ($RegistryItem in $RegistryTable) {
        $Found = Get-RemoteRegValue $RegistryItem[0] $RegistryItem[1] $RegistryItem[2]
    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-Subnet($Machine, $Credential) {

    try {
        ### $NetworkAdapters = Get-WmiObject -Namespace "root\cimv2" -Class Win32_NetworkAdapterConfiguration -ComputerName $Machine -Impersonation Impersonate -Authentication PacketPrivacy -Credential $Credential -ErrorAction Stop | ? {($_.IPEnabled -eq "True") -and ($_.DefaultIPGateway -ne $Null)}
        ### $NetworkAdapters = Get-WmiObject -Class Win32_NetworkAdapterConfiguration -ComputerName $Machine | ? {($_.IPEnabled -eq "True") -and ($_.DefaultIPGateway -ne $Null)}
        $NetworkAdapters = Get-CimInstance -Namespace "root\cimv2" -Class Win32_NetworkAdapterConfiguration -ComputerName $Machine -OperationTimeoutSec 30 -Property * -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | ? {($_.IPEnabled -eq "True") -and ($_.DefaultIPGateway -ne $Null)}

        $NetworkAdapters | % {
 
           # Compute the Subnet (Network ID) from the IP Address and Subnet Mask
           $IPAddress = @($_.IPAddress)[0]
           $IPAddress_Octets = $IPAddress -split "\."              # Split up IP Address into array of 4 octets
           $SubnetMask_Octets = @($_.IPSubnet)[0] -split "\."      # Do the same for the subnet mask
           $Subnet_Octets = @{}                                    # Initialize hashtable for the subnet

           for ($i=0; $i -le 3; $i++) {                            # Do binary-and on all octets
               [int32]$Subnet_Octets[$i] = [int32]$IPAddress_Octets[$i] -band [int32]$SubnetMask_Octets[$i]
               $Subnet_NetworkID += ($Subnet_Octets[$i]).ToString() + "."  # Concatenate the result back into dotted-notation
           }

           $Subnet_NetworkID = $Subnet_NetworkID -replace ".$"             # Strip off last dot (artifact of last command)

        }

    }

   catch { $Subnet_NetworkID = "OFFLINE" }

   return $Subnet_NetworkID

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SystemInfo ($Machine, $Credential) {

    try {
        $OSInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem -ComputerName $Machine  ### -Impersonation Impersonate -Authentication PacketPrivacy -Credential $Credential -ErrorAction SilentlyContinue        ### $OSInfo = Get-CimInstance -Namespace "root\cimv2" -Class Win32_OperatingSystem -ComputerName $Machine -OperationTimeoutSec 30 -ErrorAction SilentlyContinue -WarningAction SilentlyContinue    }    catch {        $OSInfo = $False        Error-Handler "Unable to query WMI Win32_OperatingSystem class on [$Machine] with account [$($Credential.Username)]" $NoExitonError
        ### Error-Handler "Unable to query WMI Win32_OperatingSystem class on [$Machine]" $NoExitonError
    }    if ($OSInfo) {        # Get last boot tiime        $LastBootTime = $OSInfo.ConvertToDateTime($OSInfo.LastBootUpTime)  # Use this if enumerating with GET-WMIOBJECT        ### $LastBootTime = $OSInfo.LastBootUpTime    # Use this if enumerating with GET-CIMINSTANCE        if ($LastBootTime -eq $Null) { $LastBootTime = "UNKNOWN" }
        # Get OS Version
        $OSName = $OSInfo.Caption -replace "Microsoft ",""        if ($OSName -like "*Windows 7*") {

            $OSVersion = Get-OSVersion $OSName $OSInfo.CSDVersion        } else {            $OSVersion = Get-OSVersion $OSName $OSInfo.Version        }

    } else {

        $OSVersion = "UNKNOWN"
        $LastBootTime = "UNKNOWN"
    }


    $ReturnObject = [PSCustomObject]@{
        OSVersion = $OSVersion
        LastBootTime = $LastBootTime
    }    return $ReturnObject
}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-TimeDifference([DateTime]$Start, [DateTime]$End) {
    [TimeSpan]$Diff = $End - $Start

    $Result = ""

    if ($Diff.Ticks -gt 0) {

        $Hours = $Diff.Hours
        $Mins = $Diff.Minutes
        $Secs = $Diff.Seconds
        $Millisecs = $Diff.Milliseconds

        if ($Hours -gt 0) { $Result +=  "${Hours} hours"  }
        if ($Mins -gt 0 ) { $Result +=  " ${Mins} minutes" }
        if ($Secs -gt 0 ) { $Result +=  " ${Secs} seconds" }
        if ($Millisecs -gt 0) { $Result +=  " ${Millisecs} milliseconds" }

    } else {

        $Result = "less than 1 second"

    }
    
    return $Result
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-TimeStamp {
    $timestamp = "[" + (Get-Date).ToShortDateString() + " " + (Get-Date).ToShortTimeString() + "]:"
    return $timestamp
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------Function Get-WmiCustom([string]$Class,[string]$ComputerName,[string]$Namespace = "root\cimv2",[int]$Timeout=15, [pscredential]$Credential) {

    $ConnectionOptions = New-Object System.Management.ConnectionOptions
    $EnumerationOptions = New-Object System.Management.EnumerationOptions

    if($Credential){
        $ConnectionOptions.Username = $Credential.UserName;
        $ConnectionOptions.SecurePassword = $Credential.Password;
    }


    $timeoutseconds = New-TimeSpan -Seconds $timeout 
    $EnumerationOptions.set_timeout($timeoutseconds)

    $assembledpath = "\\$Computername\$Namespace"
    #write-host $assembledpath -foregroundcolor yellow

    $Scope = New-Object System.Management.ManagementScope $assembledpath, $ConnectionOptions 
    $Scope.Connect()

    $querystring = "SELECT * FROM " + $class 
    #write-host $querystring

    $query = New-Object System.Management.ObjectQuery $querystring 
    $searcher = New-Object System.Management.ManagementObjectSearcher 
    $searcher.set_options($EnumerationOptions) 
    $searcher.Query = $querystring 
    $searcher.Scope = $Scope

    trap { $_ } $result = $searcher.get()

    return $result 
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-WUHistory ($Machine) {    $ReportFile = "C:\Temp\WindowsUpdate_History-$Machine.txt"
    if (Test-Path $ReportFile) { Remove-Item $ReportFile -Force -ErrorAction SilentlyContinue }


    # Get Windows 10 OS Upgrade history
    "`n*** Windows 10 In-Place OS Upgrade History for: $Machine ***" | Out-File -FilePath $ReportFile -Append

    $Result = Invoke-Command -ComputerName $Machine -ErrorAction SilentlyContinue -ScriptBlock {

        $Upgrades = Get-ChildItem -Path "HKLM:\System\Setup"  | ? {$_.Name -like "*Source OS*"} | 
             % { $_ | Select @{n="ProductName";e={$_.GetValue("ProductName")}},
                                @{n="Version";e={$_.GetValue("ReleaseID")}},
                                @{n="CurrentBuild";e={$_.GetValue("CurrentBuild")}},
                                @{n="UpdateTime";e={if ($_.Name -match "Updated\son\s(\d{1,2}\/\d{1,2}\/\d{4}\s\d{2}:\d{2}:\d{2})\)$") {[dateTime]::Parse($Matches[1],([Globalization.CultureInfo]::CreateSpecificCulture('en-US')))}}
                }
        
        }

        return $Upgrades

    } 
    
    if ($Result.length -eq 0) {
        "No history found!" | Out-File -FilePath $ReportFile -Append
    } else {
        $Result | Sort UpdateTime | ft PSComputerName, ProductName, Version, CurrentBuild, UpdateTime | Out-File -FilePath $ReportFile -Append -Width 250
    }



    # Get Windows Update patch history
    "`n*** Windows Hotfix Update History for: $Machine ***" | Out-File -FilePath $ReportFile -Append

    $Result = Invoke-Command -ComputerName $Machine -ErrorAction SilentlyContinue -ScriptBlock {

        $Upgrades = Get-WinEvent -FilterHashtable @{LogName = 'System'; ID='19'}

        return $Upgrades

    }

    if ($Result.length -eq 0) {
        "No history found!" | Out-File -FilePath $ReportFile -Append
    } else {    
        $Result | ft PSComputerName, TimeCreated, Message | Out-File -FilePath $ReportFile -Append -Width 250
    }


    return $ReportFile
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-YesNoAnswer ([string]$PromptMessage) {

    do {

        $Prompt = (Read-Host "`n$PromptMessage [Y / N] ").ToUpper()

    } while($Prompt -notmatch "[YN]")

    return $Prompt
}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function IsAdmin() {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------Function Ping-Computer {
	[CmdletBinding()]
	param
	(
		[Parameter(Mandatory=$True,
		ValueFromPipeline=$True, ValueFromPipelinebyPropertyName=$true)]
		[alias("CN","MachineName","Device Name")]
		[string]$ComputerName	
	)

	Begin {
		[int]$timeout = 20
		[switch]$resolve = $true
		[int]$TTL = 128
		[switch]$DontFragment = $false
		[int]$buffersize = 32
		$options = New-Object system.net.networkinformation.pingoptions
		$options.TTL = $TTL
		$options.DontFragment = $DontFragment
		$buffer=([system.text.encoding]::ASCII).getbytes("a"*$buffersize)	
	}

	Process {
        $ping = New-Object System.Net.NetworkInformation.Ping
		try {
			$reply = $ping.Send($ComputerName,$timeout,$buffer,$options)	
		}
		catch {
			$ErrorMessage = $_.Exception.Message
		}

		if ($reply.status -eq "Success") {
			$props = @{ComputerName=$ComputerName
					    Online=$True
			}
		} else {
			$props = @{ComputerName=$ComputerName
						Online=$False			
			}
		}

		New-Object -TypeName PSObject -Property $props

	}

	End {}
}# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function QueryLDAP-ADObject ($Filter, $Category, $Credential = $Script:DomainCredential) {

    switch ($Category) {
        "User" { $SearchFilter = "(&(objectCategory=User)(samAccountName=$Filter))" }

        "Group" { $SearchFilter = "(&(objectCategory=Group)(samAccountName=$Filter))" }

        "Computer" { 
            #if ($Filter -match '\*') {            #    $SearchFilter = "(&(objectCategory=Computer)(samAccountName=$Filter)" 
            #} else {
                $SearchFilter = "(&(objectCategory=Computer)(samAccountName=$Filter$))"  # SAM Name requires terminating '$' for a computer
            #}
        }

        "OU" { $SearchFilter = "(&(objectCategory=OrganizationalUnit)(name=$Filter))" }

        default { return $False }
    }


    # Decrypt the password, it must be passed as cleartext to the 'JoinDomainorWorkgroup' and 'UnjoinDomainorWorkgroup' methods
    $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($Credential.Password)
    $UnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)


    $SearchRoot = "LDAP://DC=nyumc,DC=org"
    $SearchPath = New-Object System.DirectoryServices.DirectoryEntry 
    ### $SearchPath = New-Object System.DirectoryServices.DirectoryEntry ($SearchRoot, $Credential.Username, $UnsecurePassword)
    $Searcher = New-Object System.DirectoryServices.DirectorySearcher

    $Searcher.SearchRoot = $SearchPath
    $Searcher.PageSize = 10
    ### $Searcher.PropertiesToLoad.Add("Name")
    $Searcher.Filter = $SearchFilter
    $Searcher.SearchScope = "Subtree"

    try {
        if ($Category -eq "Group") {
            $Result = $Searcher.FindAll().GetDirectoryEntry()
        } else {
            if ($Filter -match '\*') {                $Result = ($Searcher.FindAll().GetDirectoryEntry()).Name
            } else {
                $Result = $Searcher.FindOne().GetDirectoryEntry()
            }
        }
    }
    catch { $Result = $False }

    <#
    if ($Result) {
        Write-Host "Resolved Search Filter = $($Searcher.Filter)"
        $Result | fl *
        exit
    } 
    #>
       
    $Searcher.Dispose()

    return $Result

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function QueryLDAP-GroupList ($Filter, $Category) {

    $Result = QueryLDAP-ADObject $Filter $Category

    <#
    $Result | fl *
    exit
    #>


    if ($Result) {

        $CanonicalGroups = $Result.memberof | % { ($_ -split ",")[0] -replace "CN=","" -replace "\\","" } | sort
        $Groups = [string]::Join(", ", $CanonicalGroups)
        if ([string]::IsNullOrEmpty($Groups)) { $Groups = "[NONE_FOUND]" }

    } else {

        $Groups = "[LDAP_QUERY_ERROR]"

    }

    return $Groups

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function QueryLDAP-GroupMembers ($Groupname, $MemberType) {    Write-Host "`nGetting members of group [$Groupname]...`n"    $Result = QueryLDAP-ADObject $Groupname "Group"    if ($Result) {

        switch ($MemberType) {
            "User" { $Members = $Result.member | % { $_ -replace "(CN=)(.*?),.*",'$2' } | ? { QueryLDAP-ADObject $_ "User" } | sort -Unique }
            "Computer" { $Members = $Result.member | % { $_ -replace "(CN=)(.*?),.*",'$2' } | ? { QueryLDAP-ADObject $_ "Computer" } | sort -Unique }
            "All" { $Members = $Result.member | % { $_ -replace "(CN=)(.*?),.*",'$2' } | sort }
            default { return $False }
        }

        return $Members
    } else {        return $False
    }
}# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function QueryLDAP-Computers_in_OU($OUPath) {
    # Convert the CanonicalPath to a DistinguishedPath
    $OUPath_DN = Test-OUPath $OUPath
    
    if ([bool]$OUPath_DN) { 
        
        $Searcher = New-Object System.DirectoryServices.DirectorySearcher

        <#
        $Domain = (New-Object System.DirectoryServices.DirectoryEntry).DistinguishedName # should return DC=nyumc,DC=org
        $DomainPath = "LDAP://$Domain"
        #>

        $DomainPath = "LDAP://$OUPath_DN"
        $Searcher.SearchRoot = New-Object System.DirectoryServices.DirectoryEntry ($DomainPath) ###, $Credential.Username, $UnsecurePassword)
        $Searcher.PageSize = 1000
        $Searcher.PropertiesToLoad.Add("Name")
        $Searcher.Filter = "objectCategory=Computer"
        $Searcher.SearchScope = "OneLevel"
        ### $Searcher.Sort = New-Object System.DirectoryServices.SortOption

        $Computers = $Searcher.FindAll() | % { $_.Properties.name } | sort   # The ".name" attribute is case-sensitive (must remain lowercase)!

        return $Computers

    } else {

        return $False

    }

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Set-RemoteRegValue($Computer, $Path, $Name, $NewValue, $NewValueType) {

    $RegObject = Invoke-Command -ComputerName $Computer -ArgumentList $Path, $Name, $NewValue, $NewValueType -ErrorAction SilentlyContinue -ScriptBlock { 

        param ($RegPath, $RegName, $NewRegValue, $NewRegValueType)
        # Create the registry key if it does not exist
        if (!(Test-Path -Path $RegPath)) {
            New-Item -Path $RegPath -Force
        }

        $CurrentValue = Get-ItemProperty -Path $RegPath -Name $RegName

        if (!([bool]$CurrentValue)) {
            $Results = New-ItemProperty -Path $RegPath -Name $RegName -Value $NewRegValue -PropertyType $NewRegValueType -Force
        } else {
            $Results = Set-ItemProperty -Path $RegPath -Name $RegName -Value $NewRegValue -Force -PassThru
        }

        return $Results
    }}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Delete-RemoteRegValue($Computer, $Path, $Name) {

    $RegObject = Invoke-Command -ComputerName $Computer -ArgumentList $Path, $Name -ErrorAction SilentlyContinue -ScriptBlock { 

        param ($RegPath, $RegName)
        Remove-ItemProperty -Path $RegPath -Name $RegName -Force 
        $CurrentValue = Get-ItemProperty -Path $RegPath -Name $RegName

        if (!([bool]$CurrentValue)) {
            $Results = $True
        } else {
            $Results = $False
        }

        return $Results
    }
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Test-OUPath ($TargetOU) {
    $TargetOU_DN = Convert-CNtoDN $TargetOU

    try { if ([adsi]::Exists("LDAP://$TargetOU_DN")) { return $TargetOU_DN } }
    catch { $Result = $False }
    
}# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Test-WinRM ($Machine, $Credential) {
    $Result = $False

    try {
        $OSInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem -ComputerName $Machine -Impersonation Impersonate -Authentication PacketIntegrity -Credential $Credential -ErrorAction SilentlyContinue        ### $TestWSMan = Test-WSMan -ComputerName $Machine -Credential $Credential -Authentication Kerberos -        ### $TestWSMan | fl *        ### exit        $Result = $True    }    catch [System.UnauthorizedAccessException] {        Error-Handler "Unable to query WMI Win32_OperatingSystem class on [$Machine] with account [$($Credential.Username)]" $NoExitonError

        <#
        Write-Host "CREATING SELF SIGNED CERTIFICATE"
        $Cert = New-SelfSignedCertificate -CertStoreLocation Cert:\LocalMachine\my -DNSName $Machine -NotAfter (Get-Date).AddDays(1) -
        $Cert | fl *
        $Cert | gm *

        Write-Host "CREATING WSMAN LISTENER"
        $WSManConfig = New-Item -Path WSMan:\LocalHost\Listener -Transport HTTPS -Port 5986 -Address * -CertificateThumbPrint $Cert.Thumbprint –Force -Credential
        $WSManConfig | fl *
        $WSManConfig | gm *
        #>

        Write-Host "ADDING TO TRUSTED HOSTS"
        $TrustedHosts = Set-Item WSMan:\LocalHost\Client\TrustedHosts -Value $Machine -Force -PassThru -Credential $Credential
        $TrustedHosts | fl *
        $TrustedHosts | gm *

        #Import-Certificate -Filepath 'C:\temp\cert' -CertStoreLocation 'Cert:\LocalMachine\Root'
 
        # Skip Certification Authority (CA) check
        $SessionOption = New-PsSessionOption –SkipCACheck -SkipCNCheck -SkipRevocationCheck 
        Enable-PSRemoting -SkipNetworkProfileCheck -Force
    
        # Establish a POSH Remoting session
        $Session = New-PSSession -Computername $Machine -Port 5986 -Credential $Credential -UseSSL -SessionOption $SessionOption
        Enter-PSSession -Session $Session

        $OSInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem -ComputerName $Machine -Impersonation Impersonate -Authentication PacketIntegrity -Credential $Credential -ErrorAction SilentlyContinue        $OSinfo = fl *
        exit

    }    catch [Exception] {        Error-Handler "General exception fault" $NoExitonError    }    return $Result}# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Usage {    Write-Host "Usage: $ScriptName <machinespec> [-ForceReboot] [-Report]"    Write-Host "`nwhere <machinespec> is one of"    Write-Host "      [-COMPUTERNAME] MachineName"    Write-Host "      [-LIST MachineNameswithWildCards*]"    Write-Host "      [-LIST <MachineNames.txt>]"    Write-Host "      [-GROUP <DomainGroupName>]"    Write-Host "      [-OUPATH <CanonicalOUPath>]"    exit}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------clear# Abort if no arguments, display usage helpif ($psboundparameters.count -eq 0) { Usage }


# Abort if user does not have local admin rights for certain functions
if ($ForceReboot -and !(IsAdmin)) { Write-Warning "The [-FORCEREBOOT] switch requires admin privileges!  Please elevate and re-run the script."; exit }
#region Enumerate all arguments (both defaults and passed from command line) and save name and value to logfile### Write-Log "`n`n`n`nArguments passed to script:`n"($MyInvocation.MyCommand.Parameters).Keys | sort | % {
    $ArgName = Get-Variable -Name $_ -ErrorAction SilentlyContinue
    $ArgValue = $ArgName.Value
    # if( $ArgValue.length -gt 0 ) {
        if ($ArgValue -is [String]) {
            $ArgName.Value = $ArgValue.ToUpper()
            Set-Variable -Name $ArgName -Value $ArgValue
        }
        ### Write-Warning "$_ = $($ArgName.Value)"
    # }
}
#endregion#region Get service account credentials
try { $ServiceAccount = Import-Clixml $PasswordFile }
catch { Error-Handler "Unable to read password file [$PasswordFile]" $ExitOnError }
try { $ServiceAccountPassword = ConvertTo-SecureString $ServiceAccount.EncryptedPwd -Key $ServiceAccount.Key }
catch { Error-Handler "Unable to convert encrypted password string for account [$($ServiceAccount.Username)]" $ExitOnError }
try { $DomainCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $ServiceAccount.Username,$ServiceAccountPassword }
catch { Error-Handler "Unable to create Credentials object for account [$($ServiceAccount.Username)]" $ExitOnError }

<#
$BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($DomainCredential.Password)
$UnsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
Write-Log "ServiceAccount = $($ServiceAccount.Username); ServiceAccountPassword = $ServiceAccountPassword"
Write-Log "DomainUsername = $($DomainCredential.Username); DomainPassword = $UnsecurePassword"
exit
#>
#endregion


#region Enumerate the list of machines: can be single, array, file, group or OU$WildcardFlag = $Falseswitch ($True) {    (!([string]::IsNullOrEmpty($List))) {         $List = $List.ToUpper()            if ($List -match '\*') {            $MachineListName = $List            $WildcardFlag = $True            $MachineList = QueryLDAP-ADObject $List "Computer"            <#            #$NYUMC_Workstation_Trees = @("CN=Workstations,CN=Hospital,DC=nyumc,DC=org", 
                                          "CN=Win,CN=NYULMC Clients,DC=nyumc,DC=org",
                                          "CN=LegacyClients,CN=NYULMC Clients,DC=nyumc,DC=org"
                                         )

            ### $MachineList = ($NYUMC_Workstation_Trees | % {Get-AdComputer -LDAPFilter "(Name=$List)" -SearchBase $_ -SearchScope Subtree -ErrorAction Stop | select Name } | sort Name).Name            $MachineList = ($NYUMC_Workstation_Trees | % { QueryLDAP-ADObject $List "Computer"}).Name            #>        } else {            if ($List -like '*.TXT') {                try {                     $MachineListName = $List                    $MachineList = Get-Content -Path $List | Sort | % { $_.toupper().trim() } | ? { $_.trim() -ne ""  } | Set-Content $List -PassThru # sort and trim whitespace and blank lines from textfile                }                catch { Error-Handler "Unable to open file list $List" $ExitonError }            } else {                $MachineList = $List            }        }    }    (!([string]::IsNullOrEmpty($Group))) {
        if ($ForceReboot -and !$Override) {
            Write-Host "`nThe [-FORCEREBOOT] switch is disabled if using the [-GROUPNAME] switch.`nUse the [-OVERRIDE] switch to override this restriction." ; exit

        } else {

            # Need to revise this to return correct results for groups with more than 1500 members
            <#
            $MemberType = "Computer"
            $MachineListName = $Group            $MachineList = QueryLDAP-GroupMembers $Group $MemberType
            #>            $MachineList = (Get-ADGroup -Identity $Group -Properties member).member | % { $_ -replace "(CN=)(.*?),.*",'$2' } | sort -Unique
            if (!$MachineList) { Error-Handler "Group [$Group] does not exist in AD or there are no [$MemberType] objects in the group" $ExitonError }        }    }    (!([string]::IsNullOrEmpty($OUPath))) {
        if ($ForceReboot -and !$Override) {
            Write-Host "The [-FORCEREBOOT] switch is disabled if using the [-OUPATH] switch.`nUse the [-OVERRIDE] switch to override this restriction." ; exit
        } else {
            $MachineListName = $OUPath            ### $MachineList = QueryLDAP-Computers_in_OU -OUPath $OUPath
            $MachineList = (Get-ADComputer -Filter * -SearchBase (Convert-CNtoDN -CanonicalName $OUPath) -SearchScope OneLevel -ErrorAction SilentlyContinue).Name
            if (![bool]$MachineList) { Error-Handler "Source OU Path [$OUPath] does not exist in AD or there are no computers in the OU" $ExitonError }        }    }    default { Error-Handler "This argument does not match any parameter" $ExitOnError }}#endregion>
#region Parse the switch arguments
switch ($True) {    $ADOnly {        $RDP = $False        $ForceReboot = $False    }    $CheckBootTime {        $ForceReboot = $False    }        $ForceReboot {        $GetComputerGroups = $False        $GetUserGroups = $False        $ADOnly = $False        $CheckBootTime = $False        $Report = $False        $RDP = $False        $SortbyOU = $False        if ($MachineList.Count -eq 1) {            $Answer = Get-YesNoAnswer "Do you want to remotely reboot [$MachineList]"
        } else {
            if ($WildcardFlag) {
                Write-Host "`nWildcard detected - these are the machines that match [$MachineListName]:`n"
                $MachineList
                Write-Host "`nTotal of [$($MachineList.Count)] machines found"
                $Answer = Get-YesNoAnswer "Do you want to remotely reboot all these machines"
            } else {
                $Answer = Get-YesNoAnswer "Do you want to remotely reboot all [$($MachineList.Count)] machine(s) found in [$MachineListName]"
            }
        }
        if ($Answer -eq "N") { exit } else { Write-Host }    }
}
#endregion

#region Start running the clock$Script_StartTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"
Write-Host "`nProcessing Start`t: $Script_StartTime`n"
#endregion


#region Construct multi-dimensional array to store status information on each computer$Win10UpgradeVersion = "10.0.19041"  #  This is for the -CHECKOSUPDATEREADY switch, to check if computer is < version 2004
$Counter, $Count_Pinged, $Count_NotPinged, $Count_FoundinAD, $Count_NotFoundinAD = 0
$MachineObjectProps = @{}
$MachineObject = @()
$MachineObjectTable = @()
$ReportTotals = @()
#endregion


#region Iterate through the machine list and execute the requested action
### $MachineList | fl *## #exit
<#
$OSVersionInfo = Get-OSVersion-NEW
$OSVersion = $OSVersionInfo.OSVersion
$OSBuild = $OSVersionInfo.OSBuild
$OSFullName = $OSVersionInfo.OSFullName
#>

:LOOP_OUTER
foreach ($Machine in $MachineList) {    $Machine = $Machine.ToUpper().Trim()    # Display progress bar
    $Counter++
    $PercentComplete = [int32](($Counter / $MachineList.Count) * 100)
    Write-Progress -Activity "Now Scanning [$Counter] out of [$($MachineList.Count)] Computers" `
        -CurrentOperation "Number of computers successfully pinged so far: $Count_Pinged" `
        -Status "$PercentComplete% complete" -PercentComplete $PercentComplete
    # Gather AD-specific information ...    try {
        # Determine OU of where machine is located in AD
        $CanonicalName = $Null
        $ADComputer = Get-ADComputer -Identity $Machine -Properties * -ErrorAction SilentlyContinue
        $CanonicalName = $ADComputer.CanonicalName -replace "/$Machine","" -replace "nyumc.org","+"
        ### $OSVersion = $ADComputer.OperatingSystem + " - build " + $ADComputer.OperatingSystemVersion
        $OSVersion = Get-OSVersion $ADComputer.OperatingSystem $ADComputer.OperatingSystemVersion
        $Count_FoundinAD++
    }        catch {        $CanonicalName = "COMPUTER NOT FOUND IN ACTIVE DIRECTORY"        $OSVersion = $LastBootTime = $Subnet = $ActiveUser = "UNKNOWN"        $Count_NotFoundinAD++
    }    # Enumerate the domain groups that the computer is a member of    if ($GetComputerGroups) { $DomainGroups_Computer = QueryLDAP-GroupList $Machine "Computer"; $Report = $True }
    ### if ($GetUserGroups) { $DomainGroups_User = QueryLDAP-GroupList $Machine "User" ; $Report = $True }
    # ... and if AD information is the only thing requested then skip the rest of the loop    if ($ADOnly) {        # $MachineObjectProps = [ordered] @{'Name'=$Machine; 'Pingable'='N/A'; 'DNS Name'="N/A"; 'IP Address'="N/A"}        $MachineObjectProps = [ordered] @{'Name'=$Machine}        $MachineObjectProps += @{"Organizational Unit" = $CanonicalName}        $MachineObjectProps += @{"OS Version" = $OSVersion}
        <#
        if ($CheckOSUpdateReady) {
            if ([version]$ADComputer.OperatingSystemVersion -lt [version]$Win10UpgradeVersion) {
                $MachineObjectProps += @{"OSUpdateReady" = "Yes" }            } else {
                $MachineObjectProps += @{"OSUpdateReady" = "No" }
            }
        }
        #>

        $MachineObjectProps += @{"OSInfo Source" = "AD"}
        if ($GetComputerGroups) { $MachineObjectProps += @{"Domain Computer Groups" = $DomainGroups_Computer} }        if ($GetUserGroups) { $MachineObjectProps += @{"Domain User Groups" = $DomainGroups_User} }        $MachineObjectTable += New-Object -TypeName PSObject -Property $MachineObjectProps        continue LOOP_OUTER    }        $MachineObject = Get-OnlineStatus $Machine    ### $MachineObject | fl *    ### exit    $Online = $MachineObject.OnlineStatus    if ($Online -ne "Yes") {        $Count_NotPinged++        $ActiveUser = "OFFLINE"        $DiskSpaceInfo = ""        ### $TaskReport = New-Object -TypeName PSObject -Property ([ordered]@{'Status'=$False; 'Name'='OFFLINE'; 'State'='OFFLINE'})        Write-Host "$Machine`t`t: Cannot ping machine`n" -ForegroundColor Red    } else {        $Count_Pinged++        $FQDN_Machine = $MachineObject.DNSHostName        $Machine_IPAddress = $MachineObject.IPAddress
        # Parse local admin credentials for the computer
        ### $LocalCredential = Get-LocalCredential "mcitadmin"
        if ($LocalUsername) { $LocalCredential = Get-LocalCredential $Machine $LocalUsername $LocalPassword }


        $WinRM = [bool](Test-WSMan -ComputerName $Machine -ErrorAction SilentlyContinue)
        <#
        if ($WinRM) {
            Write-Host "$Machine`t`t: WinRM is enabled"
        } else {
            Write-Host "$Machine`t`t: WinRM is not enabled"
        } 
        #>        # Add system information details to the machine object        if ($WinRM) {             $Sysinfo = Get-SystemInfo $Machine $LocalCredential            $MachineObjectProps += @{"OSInfo Source" = "WMI"}
            $OSVersion = $Sysinfo.OSVersion            $LastBootTime = $Sysinfo.LastBootTime
            # Get the machine's subnet
            $Subnet = Get-Subnet $Machine $LocalCredential
                # Get current logged in user on the computer            $ActiveUser = (Get-CurrentRemoteUser($Machine))[0]

        } else {
            $MachineObjectProps += @{"OSInfo Source" = "WinRM Not Enabled"}
            $OSVersion = $LastBootTime = $Subnet = $ActiveUser = "WinRM Not Enabled"        }        # Get Windows Update history        if ($GetWindowsUpdates) { 
            $ReportFileName = Get-WUHistory $Machine
            Write-Host "Saving Windows Update History report to: $ReportFileName`n"
        }        # Get free disk space        $DiskSpace = Get-DiskSpace $Machine        $DiskSpaceInfo = [string]::Format("{0}GB / {1}GB / {2}GB", $DiskSpace.Free, $DiskSpace.Used, $DiskSpace.Total)        # Get requested events        if ([bool]$GetAppEvents -or [bool]$GetSecurityEvents -or [bool]$GetSystemEvents) {            switch ($True) {                (![string]::IsNullOrEmpty($GetAppEvents)) {                     $EventID = [string]$GetAppEvents                    $EventLogname = "APPLICATION"                }                (![string]::IsNullOrEmpty($GetSecurityEvents)) {                    $EventID = [string]$GetSecurityEvents                    $EventLogname = "SECURITY"                }                (![string]::IsNullOrEmpty($GetSystemEvents)) {                    $EventID = [string]$GetSystemEvents                    $EventLogname = "SYSTEM"                }            }            $Events = Get-RemoteEventLog $Machine $EventID $EventLogname $LocalCredential            if (!([bool]$Events)) {                 Write-Warning "$Machine`t`t: No '$EventLogname' events for Event ID '$EventID' were found"            } else {                $EventLogfile = "C:\TEMP\$Machine-$EventLogname-EVENT_ID-$EventID.log"
            }        }        # Check for any registry settings that are requested        if ($CheckRegistry) {            <#            $Index = 0            $RemoteRegValue = @()            ### $RegistryTable = ("HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings", "AutoConfigURL"),  
            ###                  ("HKLM:\Software\Policies\Microsoft\Windows\WindowsUpdate", "TargetGroup") 
            foreach ($RegistryItem in $RegistryTable) {
                try{
                    ### $Index = $RegistryTable.IndexOf($RegistryItem)
                    $RemoteRegValue[$Index] = Get-RemoteRegValue $Machine $RegistryItem[1] $RegistryItem[2]
                    Write-Host $RegistryItem[1], $RegistryItem[2], $RemoteRegValue[$Index]
                    if (($RemoteRegValue[$Index] -eq $Null) -or ($RemoteRegValue[$Index] -eq "")) { $RemoteRegValue[$Index] = "EMPTY" }
                }                catch {
                    $RemoteRegValue[$Index] = "UNKNOWN"
                }                $Index++
                $RemoteRegValue[$Index]
            }            #>            $RemoteRegKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings"            $RemoteRegName = "AutoConfigURL"            $RemoteRegValue = Get-RemoteRegValue $Machine $RemoteRegKey $RemoteRegName
            ### Write-Host $RemoteRegKey $RemoteRegName $RemoteRegValue
            ### exit        }        <#        if ($CheckOSUpdateReady) {
            if ([version]$ADComputer.OperatingSystemVersion -lt [version]$Win10UpgradeVersion) {
                $OSUpdateReadyFlag = "Yes"
            } else {
                $OSUpdateReadyFlag = "No"
            }
        }        #>        if ($GetAppVersion) {            $Altiris_Version = Get-AppVersion $FQDN_Machine "AeXNSClient" "${env:ProgramFiles}\Altiris\Altiris Agent\AeXNSAgent.exe"
        }        switch ($Special) {            "DISABLEREBOOT" {                $TaskReport = $Null                $TaskAction = "DISABLE"                ### $TaskAction = "CHECK"                $TaskName = "EUDE_STANDARD_REBOOT"                Write-Host "`n$Machine`t`t: Deleting weekly scheduled reboot -- wait an hour to check that scheduled task is deleted" -ForegroundColor Yellow                Set-RemoteRegValue $Machine "HKLM:\Software\EUDE" "DoNotReboot" "1" "STRING"            }            "ENABLEREBOOT" {                Write-Host "`n$Machine`t`t: Re-enabling weekly scheduled reboot -- wait an hour to check that scheduled task is recreated" -ForegroundColor Yellow                Delete-RemoteRegValue $Machine "HKLM:\Software\EUDE" "DoNotReboot"            }            default {}        }                if ([bool]$TaskAction) {            $TaskReport = $Null            if (!(([string]::IsNullOrEmpty($TaskName)))) {                $TaskReport = Config-ScheduledTask $Machine $TaskAction $TaskName                ### $TaskReport | ft *                if ($TaskReport.Status) {                    Write-Host "$Machine`t`t: Action [$TaskAction] succeeded on task [$TaskName] - returned status is: " $TaskReport.State -ForegroundColor Green                } else {
                    Write-Host "$Machine`t`t: Action [$TaskAction] failed on task [$TaskName] - returned status is: " $TaskReport.State -ForegroundColor Red
                }            } else {                Write-Warning "$Machine`t`t: Task Action [$TaskAction] is missing the task name"            }        }        if ($ForceReboot) {            if ((!$Override) -and ($Machine -in @($Computername,"RRT-EUDE-WIN01","RRT-EUDE-WIN02"))) {                $RebootTime = "SKIPPED"                Write-Warning "$Machine`t`t: Attempting to reboot the host or a protected machine - use -OVERRIDE switch"            } else {                try {                    Restart-Computer -ComputerName $FQDN_Machine -Force # -WhatIf -Verbose                    $RebootTime = (Get-Date).ToString()                    Write-Host "$Machine`t`t: Restarting computer"                }                catch {                    Write-Warning "$Machine`t`t: Failed to restart machine"                }            }        }    }    # Construct the object with all elements    $MachineObjectProps = [ordered] @{'Name'=$Machine}    $MachineObjectProps += @{"Pingable" = $MachineObject.OnlineStatus}    $MachineObjectProps += @{"DNS Name" = $MachineObject.DNSHostName}    $MachineObjectProps += @{"IP Address" = $MachineObject.IPAddress}    $MachineObjectProps += @{"Subnet" = $Subnet}    $MachineObjectProps += @{"Organizational Unit" = $CanonicalName}    $MachineObjectProps += @{"Current User" = $ActiveUser}    if ($CheckBootTime -or $RDP) { $MachineObjectProps += @{"Last Boot Time" = $LastBootTime} }    if ($ForceReboot) { $MachineObjectProps += @{"Reboot Time" = $RebootTime} }    $MachineObjectProps += @{"OS Version" = $OSVersion}
    $MachineObjectProps += @{"Free / Used / Total Disk Space" = $DiskSpaceInfo}
    ### if ($CheckOSUpdateReady) { $MachineObjectProps += @{"OSUpdateReady" = $OSUpdateReadyFlag} }    if ($GetAppVersion) { $MachineObjectProps += @{"Altiris Version" = $Altiris_Version} }    if ($CheckRegistry) { $MachineObjectProps += @{"RegistryValue" = $RemoteRegValue} }    if ([bool]$TaskAction) {        $MachineObjectProps += @{"TaskName" = $TaskReport.Name}
        $MachineObjectProps += @{"TaskState" = $TaskReport.State}
    }
    if ($GetComputerGroups) { $MachineObjectProps += @{"Domain Computer Groups" = $DomainGroups_Computer} }    if ($GetUserGroups) { $MachineObjectProps += @{"Domain User Groups" = $DomainGroups_User} }    $MachineObjectTable += New-Object -TypeName PSObject -Property $MachineObjectProps}#endregion


#region Display to screen console
if ($SortbyOU) {
    $OutputTable = $MachineObjectTable | sort "Organizational Unit", "Name"
} else {
    $OutputTable = $MachineObjectTable | sort "Name"
}

if (!$ADOnly) { $OutputTable = $OutputTable | Select-Object * -ExcludeProperty "Organizational Unit" }
if ($CheckBootTime -or $ForceReboot -or $RDP -or $CheckOSUpdateReady) { $OutputTable = $OutputTable | Select-Object * -ExcludeProperty "OS Version" }
    $OutputTable | ft * -AutoSize
#endregion


#region Display remote event logs if asked for
if ([bool]$Events) {
    Write-Host "Writing restart and shutdown events to logfile in [$EventLogfile] folder..."
    $Events | Out-File -FilePath $EventLogfile -Force -Width 250 -Encoding ascii
}
#endregion
#region Manage RDP sessionsif ($RDP) {    if ($MachineList.Count -gt 1) {         Write-Warning "[-RDP] switched detected - can only RDP to a single machine."    } else {        if ($MachineObject.OnlineStatus -eq "Yes") {
            switch ($ActiveUser) {
                "NO_CURRENT_LOGON" { Write-Host -ForegroundColor Yellow "   --- Machine" $FQDN_Machine "[" $Machine_IPAddress "] is ONLINE and no user is logged in" }
                "UNKNOWN" { Write-Host -ForegroundColor Yellow "   --- Machine" $FQDN_Machine "[" $Machine_IPAddress "] is ONLINE but cannot determine if a user is logged in" }
                default { Write-Host -ForegroundColor Green "   --- Machine" $FQDN_Machine "[" $Machine_IPAddress "] is ONLINE and user [" $ActiveUser "] is logged in" }
            }

            $Answer = Get-YesNoAnswer "   Do you want to connect remotely to $FQDN_Machine"
    
            if ($Answer -eq "Y") {
                Write-Host "`n   Attempting to connect to $FQDN_Machine ..."

                if ($env:USERNAME -like "*_ADM") {
                    $Arguments = "/v:$FQDN_Machine /prompt"
                } else {
                    $Arguments = "/v:$FQDN_Machine"
                }

                try { & { Start-Process mstsc.exe -ArgumentList "$Arguments" } }
                catch { Error-Handler "`n   Failed to connect to: $FQDN_Machine" $ExitonError }
            }            exit        }    }

}#endregion#region Enumerate totals and display to screen
if (!$ADOnly) {    $ReportTotalProps = [ordered]@{"Number of machines found online" = $Count_Pinged}    $ReportTotalProps += @{"Number of machines not online" = $Count_NotPinged}}$ReportTotalProps += [ordered]@{"Number of machines found in AD" = $Count_FoundinAD}$ReportTotalProps += @{"Number of machines not found in AD" = $Count_NotFoundinAD}$ReportTotals = New-Object -TypeName PSObject -Property $ReportTotalPropsWrite-Host "`n`nReport Totals:"$ReportTotals | fl *#endregion#region Save output to spreadsheet if requestedif ($Report) {    # Build the report filename
    $ReportFile_CSV = "$OutputFolder\$ScriptName-REPORT-$Today.csv"
    if ($SortbyOU) { Write-Host "`n- NOTE: The '-SortbyOU' option will be ignored because '-Report' was specified" }    # Convert Report CSV to XLSX
    $MachineObjectTable | Export-Csv -Path $ReportFile_CSV -Append -NoTypeInformation -Force
    Write-Host "`n- Converting report to Excel format" -NoNewline
    $Process_StartTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"

    try {
        [IO.File]::OpenWrite($ReportFile_CSV).Close()
        Convert-CSVtoXLSX $ReportFile_CSV
        $ReportFile = $ReportFile_CSV -replace "csv","xlsx"
        $Process_EndTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"
        $Process_TimeDiff = Get-TimeDifference -Start $Process_StartTime -End $Process_EndTime
        Write-Host " (done in $Process_TimeDiff)"
    }
    catch {
        Write-Host "`n`n- Unable to convert - copying CSV file instead" -ForegroundColor Red
        $ReportFile = $ReportFile_CSV
    }

    # Copy report from local folder to network share
    Write-Host "`n- Saving report [$ReportFolder\$([System.IO.Path]::GetFileName($ReportFile))]"
    Copy-Item -Path $ReportFile -Destination $ReportFolder

    Start-Process -FilePath "Excel.exe" -ArgumentList $ReportFile -WindowStyle Maximized

}
#endregion

#region Stop the clock and exit$Script_EndTime = Get-Date -Format "MM/dd/yyyy hh:mm:ss tt"
$TimeDiff = Get-TimeDifference -Start $Script_StartTime -End $Script_EndTime
Write-Host "Processing Stop`t`t: $Script_EndTime"
Write-Host "`nScript completed in $TimeDiff`n`n"
#endregion
if ($DevTest) { Stop-Transcript }

