﻿#==========================================================================================================================================# Program	: GET-WIN10UPGRADESTATUS.PS1# Version	: 1.0.0# Date		: Feb 09 2020# Author	: Roland Thomas# Team		: MCIT / End User Device Engineering## This script will read the Windows 10 Upgrade Log on a remote computer.### Usage     : GET-WIN10UPGRADESTATUS.PS1 <machinespec>## 02-09-20 (v1.0.0): First release#Requires -Version 3.0### #Requires -RunAsAdministrator

[cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]param(    [string]$Computer = $Null)


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Error-Handler([string]$ErrorMessage, [boolean]$_ExitonError) {

    Write-Log "$ErrorMessage" "Red"

    try {

        ### $ExceptionMessage = $Error[0].Exception.Message
        ### if ($ExceptionMessage -ne $Null) { Write-Log "System error message was: '$ExceptionMessage'" "Yellow" }
        
        $HResultCode = $Error[0].Exception.HResult

        ### Write-Host "HResultCode = $HResultCode"

        if (([bool]$HResultCode) -and ($HResultCode -ne 0)) {
            $ExitCode = "0x" + $("{0:x}" -f $HResultCode)
        } else {
            $ExitCode = -1
        }

    }
    catch { 
        $ExitCode = -999
    }

    ### Write-Log "Returning to caller with Error Code: $ExitCode" "Yellow"

    if ($_ExitonError) {
        Stop-Transcript -ErrorAction SilentlyContinue | Out-Null
        exit $ExitCode
    } else {
        return $ExitCode
    }

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Convert-OSBuildNumber ($OSBuild) {

    switch -Wildcard ($OSBuild) {
        "*10240*" { $OSVersion = "1507 RTM" }
        "*10586*" { $OSVersion = "1511" }
        "*14393*" { $OSVersion = "1607" }
        "*15063*" { $OSVersion = "1703" }
        "*16299*" { $OSVersion = "1709" }
        "*17134*" { $OSVersion = "1803" }
        "*17763*" { $OSVersion = "1809" }
        "*18362*" { $OSVersion = "1903" }        "*18845*" { $OSVersion = "InsiderPreview-20H1" }        default { $OSVersion = "UNKNOWN" }    }    return $OSVersion
}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-OnlineStatus($Machine) {    $PingStatus = Test-Connection -ComputerName $Machine -Count 1 -Quiet    if ($PingStatus) {    ### $PingStatus = Ping-Computer -ComputerName $Machine    ### if ($PingStatus.Online) {        $Machine_IPAddress = (Test-Connection -ComputerName $Machine -Count 1).IPV4Address.IPAddressToString        $FQDN_Machine = ([System.Net.Dns]::GetHostEntry($Machine)).Hostname        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "Yes"
            DNSHostName = $FQDN_Machine
            IPAddress = $Machine_IPAddress
        }

    } else {        $ReturnObject = [PSCustomObject]@{
            Name = $Machine
            OnlineStatus = "No"
            DNSHostName = "OFFLINE"
            IPAddress = "OFFLINE"
        }
    }    return $ReturnObject}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-OSVersion {

    $OSInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem -ErrorAction SilentlyContinue

    if ([bool]$OSInfo) {

        $OSLongName = $OSInfo.Caption -replace "Microsoft ",""
        $OSBuild = $OSInfo.Version

        if ($OSLongName -like "*Windows 7*") {

            $OSShortName = $OSLongName -replace "Windows 7","Win7"
            $OSFullName = "$OSLongName $OSBuild"        } else {            $OSVersion = Convert-OSBuildNumber $OSBuild
            $OSShortName = $OSLongName -replace "Windows 10","Win10"            $OSFullName = "$OSLongName (ver $OSVersion - build $OSBuild)"
        }    } else {        $OSLongName = $OSShortName = $OSBuild = $OSVersion = $OSFullName = "UNKNOWN"
    }    $OSVersionObject = [PSCustomObject]@{
        OSLongName = $OSLongName
        OSShortName = $OSShortName
        OSBuild = $OSBuild
        OSVersion = $OSVersion
        OSFullName = $OSFullName
    }


    return $OSVersionObject

}

# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------function Get-RemoteProcessUpTime {    [cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]    param(        [string]$Computer = $Null    )


    $Results = Invoke-Command -ComputerName $Computer -HideComputerName -ScriptBlock { 

        $Properties = @{}
        $ProcessDuration = @()

        $ProcessList = Get-Process -ErrorAction SilentlyContinue

        foreach ($Process in $ProcessList) {

            $Properties = [ordered]@{
                Name = $Process.Name
                ID = $Process.ID
                Version = $Process.FileVersion
            }

            if ($Process.StartTime -ne $Null) {

                $TimeSpan = New-TimeSpan -Start $Process.StartTime -ErrorAction SilentlyContinue

                $Properties += [ordered]@{
                    StartTime = $Process.StartTime
                    Days = $TimeSpan.Days
                    Hours = $TimeSpan.Hours
                    Minutes = $TimeSpan.Minutes
                    Seconds = $TimeSpan.Seconds
                }

            }

            $ProcessDuration += New-Object -TypeName PSObject -Property $Properties

        }

        return ( $ProcessDuration | ? { $_.Name -ne "Idle" } ) # return all processes except the "Idle" process

    }

    return $Results

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-RemoteRegValue {

    [cmdletbinding (DefaultParameterSetName=$Null,SupportsShouldProcess=$True, ConfirmImpact="High")]
    param(
        [string]$Computer = $Null,
        [string]$RegKeyPath = $Null,
        [string]$RegKeyName = $Null
    )


    $Results = Invoke-Command -ComputerName $Computer -HideComputerName -ArgumentList $Computer, $RegKeyPath, $RegKeyName -ScriptBlock { 

        param ($RemoteComputer, $Key, $Name) 

        return (Get-ItemProperty -Path $Key -Name $Name -ErrorAction SilentlyContinue).$Name
       
    }

    return $Results

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Get-SystemInfo ($Machine) {

    # Get system information from the Win32_ComputerSystem and Win32_BIOS classes
    try {
        $SysInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_ComputerSystem -ComputerName $Machine -ErrorAction SilentlyContinue
        $Manufacturer = $SysInfo.Manufacturer
        $Model = $SysInfo.Model
        $BIOS = (Get-WmiObject -Namespace "root\cimv2" -Class Win32_BIOS -ComputerName $Machine -ErrorAction SilentlyContinue).Description  # Also property SMBIOSBIOSVersion
    }    catch {        $Manufacturer = $Model = $BIOS = "UNKNOWN"    }

    # Get system information from the Win32_OperatingSystem classes
    try {
        $OSInfo = Get-WmiObject -Namespace "root\cimv2" -Class Win32_OperatingSystem -ComputerName $Machine -ErrorAction SilentlyContinue        # Get last boot tiime        $BootTime = $OSInfo.ConvertToDateTime($OSInfo.LastBootUpTime)  # Use this if enumerating with GET-WMIOBJECT        ### $BootTime = $OSInfo.LastBootUpTime    # Use this if enumerating with GET-CIMINSTANCE        if ($BootTime -eq $Null) { $BootTime = "UNKNOWN" }
        # Get OS Version
        $OSName = $OSInfo.Caption -replace "Microsoft ",""        if ($OSName -like "*Windows 7*") {
            $OSVersion = Get-OSVersion $OSName $OSInfo.CSDVersion        } else {            $OSVersion = Get-OSVersion $OSName $OSInfo.Version        }

        $OSUpgradeDate = $OSInfo.ConvertToDateTime($OSInfo.InstallDate)

    }    catch {        $BootTime = $OSVersion = $OSUpgradeDate = "UNKNOWN"    }


    $ReturnObject = [PSCustomObject]@{
        Manufacturer = $Manufacturer
        Model = $Model
        BIOS = $BIOS
        OSVersion = $OSVersion
        OSUpgradeDate = $OSUpgradeDate
        BootTime = $BootTime
    }    return $ReturnObject
}


# --------------------------------------------------------------------------------------------------------------------------------------------------------------------------
function Write-Log ([string]$Message) {

    $ScriptName = $Global:Scriptname.ToUpper()
    $CallingFunction = ((Get-Variable MyInvocation -Scope 1).Value.MyCommand.Name).ToUpper() -replace ".ps1",""
    $LineNumber = $MyInvocation.ScriptLineNumber

    $Now = Get-Date -format "yyyy-MM-dd_HH:mm:ss"

    if (($CallingFunction -eq $ScriptName) -or ($CallingFunction -like "ALTIRISSCRIPT*")) {
        $LogMsg = "${Now}: [Line:$LineNumber (Main Section)] ${Message}"
    } else {
        $LogMsg = "${Now}: [Line:$LineNumber (Function '$CallingFunction')] ${Message}"
    }

    Write-Verbose $LogMsg

}


# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------

$ScriptName = $MyInvocation.MyCommand.Name.ToUpper()
$Domain = $env:USERDOMAIN


if ($Computer) { 

    $Computer = $Computer.ToUpper()

    $ComputerStatus = Get-OnlineStatus $Computer

    if ($ComputerStatus.OnlineStatus -ne "Yes") {        Write-Host "Cannot ping machine [$Computer] - it may be offline" -ForegroundColor Red
        exit
    }    

    ### cls

    Write-Host "Windows 10 Upgrade Status for Computer [$Computer]" -ForegroundColor Yellow

    Write-Host "`n`nSYSTEM INFORMATION" -ForegroundColor Green

    $SysInfo = Get-SystemInfo $Computer

    Write-Host "Manufacturer`t=`t$($SysInfo.Manufacturer)"
    Write-Host "Model Name`t=`t$($SysInfo.Model)"
    Write-Host "BIOS Version`t=`t$($SysInfo.BIOS)"
    Write-Host "OS Version`t=`t$($SysInfo.OSVersion.OSFullName)"
    Write-Host "OS Upgrade Date`t=`t$($SysInfo.OSUpgradeDate)"
    Write-Host "Last Boot Date`t=`t$($SysInfo.BootTime)"


    $DiskSpace = Invoke-Command -ComputerName $Computer -ScriptBlock {

        $FreeDiskSpace = [math]::Round((Get-PSDrive -Name C).Free / 1GB)
        $UsedDiskSpace = [math]::Round((Get-PSDrive -Name C).Used / 1GB)
        $TotalDiskSpace = $FreeDiskSpace + $UsedDiskSpace

        return [PSCustomObject]@{
            Free = $FreeDiskSpace
            Used = $UsedDiskSpace
            Total = $TotalDiskSpace
        }

    }

    Write-Host "`n`nDISK SPACE INFORMATION" -ForegroundColor Green
    Write-Host "Used Space C:`t=`t$($DiskSpace.Used) GB"
    Write-Host "Free Space C:`t=`t$($DiskSpace.Free) GB"
    Write-Host "Total Space C:`t=`t$($DiskSpace.Total) GB"


    Write-Host "`n`nREGISTRY SETTINGS" -ForegroundColor Green
    $RegKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization"
    $RegName = "DODownloadMode"

    $RegValue = Get-RemoteRegValue $Computer $RegKey $RegName
    if ([bool]$RegValue) {
        Write-Host "Registry setting [$RegKey`:$RegName] = $RegValue"
    } else {
        Write-Host "Registry setting [$RegKey`:$RegName] = NOT FOUND" -ForegroundColor Red
    }


    # Get runtime status of the SETUP processes
    Write-Host "`n`nREAL-TIME REMOTE PROCESS INFORMATION" -ForegroundColor Green
    $SetupProcesses = Get-RemoteProcessUpTime $Computer | ? { $_.Name -like "setup*" }

    if([bool]$SetupProcesses) {
        $SetupProcesses | sort Name | Select-Object -Property * -ExcludeProperty RunspaceID | ft
    } else {
        Write-Host "No SETUP processes currently running" -ForegroundColor Red
    }


    # Get setup log file
    <#
    $LogPath = "\\$Computer\c$\temp"
    ### $FilePattern = "install-win10featureupdate-*$Computer*.log"
    $LogFile = Get-ChildItem -Path $LogPath -Filter $FilePattern | sort LastWriteTime -Descending | select -First 1
    #>

    $LogPath = "\\$Computer\c$\temp"
    $LogFileName = "$Computer-win10upgrade.log"
    $LogFile = "$LogPath\$LogFilename"
    
    Write-Host "`n`nLOGFILE INFORMATION: $LogFile" -ForegroundColor Green

    if (Test-Path -Path $LogFile) {
        Copy-Item -Path $LogFile -Destination C:\TEMP -Force
        Get-Content C:\TEMP\$LogFileName
    } else {
        Write-Host "NO LOGFILE FOUND" -ForegroundColor Red
    }

    # Grab the rollback logs if found
    if (Test-Path -Path "$LogPath\*__DISM*") { Copy-Item -Path "$LogPath\*__DISM*" -Destination C:\TEMP -Force }
    if (Test-Path -Path "$LogPath\*__ROLLBACK*") { Copy-Item -Path "$LogPath\*__ROLLBACK*" -Destination C:\TEMP -Force }
    
    Write-Host "`n" ("*" * 160) "`n" -ForegroundColor Cyan


    <#
    # Spot check various Program Files folders
    $ProgramFilesFolders =  @("c:\program files (x86)\adobe", "c:\program files (x86)\microsoft office", "c:\program files (x86)\mozilla firefox")

    foreach ($Folder in $ProgramFilesFolders) {

        $Folder = $Folder.ToUpper()
    
        if (Test-Path -Path $Folder) {
            Write-Host "`n`nPROGRAMFILES FOLDER: [$Folder]" -ForegroundColor Green
            dir -Path $Folder
        } else {
            Write-Host "`n`nPROGRAMFILES FOLDER: [$Folder] IS NOT FOUND" -ForegroundColor Red
        }

    }

    Write-Host "`n" ("*" * 160) "`n" -ForegroundColor Cyan
    #>

} else {

    Write-Host "Usage: $ScriptName [-Computer <computername>]"

}
