Function Invoke-DiskCleanup{

[CmdletBinding()] 
    Param ( 
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()] 
        [byte]$StateFlags= '89',
 
        [Parameter(Mandatory=$false)] 
        [string]$includeData='',
         
        [Parameter(Mandatory=$false)]
        [string]$excludeData='', 

        [Parameter(Mandatory=$false)] 
        [string]$strKeyPath="HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches",
         
        [Parameter(Mandatory=$false)] 
        [switch]$clean_StateFlag
    ) 

    $subkeys = Get-ChildItem -Path $strKeyPath -Name -Include $includeData -Exclude $excludeData
    Write-Log -Message "Function start : Invoke-Diskcleanup : Subkey Count = $($subkeys.count) "

    $strValueName="StateFlags00$($StateFlags)"
    Write-Log -Message "Function : Invoke-Diskcleanup : Setting StateFlag = $strValueName"

ForEach($subkey in $subkeys){
Write-log -Message " Writing Registry : -Path $strKeyPath\$subkey -Name $strValueName -PropertyType DWord -Value 2"

    $null = New-ItemProperty `
        -Path $strKeyPath\$subkey `
        -Name $strValueName `
        -PropertyType DWord `
        -Value 2 `
        #-ea SilentlyContinue `
        #-wa SilentlyContinue 
}

Write-log -Message " Running Command : cleanmgr -ArgumentList /sagerun:$StateFlags"

Start-Process cleanmgr `
        -ArgumentList "/sagerun:$StateFlags" `
        -Wait `
        -NoNewWindow `
        -ErrorAction   SilentlyContinue `
        -WarningAction SilentlyContinue 

if ($clean_StateFlag){
Write-log -Message " Clean_stateFlag: $clean_StateFlag : Cleaning the clean_StateFlag from registry "

    ForEach($subkey in $subkeys){
        $null = Remove-ItemProperty `
            -Path $strKeyPath\$subkey `
            -Name $strValueName `
            -ea SilentlyContinue `
            -wa SilentlyContinue
}}
Write-log -Message " Function End : Invoke-DiskCleanup"

}