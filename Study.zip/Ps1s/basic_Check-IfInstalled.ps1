Function Check-IfInstalled
{	[CmdletBinding()]
	Param(
     [Parameter(Mandatory=$True,ValueFromPipeline=$True)]
	 [String[]]$appName,
     [Parameter(Mandatory=$false,ValueFromPipeline=$True)]
     [String[]]$exclude)

Begin{
    $app32=@()
    $app64=@()
    $installed=$True }
 
Process{
    $app32=Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* -Exclude $exclude | where {($_.displayname -like $appName)}
    $app64=Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* -Exclude $exclude | where  {($_.displayname -like $appName)}
    If (($app32 -ne $null) -or ($app64 -ne $null)){$installed=$True} 
    else {$installed = $false}} #Application is Installed , End of Process Block

End{Return $installed}
}