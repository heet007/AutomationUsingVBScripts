﻿#[CmdletBinding()]
param ([parameter(mandatory)] 
[validateset("Install","Uninstall")] 
[string] $Action )


#--------------------------------
#region Function Definations and Modules

Function Write-Log #Author: Hitesh Patel
{ 
    [CmdletBinding()] 
    Param 
    ( 
        [Parameter(Mandatory=$true, 
                   ValueFromPipelineByPropertyName=$true)] 
        [ValidateNotNullOrEmpty()] 
        [Alias("LogContent")] 
        [string]$Message, 
 
        [Parameter(Mandatory=$false)] 
        [Alias('LogPath')] 
        [string]$Path="$env:SystemDrive\temp\InstallBT_Client_ScriptBased.log", 
         
        [Parameter(Mandatory=$false)] 
        [ValidateSet("Error","Warn","Info")] 
        [string]$Level="Info", 
         
        [Parameter(Mandatory=$false)] 
        [switch]$NoClobber 
    ) 
 
    Begin 
    { 
        # Set VerbosePreference to Continue so that verbose messages are displayed. 
        $VerbosePreference = 'SilentlyContinue' 
    } 
    Process 
    { 
         
        # If the file already exists and NoClobber was specified, do not write to the log. 
        if ((Test-Path $Path) -AND $NoClobber) { 
            Write-Error "Log file $Path already exists, and you specified NoClobber. Either delete the file or specify a different name." 
            Return 
            } 
 
        # If attempting to write to a log file in a folder/path that doesn't exist create the file including the path. 
        elseif (!(Test-Path $Path)) { 
            Write-Verbose "Creating $Path." 
            $NewLogFile = New-Item $Path -Force -ItemType File 
            } 
 
        else { 
            # Nothing to see here yet. 
            } 
 
        # Format Date for our Log File 
        $FormattedDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss" 
 
        # Write message to error, warning, or verbose pipeline and specify $LevelText 
        switch ($Level) { 
            'Error' { 
                Write-Error $Message 
                $LevelText = 'ERROR:' 
                } 
            'Warn' { 
                Write-Warning $Message 
                $LevelText = 'WARNING:' 
                } 
            'Info' { 
                Write-Verbose $Message 
                $LevelText = 'INFO:' 
                } 
            } 
         
        # Write log entry to $Path 
        
        "$FormattedDate $LevelText $Message" | Out-File -FilePath $Path -Append
    } 
    End 
    { 
    } 
}

Function GetLinkedParams #Author: Hitesh Patel
 {
 [CmdletBinding()] 
    Param 
    ( 
        [Parameter(Mandatory=$true)] 
        $obj, 
 
        [Parameter(Mandatory=$true)] 
        $DomainInfo,

         [Parameter(Mandatory=$true)] 
        $parentOU

        ) 

        Write-log "ParentOU : $parentOU"

        $keys=$obj.$parentOU.keys
        Write-log "Key(s): $keys"

        foreach($i in $Keys)
            {
            $searchItem="ou=$i".ToLower()
            Write-log "Search item : $searchItem, Found : $($DomainInfo.contains($searchItem))"

                if ($DomainInfo.contains($searchItem))
                {
                
                $param =$obj.$parentOU.$i
                
                }
            }
          
Return $param
 }

Function Get-InstalledApplications #Author: Hitesh Patel
{
	    [CmdletBinding(DefaultParameterSetName='PName')]
        Param (

        [Parameter(Mandatory=$true,ParameterSetName='PName',Position=0)]
        [ValidateNotNullorEmpty()]
        [string]$ProductName,

        [Parameter(Mandatory=$true,ParameterSetName='Pcode',Position=1)]
        [ValidatePattern("^(\{{0,1}([0-9a-fA-F]){8}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){12}\}{0,1})$")]
        [ValidateNotNullorEmpty()]
        [string]$ProductCode,

        [Parameter(Mandatory=$False,Position=2)]
        [ValidateNotNullorEmpty()]
        #[ValidateSet('PsObject','Boolean')]
        [Switch]$GetObj,

        [Parameter(Mandatory=$false,Position=3)]
        [Switch]$Exclude_SysWow
            ) 

$obj=@()
$Counter=0
$Check=$null

        if (($Exclude_SysWow) -or ([IntPtr]::Size -eq 4))
               {$path = @('HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*')
               $Counter=$path.Length}

        else   {$path = @('HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
                $Counter=$path.Length
        }
           
#[psobject[]]$AppInfo= @()
#if ($get -eq 'PsObject'){

$ErrorActionPreference = "SilentlyContinue"

if ($GetObj){
    foreach($item in $path)
       {    
         if ($ProductName)
            {
        <# $checkBit=$false
            if (($item -notlike "*Wow6432Node*") -and ([IntPtr]::Size -ne 4)){$checkBit=$true}
                                                 else { $checkBit=$False }
                                                 $IS64= @{label="is64"; expression={ $checkBit } } #>  

           $obj+= Get-ChildItem $item|
                  ForEach-Object {Get-ItemProperty $_.Pspath}|
                  Where-Object {$_.displayname -like $ProductName}|
                  Select-Object -Property Displayname,DisplayVersion,publisher,Pschildname,InstallDate,UninstallString,InstallSource -ErrorAction SilentlyContinue
             }
         
        else {
            $obj+= Get-ChildItem $item|
                  ForEach-Object {Get-ItemProperty $_.Pspath}|
                  Where-Object {$_.Pschildname -eq $ProductCode}|
                  Select-Object -Property Displayname,DisplayVersion,publisher,Pschildname,InstallDate,UninstallString,InstallSource -ErrorAction SilentlyContinue
             }

        }
      $ErrorActionPreference = "Continue" # this is to avoid error due to invalid characters in the registry path like "Root\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\BeyondTrust Remote Support Jump Client [remotesupport.nyumc.org-606F43B0]"
       If ($obj.count -ne 0){Return $obj}
       Else {Return $False}
}

Else{
       foreach($item in $path)
        {
                if ($ProductName){$Check=Get-ChildItem $item|ForEach-Object {Get-ItemProperty $_.pspath}|Where-Object {$_.displayname -like $ProductName}}
                Else             {$Check=Get-ChildItem $item|ForEach-Object {Get-ItemProperty $_.pspath}|Where-Object {$_.Pschildname -eq $ProductCode}}
               
              $ErrorActionPreference = "Continue" # this is to avoide error due to invalid characters in the registry path like "Root\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\BeyondTrust Remote Support Jump Client [remotesupport.nyumc.org-606F43B0]"
      
                If ($Check -ne $null)
                        {$Counter+=1}
                Else    {$Counter-=1}
                
       }

        
If($Counter -ge 1){Return $True}
Else              {Return $False}

    }

}#end Function


			
#--------------------------------------------------------------------
Write-Log -Message "Current Execution policy - $(Get-ExecutionPolicy -Scope LocalMachine)"
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process -Force -ErrorAction SilentlyContinue
Write-Log -Message "Running Powershell in - $(Get-ExecutionPolicy -Scope Process)"

# Set CurrentDIr
If ($MyInvocation.MyCommand.CommandType -eq "ExternalScript") { $ScriptPath = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition }
Else { $ScriptPath = Split-Path -Parent -Path ([Environment]::GetCommandLineArgs()[0]) }



#Initialise the Veriable
#$sScriptDir= $ScriptPath
$sScriptDir= "\\mscsnyu01\adbuild\DET_Builds\Packages\BeyondTrust\Bomgar_Client_Script\21.1.1"
$error1=$False
$ExitC=0
$tags=@{}
$jumpGroup=@{}
$param_JumpGroup=$null
$param_tags=$null
$Precheck = $null
$var=$null
$removeexe=$null



#installation
IF ($Action -eq "Install")
 {

#region Cleanup
 
         $Precheck=Get-InstalledApplications -ProductCode "{5ADA213E-0F62-4DAE-9A07-16120E3958E7}"
         
         If($Precheck) 
            {
                #stop Process
                $proc=Stop-Process -Name "bomgar-scc" -PassThru -Force -ErrorAction SilentlyContinue
                If($proc){Write-Log -Message "Stopped Process $proc"}
                Else{Write-Log -Message "Process (bomgar-scc) Does Not Exists or Could Not Stop the Process"}
                #Remove Old MSI 

                Write-Log -Message "Found old Application, Trying to Remove it"
                $removemsi= "/x {5ADA213E-0F62-4DAE-9A07-16120E3958E7} /qn " #The CMD prompt appreares during uninstall, which not be suppresssed, the MSI launchs CMD file with below commands
                $removeexe="$env:SystemDrive\ProgramData\BeyondTrustRemoteSupport\bomgar-scc.exe"
                $ExeArg= "-uninstall silent"
                
                Start-Process -FilePath $removeexe -WorkingDirectory "$env:SystemDrive\ProgramData\BeyondTrustRemoteSupport" -ArgumentList $ExeArg -WindowStyle Hidden -Wait
                 #Sometime the EXE does not remove the Uninstall reg and because the The CMD prompt appreares during uninstall,Removeing the MSI after teh exe
                Start-Process -FilePath "msiexec.exe" -WorkingDirectory "$env:SystemDrive\Windows\system32"  -ArgumentList $removemsi -WindowStyle Hidden -Wait -ErrorAction SilentlyContinue 
               
                $var=Get-InstalledApplications -ProductCode "{5ADA213E-0F62-4DAE-9A07-16120E3958E7}"
                
                If (-not ($var))
                {Write-Log -Message "Removed, Function : Get_InstalledApplications -ProductCode '{5ADA213E-0F62-4DAE-9A07-16120E3958E7}' Returned: $var"}
                else {Write-log -Message "Something Went Wrong, Please Try again" } 
            }

        #Remove_folder (This is needed as the BTClient failes to install if this folder is present)

        Remove-Item -Path "$env:ALLUSERSPROFILE\BeyondTrustRemoteSupport" -Recurse -Force  -ErrorAction SilentlyContinue
#endregion Cleanup


#region Traverse_and_Convert_Json_To_hastable 

        $JsonObj=(Get-content -Path "$sScriptDir\BTRS_Installation_Groups.json") | ConvertFrom-Json #Converts .json to [PsObject]
        $ParantOU=$JsonObj.psobject.Properties.name
        Write-Log -Message "Parsing the JSON, Trying to make Hashtable"
 
        foreach($Ou in $ParantOU)
        {
             $T1=@{}
             $J1=@{}

                $Type=$JsonObj.$Ou.gettype().basetype.name
                If ($type -eq 'array')   #  if(($Ou -is [System.Collections.IEnumerable]) -or ( $Ou -is [array]))
                      {
                            $PsObj=$JsonObj.$ou| Select-Object # Returns the hastable object which can be parsed.
                            $prop=$psobj.psobject.properties.name
                                foreach ($p in $prop)
                                {
                                    $T1.add("$p",$JsonObj.$ou.$p.jc_tag)
                                    $J1.add("$p",$JsonObj.$Ou.$p.jc_jump_group)
                                }
                     }

                Else
                   {
                           $T1.add($ou,$jsonobj.$ou.jc_tag)
                           $J1.add($ou,$JsonObj.$Ou.jc_jump_group)
                   }

             $tags.add("$ou",$T1)
             $jumpGroup.add("$ou",$J1)
         }

        Write-Log -Message "Hashtables Created - ""tags"":$tags and ""jumpGroup"": $jumpGroup "  
#endregion Traverse_and_Convert_Json_To_hastable 


#region Get_Domain_name_of_machine

        $SysInfo = New-Object -ComObject "ADSystemInfo"
        try
            {
                $ComputerDN = $SysInfo.GetType().InvokeMember("ComputerName", "GetProperty", $Null, $SysInfo, $Null)
                $ComputerDNArray=$ComputerDN.Split(',').tolower()
            }
        Catch
        {
                 Write-Log -Message "Query to AD Unsuccessful, Please Run with Admin rights or Contact Your System Admin"
                 $error1=$True
                 $ExitC=9 #Any code can be specified here
                 [System.Environment]::Exit($ExitC) #This will return exit code to altiris
        }
#endregion Get_Domain_name_of_machine


#region FindTheLinkValueForDomainName
        If ($error1 -eq $False)
        {  Write-Log -Message "Query to AD is Successful, Returned - $($ComputerDN.tolower())" 
   
            foreach($Sub_OU in $ParantOU)
            {  
               $SearchItem = "ou=$Sub_OU".ToLower()
               Write-Log -Message "Checking if the Domain Info Contains $SearchItem :$($ComputerDNArray.contains($SearchItem))"
       
               # Find the Value of "jc_jump_group" and "jc_tag" from the hashtable, based on the domain name

                if ($ComputerDNArray.contains($SearchItem))    
                {
                    $param_tags=GetLinkedParams -obj $tags -DomainInfo $ComputerDNArray -parentOU "$Sub_OU"
                    $param_JumpGroup=GetLinkedParams -obj $jumpGroup -DomainInfo $ComputerDNArray -parentOU "$Sub_OU"
                    Write-Log -Message "Function Returned, ""jc_jump_group""= $param_JumpGroup and ""jc_tag"" =  $param_tags "
                }
            }
        }
                Else {Write-log "The parent OU of this machine is not mentioned in the link file (.json)"}
    
#endregion FindTheLinkValueForDomainName


#region Install_BtclientMSI_with_Custom_params
        if (($param_JumpGroup -eq $Null) -and ($param_tags -eq $Null))
            {      $param_JumpGroup= "jumpgroup:General_Population"
                   $param_tags ="" # "WinDesktops"  -  The New Json has jc_tag empty as it makes subgroups whihc roland does not want.
                   Write-Log -Message "NO Match found, Please add Link in the .json, Please contact Your system admin"
                   Write-Log -Message "Initialising the Default Values ""jc_jump_group""= jumpgroup:General_Population  and ""jc_tag"" = "
       
            }
               $args=" /i ""$sScriptDir\bomgar-scc-win64.msi"" KEY_INFO=w0ic305dfy5d71d6zizxyiewe8dz8zx76d58gic40hc90 INSTALLDIR=""$env:SystemDrive\Programdata\BeyondTrustRemoteSupport"" REBOOT=ReallySuppress /qn /L*v ""$env:SystemDrive\temp\BeyondTrustClient21.1.1_MSI.log"" jc_jump_group=""$param_JumpGroup"" jc_tag=""$param_tags"""
               Write-Log -Message "Starting installation: -FilePath ""$env:SystemDrive\Windows\system32\msiexec.exe"" -ArgumentList $args "
               $status= Start-Process -FilePath "msiexec.exe" -WorkingDirectory "$env:SystemDrive\Windows\system32"  -ArgumentList $args -WindowStyle Hidden -Wait -ErrorAction SilentlyContinue
               
              
               If (Get-InstalledApplications -ProductCode "{5ADA213E-0F62-4DAE-9A07-16120E3958E7}")
               {Write-Log -Message "Installed Successfully"}
               else {Write-log -Message "Something Went Wrong, Please Try again" } 




#endregion Install_BtclientMSI_with_Custom_params                   


#region_Write_DetectionReg
Start-Process -FilePath "reg.exe" -WorkingDirectory "$env:SystemDrive\Windows\system32" -ArgumentList 'add "HKLM\SOFTWARE\Bomgar\Bomgar_Client" /v "Scripted" /t REG_SZ /d "Yes" /f /reg:64' -WindowStyle Hidden -Wait
#endregion_Write_DetectionReg


#check if the "bomgar-scc" running.

$proc= Get-Process -ProcessName "bomgar-scc" -ErrorAction SilentlyContinue
If ($proc){Write-Log -Message " Process 'bomgar-scc' Is running"}
else{Write-Log -Message "The Process 'bomgar-scc' Does not exists, please reinstall the package."}

 }




#-----------------------------------------------------------------


elseif ($Action -eq "Uninstall")
{
$RmPath="$env:SystemDrive\temp\UninstallBT_Client_ScriptBased.log"
#region CleanuponRemove

 
        #stop Process
        $proc=Stop-Process -Name "bomgar-scc" -PassThru -Force -ErrorAction SilentlyContinue
        If($proc){Write-Log -Message "Stopped Process $proc" -Path $RmPath}
        Else{Write-Log -Message "Process Does Not Exists or Could Not Stop the Process" -Path $RmPath}

        #Remove Old MSI 

        If(Get-InstalledApplications -ProductCode "{5ADA213E-0F62-4DAE-9A07-16120E3958E7}") 
            {
                Write-Log -Message "Found Old Application, Trying to Remove it" -Path $RmPath
                $removemsi= "/x {5ADA213E-0F62-4DAE-9A07-16120E3958E7} /qn " #The CMD prompt appreares during uninstall, which not be suppresssed, the MSI launchs CMD file with below commands
                $removeexe="$env:SystemDrive\ProgramData\BeyondTrustRemoteSupport\bomgar-scc.exe"
                $ExeArg= "-uninstall silent"
                
                Start-Process -FilePath $removeexe -WorkingDirectory "$env:SystemDrive\ProgramData\BeyondTrustRemoteSupport" -ArgumentList $ExeArg -WindowStyle Hidden -Wait
                 #Sometime the EXE does not remove the Uninstall reg and because the The CMD prompt appreares during uninstall,Removeing the MSI after teh exe
                Start-Process -FilePath "msiexec.exe" -WorkingDirectory "$env:SystemDrive\Windows\system32"  -ArgumentList $removemsi -WindowStyle Hidden -Wait -ErrorAction SilentlyContinue 
               
                $var=Get-InstalledApplications -ProductCode "{5ADA213E-0F62-4DAE-9A07-16120E3958E7}"
                
                If (-not ($var))
                {Write-Log -Message "Removed Successfully, Function : Get_InstalledApplications -ProductCode '{5ADA213E-0F62-4DAE-9A07-16120E3958E7}' Returned: $var" -Path $RmPath}
                else {Write-log -Message "Something Went Wrong, Please Try again" -Path $RmPath }
            }

        #Remove_folder ( This is needed as the BTClient failes to install if this folder is present

        Remove-Item -Path "$env:ALLUSERSPROFILE\BeyondTrustRemoteSupport" -Recurse -Force -ErrorAction SilentlyContinue
        Write-log -Message "Removed $env:ALLUSERSPROFILE\BeyondTrustRemoteSupport" -Path $RmPath 

        #region Remove_DetectionReg
        Start-Process -FilePath "reg.exe" -WorkingDirectory "$env:SystemDrive\Windows\system32" -ArgumentList 'Delete "HKLM\SOFTWARE\Bomgar\Bomgar_Client" /v "Scripted" /f /reg:64' -WindowStyle Hidden -ErrorAction SilentlyContinue 
        Write-log -Message "reg deleted : HKLM\SOFTWARE\Bomgar\Bomgar_Client\scripted" -Path $RmPath
         #endregion Remove_DetectionReg

#endregion CleanuponRemove

}
else {Write-Log -Message "Invalid Params supplied, please supply either 'install' or 'Uninstall'"}