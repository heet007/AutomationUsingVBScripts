﻿[CMDLETBINDING()]
Param()

function Get-InstalledProducts {
[CMDLETBINDING()]
Param()
   
    $uninstallRegKeys = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall','HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')
    $UninstallKeys = gci $uninstallRegKeys -ErrorAction SilentlyContinue
   
   foreach ($key in $UninstallKeys) 
   {    
        $keyProperties = gp $key.pspath;
        foreach ($p in $keyProperties) 
        {                                
                 $uninstallString = $p.uninstallstring           
                 $tempString = $uninstallString -replace '.*?\{(.*?)\}.*','$1' 
        
                if ( -not ($tempString -eq $uninstallString) ) {
                    $productKey = $tempString
                } 

                if ($p.DisplayName) 
                {
                   new-object psobject -Property @{
                        ComputerName    = $env:COMPUTERNAME;                         
                        DisplayName     = $p.DisplayName; 
                        DisplayVersion  = $p.DisplayVersion; 
                        Publisher       = $p.publisher;
                        InstallDate     = $p.InstallDate;
                        InstallLocation = $p.InstallLocation; 
                        InstallSource   = $p.InstallSource;
                        UninstallString = $uninstallString; 
                        ProductKey      = $productKey;   
                    }
                }
                    
        }        
    }    
}

function IsAdministrator
{
    $Identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $Principal = New-Object System.Security.Principal.WindowsPrincipal($Identity)
    $Principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
}


function IsUacEnabled
{
    (Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System).EnableLua -ne 0
}

if (!(IsAdministrator))
{
    if (IsUacEnabled)
    {
        # [string[]]$argList = @('-NoProfile', '-NoExit', '-File', $MyInvocation.MyCommand.Path)    ## from K.Hill. Problem with space.
        #[string[]]$argList = @('-NoProfile', '-NoExit', '-File', ('"' + $MyInvocation.MyCommand.Path + '"'))        
        [string[]]$argList = @('-NoProfile', '-File', ('"' + $MyInvocation.MyCommand.Path + '"'))        
        $argList += $MyInvocation.BoundParameters.GetEnumerator() | Foreach {"-$($_.Key)", "$($_.Value)"}        
        $argList += $MyInvocation.UnboundArguments        
        Start-Process "$env:Windir\System32\WindowsPowerShell\v1.0\PowerShell.exe" -Verb Runas -WorkingDirectory $pwd -WindowStyle Hidden -ArgumentList $argList                        
        return
    }
    else
    {
        throw "You must be administrator to run this script"
    }
}

$results = Get-InstalledProducts

if ($results) {
    $results | Select  ComputerName,DisplayName,DisplayVersion,Publisher,InstallDate,InstallLocation,InstallSource,UninstallString,ProductKey  | Export-Csv -NoTypeInformation -Path "${env:TEMP}\${env:COMPUTERNAME}_Installed.csv" -Force
    Write-Verbose "Results written to ${env:TEMP}\${env:COMPUTERNAME}_Installed.csv"
} else {
    Write-Verbose "No data was returned"
}
