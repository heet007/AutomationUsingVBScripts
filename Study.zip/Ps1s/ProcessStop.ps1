function ProcessStop($procName){
$Proc = Get-Process $procName -ErrorAction SilentlyContinue
if ($Proc) {
   # try gracefully first
   $Proc.CloseMainWindow()
   # kill after five seconds
    Sleep 5
    if (!$Proc.HasExited) {
      $Proc | Stop-Process -Force
    }
  }
 }