﻿#--------------------------------
#region FunctionAndModules

function Write-Log 
{ 
    [CmdletBinding()] 
    Param 
    ( 
        [Parameter(Mandatory=$true, 
                   ValueFromPipelineByPropertyName=$true)] 
        [ValidateNotNullOrEmpty()] 
        [Alias("LogContent")] 
        [string]$Message, 
 
        [Parameter(Mandatory=$false)] 
        [Alias('LogPath')] 
        [string]$Path="$env:SystemDrive\temp\InstallCrowdStrike_Powershell.log", 
         
        [Parameter(Mandatory=$false)] 
        [ValidateSet("Error","Warn","Info")] 
        [string]$Level="Info", 
         
        [Parameter(Mandatory=$false)] 
        [switch]$NoClobber 
    ) 
 
    Begin 
    { 
        # Set VerbosePreference to Continue so that verbose messages are displayed. 
        $VerbosePreference = 'SilentlyContinue' 
    } 
    Process 
    { 
         
        # If the file already exists and NoClobber was specified, do not write to the log. 
        if ((Test-Path $Path) -AND $NoClobber) { 
            Write-Error "Log file $Path already exists, and you specified NoClobber. Either delete the file or specify a different name." 
            Return 
            } 
 
        # If attempting to write to a log file in a folder/path that doesn't exist create the file including the path. 
        elseif (!(Test-Path $Path)) { 
            Write-Verbose "Creating $Path." 
            $NewLogFile = New-Item $Path -Force -ItemType File 
            } 
 
        else { 
            # Nothing to see here yet. 
            } 
 
        # Format Date for our Log File 
        $FormattedDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss" 
 
        # Write message to error, warning, or verbose pipeline and specify $LevelText 
        switch ($Level) { 
            'Error' { 
                Write-Error $Message 
                $LevelText = 'ERROR:' 
                } 
            'Warn' { 
                Write-Warning $Message 
                $LevelText = 'WARNING:' 
                } 
            'Info' { 
                Write-Verbose $Message 
                $LevelText = 'INFO:' 
                } 
            } 
         
        # Write log entry to $Path 
        
        "$FormattedDate $LevelText $Message" | Out-File -FilePath $Path -Append
    } 
    End 
    { 
    } 
}

#--------------------------------------------------------------------

$TAGS=$Null
$error1=$False
$ExitC=0
$OUName=@('Phase1','Phase2','Phase3','Phase4','NYULMC EVIP','Research')
$SysInfo = New-Object -ComObject "ADSystemInfo"
try{$ComputerDN = $SysInfo.GetType().InvokeMember("ComputerName", "GetProperty", $Null, $SysInfo, $Null)}
Catch{
 Write-Log -Message "Query to AD Unsuccessful, Please Run with Admin rights or Contact Your System Admin"
 $error1=$True
 $ExitC=9 #Any code can be specified here
 [System.Environment]::Exit($ExitC) #This will return exit code ot altiris
}
 
 If ($error1 -eq $False)
{   
    Write-Log -Message "Query to AD is Successful, Returned - $ComputerDN"
    :ForLp foreach ($item in $OUName)
    {
    $SearchTerm=  ("OU=$item").tolower()
    $KeyCheck=$ComputerDn.tolower().contains("$SearchTerm")

    Write-Log -Message "Searching $SearchTerm, Returned : $KeyCheck"
      
     #if ($KeyCheck -eq $true)
     if ($KeyCheck)
         { 
           :Switch1 Switch ( $item )
             {    
                'Phase1' { $TAGS = "Wave1"}#Production tag is removed from all the values
                #break ForLp } 
                'Phase2' { $TAGS = "We2"  }
                'Phase3' { $TAGS = "Wave3"}
                'Phase4' { $TAGS = "Wave4"}
                'NYULMC EVIP' { $TAGS = "EVIP"}
                'Research'    { $TAGS = "Research"}
         
            }#end Switch
                Write-Log -Message "Lookup: $SearchTerm, -- Found : $TAGS"
        
        }#EndIf
        Else{ ""}

    }#EndFor
   
}#EndIf

if ($TAGS -ne $Null){
$args ="/Install /quiet /norestart CID=9D2F21341EF54910BAC7E0BA3B1D18DE-0A /LOG C:\temp\Crowstrike6.16.13008.log GROUPING_TAGS=""$TAGS"""
$sScriptDir= $MyInvocation.MyCommand.Path

Write-Log -Message "Starting installation: -FilePath ""$sScriptDir\WindowsSensor.exe"" -ArgumentList ""$args"" "
$status= Start-Process -FilePath "$sScriptDir\WindowsSensor.exe" -ArgumentList $args -NoNewWindow -WindowStyle Hidden -Wait -ErrorAction SilentlyContinue
}
Else{ Write-Log -Message "NO Match found, Please add Link in the Lookup"}