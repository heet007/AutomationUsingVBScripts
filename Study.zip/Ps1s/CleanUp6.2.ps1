﻿$ErrorActionPreference='SilentlyContinue'

Function Write-Log 
{ 
    [CmdletBinding()] 
    Param 
    ( 
        [Parameter(Mandatory=$true, 
                   ValueFromPipelineByPropertyName=$true)] 
        [ValidateNotNullOrEmpty()] 
        [Alias("LogContent")] 
        [string]$Message, 
 
        [Parameter(Mandatory=$false)] 
        [Alias('LogPath')] 
        [string]$Path="$env:SystemDrive\temp\Imprivata_PatientSecure_CleanupScript.log", 
         
        [Parameter(Mandatory=$false)] 
        [ValidateSet("Error","Warn","Info")] 
        [string]$Level="Info", 
         
        [Parameter(Mandatory=$false)] 
        [switch]$NoClobber 
    ) 
 
    Begin 
    { 
        # Set VerbosePreference to Continue so that verbose messages are displayed. 
        $VerbosePreference = 'SilentlyContinue' 
    } 
    Process 
    { 
         
        # If the file already exists and NoClobber was specified, do not write to the log. 
        if ((Test-Path $Path) -AND $NoClobber) { 
            Write-Error "Log file $Path already exists, and you specified NoClobber. Either delete the file or specify a different name." 
            Return 
            } 
 
        # If attempting to write to a log file in a folder/path that doesn't exist create the file including the path. 
        elseif (!(Test-Path $Path)) { 
            Write-Verbose "Creating $Path." 
            $NewLogFile = New-Item $Path -Force -ItemType File 
            } 
 
        else { 
            # Nothing to see here yet. 
            } 
 
        # Format Date for our Log File 
        $FormattedDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss" 
 
        # Write message to error, warning, or verbose pipeline and specify $LevelText 
        switch ($Level) { 
            'Error' { 
                Write-Error $Message 
                $LevelText = 'ERROR:' 
                } 
            'Warn' { 
                Write-Warning $Message 
                $LevelText = 'WARNING:' 
                } 
            'Info' { 
                Write-Verbose $Message 
                $LevelText = 'INFO:' 
                } 
            } 
         
        # Write log entry to $Path 
        
        "$FormattedDate $LevelText $Message" | Out-File -FilePath $Path -Append
    } 
    End 
    { 
    } 
}

Function ProcessStop($procName){
$Proc = Get-Process $procName -ErrorAction SilentlyContinue
if ($Proc) {
   # try gracefully first
   $Proc.CloseMainWindow()
   # kill after five seconds
    Sleep 5
    if (!$Proc.HasExited) {
      $Proc | Stop-Process -Force
    }
    Write-log "$($Proc.name) is Killed : $($Proc.HasExited)"
  }
 }

Function Get-InstalledApplications #Author: Hitesh Patel
{
	    [CmdletBinding(DefaultParameterSetName='PName')]
        Param (

        [Parameter(Mandatory=$true,ParameterSetName='PName',Position=0)]
        [ValidateNotNullorEmpty()]
        [string]$ProductName,

        [Parameter(Mandatory=$true,ParameterSetName='Pcode',Position=1)]
        [ValidatePattern("^(\{{0,1}([0-9a-fA-F]){8}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){12}\}{0,1})$")]
        [ValidateNotNullorEmpty()]
        [string]$ProductCode,

        [Parameter(Mandatory=$False,Position=2)]
        [ValidateNotNullorEmpty()]
        #[ValidateSet('PsObject','Boolean')]
        [Switch]$GetObj,

        [Parameter(Mandatory=$false,Position=3)]
        [Switch]$Exclude_SysWow
            ) 

$obj=@()
$Counter=0
$Check=$null

        if (($Exclude_SysWow) -or ([IntPtr]::Size -eq 4))
               {$path = @('HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*')
               $Counter=$path.Length}

        else   {$path = @('HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
                $Counter=$path.Length
        }
           
#[psobject[]]$AppInfo= @()
#if ($get -eq 'PsObject'){

$ErrorActionPreference = "SilentlyContinue"

if ($GetObj){
    foreach($item in $path)
       {    
         if ($ProductName)
            {
        <# $checkBit=$false
            if (($item -notlike "*Wow6432Node*") -and ([IntPtr]::Size -ne 4)){$checkBit=$true}
                                                 else { $checkBit=$False }
                                                 $IS64= @{label="is64"; expression={ $checkBit } } #>  

           $obj+= Get-ChildItem $item|
                  ForEach-Object {Get-ItemProperty $_.Pspath}|
                  Where-Object {$_.displayname -like $ProductName}|
                  Select-Object -Property Displayname,DisplayVersion,publisher,Pschildname,InstallDate,UninstallString,InstallSource -ErrorAction SilentlyContinue
             }
         
        else {
            $obj+= Get-ChildItem $item|
                  ForEach-Object {Get-ItemProperty $_.Pspath}|
                  Where-Object {$_.Pschildname -eq $ProductCode}|
                  Select-Object -Property Displayname,DisplayVersion,publisher,Pschildname,InstallDate,UninstallString,InstallSource -ErrorAction SilentlyContinue
             }

        }
       $ErrorActionPreference = "Continue" # this is to avoide error due to invalid characters in the registry path like "Root\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\BeyondTrust Remote Support Jump Client [remotesupport.nyumc.org-606F43B0]"
       If ($obj.count -ne 0){Return $obj}
       Else {Return $False}
}

Else{
       foreach($item in $path)
        {
                if ($ProductName){$Check=Get-ChildItem $item|ForEach-Object {Get-ItemProperty $_.pspath}|Where-Object {$_.displayname -like $ProductName}}
                Else             {$Check=Get-ChildItem $item|ForEach-Object {Get-ItemProperty $_.pspath}|Where-Object {$_.Pschildname -eq $ProductCode}}
               
              $ErrorActionPreference = "Continue" # this is to avoide error due to invalid characters in the registry path like "Root\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\BeyondTrust Remote Support Jump Client [remotesupport.nyumc.org-606F43B0]"
      
                If ($Check -ne $null)
                        {$Counter+=1}
                Else    {$Counter-=1}
                
       }

        
If($Counter -ge 1){Return $True}
Else              {Return $False}

    }

}#end Function

function Show-MessageBox {
[CmdletBinding()]
param(
    [Parameter(Mandatory, Position=0)]
    [string]$Message,
    [Parameter(Position=1)]
    [string]$Title = '',
    [ValidateSet('OK','OKCancel','AbortRetryIgnore','YesNoCancel','YesNo','RetryCancel')]
    [Parameter(Position=2)]
    [string]$Buttons = 'OK',
    [ValidateSet('None','Hand','Error','Stop','Question','Exclamation','Warning','Asterisk','Information')]
    [Parameter(Position=3)]
    [string]$Icon = 'None',
    [Parameter(Position=4)]
    [int]$Timeout = 0
)
    Add-Type -Assembly System.Windows.Forms
    $w = $null
    if ($Timeout) {
        $cancel = New-Object System.Threading.CancellationTokenSource
        $w = New-Object System.Windows.Forms.Form
        $w.Size = New-Object System.Drawing.Size (0,0)
        [System.Action[System.Threading.Tasks.Task]]$action = {
            param($t)
            Write-Debug "Want to Close $($task.Status)"
            $w.Close()
        }
        $task = [System.Threading.Tasks.Task]::Delay(
            [timespan]::FromSeconds($Timeout), $cancel.Token
        ).ContinueWith($action,
            [System.Threading.Tasks.TaskScheduler]::FromCurrentSynchronizationContext()
        )
        Write-Debug "Before $($task.Status)"
    }
    $w.TopMost = $true
    [System.Windows.Forms.MessageBox]::Show($w, $Message, $Title, $Buttons, $Icon)
    if ($Timeout) {
        Write-Debug "After $($task.Status)"
        if ($task.Status -ne 'RanToCompletion') {
            Write-Debug "Do Cancel"
            $cancel.Cancel()
            $task.Wait()
            $cancel.Dispose()
        }
        $task.Dispose()
    }
} 

Write-Log "---------------------------------------------------------------------------------"

$T_msg="Your Computer Must Be Restarted"
$sec=120
$msg="YOUR COMPUTER WILL BE RESTARTED IN NEXT $SEC SECONDS, PLEASE SAVE YOUR WORK!.`nThis Restart is required to completely remove the ‘PatientSecure v4.2.307.10201’ & ‘PalmSecure v3.1.0404’ applications from your computer"
$new_msg="YOUR COMPUTER WILL BE RESTARTED in approximatively $($sec/60) minutes PLEASE SAVE YOUR WORK ! "
$ScheduledTaskName="PatientSecure42Fix" 

$ProcesstoKill=@("EpicWelcome", "PatientSecure.Hubs","PatientSecure.Listener","kiosk","PatientSecureMonitoringService")
foreach ($process in $ProcesstoKill)
{ProcessStop $process }

# // Service Startup Disabled
Get-Service "ImprivataPatientSecureHubs" -erroraction silentlycontinue |Stop-Service -Force -ErrorAction SilentlyContinue   
start-process -FilePath "c:\Windows\System32\sc.exe" -ArgumentList "delete `"ImprivataPatientSecureHubs`"" -WindowStyle Hidden -ea SilentlyContinue

# // remove ScheduledTask
Get-ScheduledTask -TaskName $ScheduledTaskName -ErrorAction SilentlyContinue| Unregister-ScheduledTask -Confirm:$false -ErrorAction SilentlyContinue

# // remove folder "C:\Program Files (x86)\Imprivata_PatientSecureFix\" 
Remove-Item -Path "C:\Program Files (x86)\Imprivata_PatientSecureFix\" -Force -Recurse  

# // Remove the cert
start-process -FilePath "c:\Windows\System32\netsh.exe" -ArgumentList "http delete sslcert 0.0.0.0:8081" -WindowStyle Hidden -ea SilentlyContinue
start-process -FilePath "c:\Windows\System32\netsh.exe" -ArgumentList "http delete sslcert 0.0.0.0:8082" -WindowStyle Hidden -ea SilentlyContinue
start-process -FilePath "c:\Windows\System32\netsh.exe" -ArgumentList "http delete sslcert 0.0.0.0:8083" -WindowStyle Hidden -ea SilentlyContinue

# // Deleting Registry
Get-Item -Path "HKLM:\SOFTWARE\Imprivata\PatientSecure" | Remove-ItemProperty -Name CONNECTIONSTRING -ErrorAction SilentlyContinue
Get-Item -Path "HKLM:\SOFTWARE\Imprivata\PatientSecure" | Remove-ItemProperty -Name PSWS_ADDRESS -ErrorAction SilentlyContinue

# // RemoveOldApps
$AppsToRemove=@{"ImprivataPatientSecureWebClient v4.2.307.10201" = '{326A22A6-02BA-4C54-BA99-C7EAAF347DA5}';"ImprivataPatientSecureWebClient v6.2.000.24"='{80951C45-F7C3-4A96-941C-CF7BBFA5931F}';"ImprivataPatientSecureWebClient v6.1.000.11" = '{47058482-9573-486A-8222-368686E9E76A}';"Driver 64bit"='{F08A5787-2BFF-4250-B216-AF9E0F5BBC1E}';"ImprivataPatientSecureWebClient.msi v5.3.1.7"='{5BC20E02-97E0-4CAA-99BE-61DA99FEACEF}';"PalmSecure_3.1.0404 32bit" = '{1DBDC958-8440-4DF1-B857-650BC2033A50}';"PalmSecure_3.1.0404 64bit" = '{2FCE51D0-144B-4A90-8FB1-CF3D0655FD91}';"PalmSecure_3.1.0407 64bit" = '{F1FE4290-46ED-4985-BCC8-748DF68413DB}'}

foreach($app in $AppsToRemove.GetEnumerator())
{
    $cmdLine= "/x $($app.value) /qn /norestart"
    Write-Log "Trying to Remove $($app.name), Running : msiexec /x $($app.value) /qn"
    $r_exitCode=Start-Process -FilePath "msiexec.exe" -ArgumentList "$cmdLine" -ErrorAction SilentlyContinue -WindowStyle Hidden -Wait -PassThru
    Write-log "ExitCode : $($r_exitCode.exitCode)"
}

# // #Installing EXE 
$EXE = $PSScriptRoot + "\PalmSecure_3.1.0407\fujitsuremoval2002.exe"
Write-log "Running : $EXE"
$b=Start-Process -FilePath "$EXE" -wait -ErrorAction SilentlyContinue -WindowStyle Hidden -PassThru
Write-log "Install Returned ExitCode : $($b.Exitcode)"

#$a=new-item -Path "HKLM:\SOFTWARE\NYUMC\ImprivataPatientSecure\" -Force

If ((Get-InstalledApplications -ProductCode "{80951C45-F7C3-4A96-941C-CF7BBFA5931F}") -or (Get-InstalledApplications -ProductCode '{F1FE4290-46ED-4985-BCC8-748DF68413DB}') ){
    #$b=New-ItemProperty -path "HKLM:\SOFTWARE\NYUMC\ImprivataPatientSecure\" -name "Removed" -Value "False" -Force}
    Write-log "Cleanup failed"}
Else { 
    Write-Log "Cleanup Successful - Restarting this machine in $sec Seconds"
    Write-Log "$msg"
    #$a=Show-MessageBox -Message $new_msg -Title $T_msg -Icon Information -Timeout $sec 
    Start-Process -FilePath "$env:SystemRoot\system32\msg.exe" -ArgumentList "* /time:$sec  $new_msg"
    Start-Sleep -Seconds $sec 
    Restart-Computer -Force 
    
    Exit

    }
    #$b=New-ItemProperty -path "HKLM:\SOFTWARE\NYUMC\ImprivataPatientSecure\" -name "Removed" -Value "True" -Force}

#Write-Log "reg added - $b"
