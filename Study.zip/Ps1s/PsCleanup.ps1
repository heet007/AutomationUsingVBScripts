﻿#--------------------------------
#region FunctionAndModules

function Write-Log 
{ 
    [CmdletBinding()] 
    Param 
    ( 
        [Parameter(Mandatory=$true, 
                   ValueFromPipelineByPropertyName=$true)] 
        [ValidateNotNullOrEmpty()] 
        [Alias("LogContent")] 
        [string]$Message, 
 
        [Parameter(Mandatory=$false)] 
        [Alias('LogPath')] 
        [string]$Path="$env:TEMP\KiosksDiskCleanUp.log", 
         
        [Parameter(Mandatory=$false)] 
        [ValidateSet("Error","Warn","Info")] 
        [string]$Level="Info", 
         
        [Parameter(Mandatory=$false)] 
        [switch]$NoClobber 
    ) 
 
    Begin 
    { 
        # Set VerbosePreference to Continue so that verbose messages are displayed. 
        $VerbosePreference = 'SilentlyContinue' 
    } 
    Process 
    { 
         
        # If the file already exists and NoClobber was specified, do not write to the log. 
        if ((Test-Path $Path) -AND $NoClobber) { 
            Write-Error "Log file $Path already exists, and you specified NoClobber. Either delete the file or specify a different name." 
            Return 
            } 
 
        # If attempting to write to a log file in a folder/path that doesn't exist create the file including the path. 
        elseif (!(Test-Path $Path)) { 
            Write-Verbose "Creating $Path." 
            $NewLogFile = New-Item $Path -Force -ItemType File 
            } 
 
        else { 
            # Nothing to see here yet. 
            } 
 
        # Format Date for our Log File 
        $FormattedDate = Get-Date -Format "yyyy-MM-dd HH:mm:ss" 
 
        # Write message to error, warning, or verbose pipeline and specify $LevelText 
        switch ($Level) { 
            'Error' { 
                Write-Error $Message 
                $LevelText = 'ERROR:' 
                } 
            'Warn' { 
                Write-Warning $Message 
                $LevelText = 'WARNING:' 
                } 
            'Info' { 
                Write-Verbose $Message 
                $LevelText = 'INFO:' 
                } 
            } 
         
        # Write log entry to $Path 
        
        "$FormattedDate $LevelText $Message" | Out-File -FilePath $Path -Append
    } 
    End 
    { 
    } 
}



Function Invoke-DiskCleanup{

[CmdletBinding()] 
    Param ( 
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()] 
        [byte]$StateFlags= '89',
 
        [Parameter(Mandatory=$false)] 
        [string]$includeData='',
         
        [Parameter(Mandatory=$false)]
        [string]$excludeData='', 

        [Parameter(Mandatory=$false)] 
        [string]$strKeyPath="HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\VolumeCaches",
         
        [Parameter(Mandatory=$false)] 
        [switch]$clean_StateFlag
    ) 

    $subkeys = Get-ChildItem -Path $strKeyPath -Name -Include $includeData -Exclude $excludeData
    Write-Log -Message "Function start : Invoke-Diskcleanup : Subkey Count = $($subkeys.count) "

    $strValueName="StateFlags00$($StateFlags)"
    Write-Log -Message "Function : Invoke-Diskcleanup : Setting StateFlag = $strValueName"

ForEach($subkey in $subkeys){
Write-log -Message " Writing Registry : -Path $strKeyPath\$subkey -Name $strValueName -PropertyType DWord -Value 2"

    $null = New-ItemProperty `
        -Path $strKeyPath\$subkey `
        -Name $strValueName `
        -PropertyType DWord `
        -Value 2 `
        #-ea SilentlyContinue `
        #-wa SilentlyContinue 
}

Write-log -Message " Running Command : cleanmgr -ArgumentList /sagerun:$StateFlags"

Start-Process cleanmgr `
        -ArgumentList "/sagerun:$StateFlags" `
        -Wait `
        -NoNewWindow `
        -ErrorAction   SilentlyContinue `
        -WarningAction SilentlyContinue 

if ($clean_StateFlag){
Write-log -Message " Clean_stateFlag: $clean_StateFlag : Cleaning the clean_StateFlag from registry "

    ForEach($subkey in $subkeys){
        $null = Remove-ItemProperty `
            -Path $strKeyPath\$subkey `
            -Name $strValueName `
            -ea SilentlyContinue `
            -wa SilentlyContinue
}}
Write-log -Message " Function End : Invoke-DiskCleanup"

}

#endregion FunctionAndModules
#--------------------------



Write-log -Message " Clean_stateFlag: $clean_StateFlag : Cleaning the clean_StateFlag from the registry "

$Before = Get-CimInstance -Query "Select DeviceID,Size,FreeSpace FROM Win32_LogicalDisk WHERE DeviceID='$($env:SystemDrive)'"

$exclude = "'Update Cleanup',"
#Invoke-DiskCleanup -StateFlags 25 -clean_StateFlag # -excludeData 'Update Cleanup' -includeData
Invoke-DiskCleanup -StateFlags 25 -clean_StateFlag -excludeData 'Update Cleanup'# -includeData


$After = Get-CimInstance -Query "Select FreeSpace FROM Win32_LogicalDisk WHERE DeviceID='$($env:SystemDrive)'"
        $obj=[PSCustomObject]@{
            'DiskDeviceID'       = $Before.DeviceID
            'DiskSize'           = $Before.Size
            'FreeSpaceBefore'    = $Before.FreeSpace
            'FreeSpaceAfter'     = $After.FreeSpace
            'TotalCleanedUp'     = $After.FreeSpace - $Before.FreeSpace
            'TotalCleanedUp(GB)' = '{0:N2}' -f (($After.FreeSpace - $Before.FreeSpace)/1GB)}

Write-log -Message " 
System Cleanup Stats : 
$obj
"

write-log -Message "----------------- Deleting the hiberfil.sys -------------------------------------"

Write-log -Message " Deleting hiberfil.sys ; Running command : c:\Windows\System32\powercfg.exe /h ON "

Start-Process -FilePath "C:\Windows\System32\powercfg.exe" -ArgumentList "/H OFF" -Wait -WindowStyle Hidden



write-log -Message "------------------ Deleting the pagfile.sys , this may also clear the hyberfil.sys ------"

Write-log -Message "writing the registry : 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name ClearPageFileAtShutdown -Value 1"
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name ClearPageFileAtShutdown -Value 1 -ErrorAction SilentlyContinue


if ((Get-ItemPropertyValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name ClearPageFileAtShutdown -ErrorAction SilentlyContinue) -eq 1)
        {Write-log -Message "NOTE: ' FILES WILL BE CLEARED ON THE NEXT REBOOT. DEPENDING ON THE SIZE OF PAGEFILE.sys, RESTART MAY TAKE LONGER THE USUAL TIME "}
else
        {Write-log -Message "Script Could not write to the registry, Please make sure script is launched with admin rights"}


Write-log -Message "----------------- Deleting and the search index file -------------------------------------"

Stop-Service -Name Wsearch -ErrorAction SilentlyContinue
Write-Log -Message "Service Status -- Wsearch : $((Get-Service wsearch).status)"

$IndexFile= test-path "$Env:ProgramData\Microsoft\Search\Data\Applications\Windows\Windows.edb" -ErrorAction SilentlyContinue
Write-Log -Message "Windows.edb Exists : $IndexFile"

if ($IndexFile)
    {
        Remove-item "$Env:ProgramData\Microsoft\Search\Data\Applications\Windows\Windows.edb" -Force -ErrorAction SilentlyContinue
        Write-Log -Message "Removed !!, File Exists : $(test-path "$Env:ProgramData\Microsoft\Search\Data\Applications\Windows\Windows.edb" -ErrorAction Continue)"
        Start-Service -Name WSearch -ErrorAction SilentlyContinue 
        Write-Log -Message "Service Status -- Wsearch : $((Get-Service wsearch).status)"}
else
    {   Write-Log -Message "Index file does not exists or unexpected error occured"}

Write-log -Message "----------------- Compressing the User Profiles -------------------------------------"

$MarkDate=(Get-Date).AddDays(-60)
$compact="$env:SystemDrive\windows\System32\compact.exe"
$users= Get-ChildItem "$env:SystemDrive\users\*"| Where-Object { $_.PsIsContainer }
Write-Log -Message "Finding User, Who Is Inactive Since Past 60 days"
foreach($user in $users) 
{
    if ($user.LastWriteTime -le $MarkDate)
    {
        write-Log "$($user.name) was last active before $markdate"
        $UserDir="""$user"""
        $arglist="/C /S:$UserDir /I /Q"
        Write-log "Compressing User Profile $UserDir, this may take some time depending on the size of user profile." 
        Start-Process -FilePath $compact -ArgumentList $arglist -Wait -WindowStyle Hidden
        Write-log "Completed"
    }
}

