Function Get-InstalledApplications #Author: Hitesh Patel
{
	    [CmdletBinding(DefaultParameterSetName='PName')]
        Param (

        [Parameter(Mandatory=$true,ParameterSetName='PName',Position=0)]
        [ValidateNotNullorEmpty()]
        [string]$ProductName,

        [Parameter(Mandatory=$true,ParameterSetName='Pcode',Position=1)]
        [ValidatePattern("^(\{{0,1}([0-9a-fA-F]){8}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){12}\}{0,1})$")]
        [ValidateNotNullorEmpty()]
        [string]$ProductCode,

        [Parameter(Mandatory=$False,Position=2)]
        [ValidateNotNullorEmpty()]
        #[ValidateSet('PsObject','Boolean')]
        [Switch]$GetObj,

        [Parameter(Mandatory=$false,Position=3)]
        [Switch]$Exclude_SysWow
            ) 

$obj=@()
$Counter=0
$Check=$null

        if (($Exclude_SysWow) -or ([IntPtr]::Size -eq 4))
               {$path = @('HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*')
               $Counter=$path.Length}

        else   {$path = @('HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*','HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*')
                $Counter=$path.Length
        }
           
#[psobject[]]$AppInfo= @()
#if ($get -eq 'PsObject'){

$ErrorActionPreference = "SilentlyContinue"

if ($GetObj){
    foreach($item in $path)
       {    
         if ($ProductName)
            {
        <# $checkBit=$false
            if (($item -notlike "*Wow6432Node*") -and ([IntPtr]::Size -ne 4)){$checkBit=$true}
                                                 else { $checkBit=$False }
                                                 $IS64= @{label="is64"; expression={ $checkBit } } #>  

           $obj+= Get-ChildItem $item|
                  ForEach-Object {Get-ItemProperty $_.Pspath}|
                  Where-Object {$_.displayname -like $ProductName}|
                  Select-Object -Property Displayname,DisplayVersion,publisher,Pschildname,InstallDate,UninstallString,InstallSource -ErrorAction SilentlyContinue
             }
         
        else {
            $obj+= Get-ChildItem $item|
                  ForEach-Object {Get-ItemProperty $_.Pspath}|
                  Where-Object {$_.Pschildname -eq $ProductCode}|
                  Select-Object -Property Displayname,DisplayVersion,publisher,Pschildname,InstallDate,UninstallString,InstallSource -ErrorAction SilentlyContinue
             }

        }
       $ErrorActionPreference = "Continue" # this is to avoide error due to invalid characters in the registry path like "Root\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\BeyondTrust Remote Support Jump Client [remotesupport.nyumc.org-606F43B0]"
       If ($obj.count -ne 0){Return $obj}
       Else {Return $False}
}

Else{
       foreach($item in $path)
        {
                if ($ProductName){$Check=Get-ChildItem $item|ForEach-Object {Get-ItemProperty $_.pspath}|Where-Object {$_.displayname -like $ProductName}}
                Else             {$Check=Get-ChildItem $item|ForEach-Object {Get-ItemProperty $_.pspath}|Where-Object {$_.Pschildname -eq $ProductCode}}
               
              $ErrorActionPreference = "Continue" # this is to avoide error due to invalid characters in the registry path like "Root\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\BeyondTrust Remote Support Jump Client [remotesupport.nyumc.org-606F43B0]"
      
                If ($Check -ne $null)
                        {$Counter+=1}
                Else    {$Counter-=1}
                
       }

        
If($Counter -ge 1){Return $True}
Else              {Return $False}

    }

}#end Function
