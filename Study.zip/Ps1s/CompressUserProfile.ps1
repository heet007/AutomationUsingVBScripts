$MarkDate=(Get-Date).AddDays(-60)
$compact="$env:SystemDrive\windows\System32\compact.exe"
$users= Get-ChildItem "$env:SystemDrive\users\*"| Where-Object { $_.PsIsContainer }
Write-Log -Message "Finding User, Who Is Inactive Since Past 60 days"
foreach($user in $users) 
{
    if ($user.LastWriteTime -le $MarkDate)
    {
        write-Log "$($user.name) was last active before $markdate"
        $UserDir="""$user"""
        $arglist="/C /S:$UserDir /I /Q"
        Write-log "Compressing User Profile $UserDir, this may take some time depending on the size of user profile." 
        Start-Process -FilePath $compact -ArgumentList $arglist -Wait -WindowStyle Hidden
        Write-log "Completed"
    }
}
