Function GetLinkedParams #Author: Hitesh Patel
 {
 [CmdletBinding()] 
    Param 
    ( 
        [Parameter(Mandatory=$true)] 
        $obj, 
 
        [Parameter(Mandatory=$true)] 
        $DomainInfo,

         [Parameter(Mandatory=$true)] 
        $parentOU

        ) 

        Write-log "ParentOU : $parentOU"

        $keys=$obj.$parentOU.keys
        Write-log "Key(s): $keys"

        foreach($i in $Keys)
            {
            $searchItem="ou=$i".ToLower()
            Write-log "Search item : $searchItem, Found : $($DomainInfo.contains($searchItem))"

                if ($DomainInfo.contains($searchItem))
                {
                
                $param =$obj.$parentOU.$i
                
                }
            }
          
Return $param
 }