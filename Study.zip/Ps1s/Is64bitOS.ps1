function Is64bitOS()
{
    if ([System.IntPtr]::Size -eq 4)
    {
        return $false
    }
    return $true
}